import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// الواجهة في client/ وتُبنى إلى dist/ ليقدّمها خادم Express.
// في وضع التطوير (npm run dev) يمرّر Vite اتصالات اللعبة والصور إلى الخادم على المنفذ 3000.
const SERVER = `http://localhost:${process.env.PORT || 3000}`;

export default defineConfig({
  root: 'client',
  plugins: [react()],
  build: {
    outDir: '../dist',
    emptyOutDir: true,
  },
  server: {
    host: true, // يتيح الدخول من أجهزة الشبكة نفسها
    port: 5173,
    proxy: {
      '/socket.io': { target: SERVER, ws: true },
      '/img': SERVER,
      '/memes': SERVER,
    },
  },
});
