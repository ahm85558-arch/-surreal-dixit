'use strict';
/** اختبار تكامل لطبقة Socket.IO بخادم وهمي: الأحداث، الـ ack، الجلسات، ومنع التسريب. */
const test = require('node:test');
const assert = require('node:assert');
const { RoomManager } = require('../server/RoomManager');
const { registerSocketHandlers } = require('../server/socketHandlers');
const { ImageProvider } = require('../server/imageProvider');
const { FAST_TRANSITIONS, waitFor, FakeIO } = require('./helpers');

function setup(graceMs = 5000) {
  const io = new FakeIO();
  const manager = new RoomManager(io, new ImageProvider({ logger: {} }), { timers: { STORYTELLER_PHASE: 5, PLAYERS_SUBMIT_PHASE: 5, VOTING_PHASE: 5, SCORING_PHASE: 0.05 }, transitions: FAST_TRANSITIONS, graceMs });
  registerSocketHandlers(io, manager);
  return { io, manager };
}

test('لعبة كاملة عبر الأحداث مع إعادة اتصال وعدم تسريب الأسرار', async () => {
  const { io, manager } = setup();
  const host = io.connect();
  const created = await host.send('room:create', { name: 'هند', rounds: 1 });
  assert.equal(created.ok, true);
  assert.match(created.code, /^[A-Z2-9]{6}$/);

  const bad = await io.connect().send('room:join', { code: 'ZZZZZZ', name: 'س' });
  assert.equal(bad.ok, false);

  const clients = [host];
  const sessions = [created];
  for (const name of ['علي', 'منى', 'زياد']) {
    const c = io.connect();
    const r = await c.send('room:join', { code: created.code.toLowerCase(), name });
    assert.equal(r.ok, true, r.error);
    clients.push(c); sessions.push(r);
  }
  assert.equal((await clients[1].send('game:start')).code, 'NOT_HOST');
  assert.equal((await host.send('game:start')).ok, true);
  await waitFor(() => host.state?.phase === 'STORYTELLER_PHASE');

  const byId = (id) => clients[sessions.findIndex((s) => s.playerId === id)];
  const stId = host.state.storytellerId;
  const st = byId(stId);
  const others = clients.filter((c) => c !== st);

  const stImg = st.state.hand[1].id;
  assert.equal((await st.send('round:describe', { imageId: stImg, description: 'سحابة متأخرة عن العمل' })).ok, true);

  // إعادة اتصال لاعب بمعرّف الجلسة أثناء الجولة
  const idx = clients.indexOf(others[0]);
  const handBefore = others[0].state.hand.map((i) => i.id);
  others[0].disconnect();
  const again = io.connect();
  const rj = await again.send('room:rejoin', { code: sessions[idx].code, sessionId: sessions[idx].sessionId });
  assert.equal(rj.ok, true, rj.error);
  clients[idx] = again; others[0] = again;
  assert.deepEqual(again.state.hand.map((i) => i.id), handBefore);

  for (const c of others) assert.equal((await c.send('round:submit', { imageId: c.state.hand[0].id })).ok, true);
  await waitFor(() => st.state.phase === 'VOTING_PHASE');

  // لا أحد غير الراوي تلقى رابط صورة الراوي قبل الكشف، ولا أي هوية أصحاب قبل النتائج
  const stUrl = st.state.table.find((c) => c.cardId === st.state.myCardId).url;
  for (const c of others) {
    const before = c.received.filter(([ev, s]) => ev === 'state' && ['STORYTELLER_PHASE', 'PLAYERS_SUBMIT_PHASE'].includes(s.phase));
    assert.equal(JSON.stringify(before).includes(stUrl), false);
    assert.equal(JSON.stringify(c.state).includes('ownerId'), false);
  }

  assert.equal((await st.send('round:vote', { cardId: st.state.table[0].cardId })).code, 'NOT_ALLOWED');
  for (const c of others) {
    const target = c.state.table.find((t) => t.cardId !== c.state.myCardId);
    assert.equal((await c.send('round:vote', { cardId: target.cardId })).ok, true);
  }
  await waitFor(() => st.state.phase === 'SCORING_PHASE' || st.state.phase === 'GAME_OVER');
  await waitFor(() => st.state.phase === 'GAME_OVER');
  assert.equal(st.state.final.length, 4);
  manager.close();
});

test('الحمولة الخبيثة لا تكسر الخادم', async () => {
  const { io, manager } = setup();
  const c = io.connect();
  assert.equal((await c.send('room:create', null)).ok, false);
  assert.equal((await c.send('round:vote', { cardId: { $ne: 1 } })).code, 'NOT_IN_ROOM');
  const r = await c.send('room:create', { name: '<b>x</b>', rounds: 999 });
  assert.equal(r.code, 'BAD_ROUNDS');
  manager.close();
});
