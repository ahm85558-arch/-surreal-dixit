'use strict';
/** أدوات اختبار: مؤقتات سريعة، وخادم Socket.IO وهمي يحاكي الأحداث والـ ack دون شبكة. */
const { EventEmitter } = require('events');

const FAST_TIMERS = { STORYTELLER_PHASE: 0.25, PLAYERS_SUBMIT_PHASE: 0.25, VOTING_PHASE: 0.25, SCORING_PHASE: 0.05 };
const FAST_TRANSITIONS = { DEALING: 5, SHUFFLE_REVEAL: 5 };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitFor(pred, timeout = 3000, label = 'condition') {
  const t0 = Date.now();
  while (!pred()) {
    if (Date.now() - t0 > timeout) throw new Error(`timeout waiting for ${label}`);
    await sleep(2);
  }
}

class FakeSocket {
  constructor(io, id) {
    this.io = io;
    this.id = id;
    this.data = {};
    this.handlers = new Map();
    this.received = []; // [event, payload]
    this.state = null;
  }
  on(ev, fn) { this.handlers.set(ev, fn); }
  join() {}
  leave() {}
  emit(ev, payload) { // خادم ← عميل
    this.received.push([ev, payload]);
    if (ev === 'state') this.state = payload;
  }
  /** عميل ← خادم، ويعيد ردّ ack */
  send(ev, payload = {}) {
    return new Promise((resolve) => this.handlers.get(ev)(payload, resolve));
  }
  disconnect() { this.io.sockets.sockets.delete(this.id); this.handlers.get('disconnect')(); }
}

class FakeIO extends EventEmitter {
  constructor() { super(); this.sockets = { sockets: new Map() }; this.n = 0; }
  to(id) { return { emit: (ev, p) => this.sockets.sockets.get(id)?.emit(ev, p) }; }
  connect() {
    const s = new FakeSocket(this, `sock${this.n++}`);
    this.sockets.sockets.set(s.id, s);
    this.emit('connection', s);
    return s;
  }
}

module.exports = { FAST_TIMERS, FAST_TRANSITIONS, sleep, waitFor, FakeIO };
