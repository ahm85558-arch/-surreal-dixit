'use strict';
/** الأرشيف الدائم (Cloudflare KV) بخدمة وهمية تحفظ في الذاكرة. */
const test = require('node:test');
const assert = require('node:assert');
const { Archive } = require('../server/archive');
const { AiImagePool } = require('../server/aiImages');
const { waitFor } = require('./helpers');

const json = (status, body) => ({ ok: status < 300, status, headers: new Map([['content-type', 'application/json']]), json: async () => body, text: async () => JSON.stringify(body) });

/** محاكاة واجهة KV: مساحات + مفاتيح */
function fakeKv({ deny = false } = {}) {
  const spaces = new Map(); // id → Map(key → Buffer)
  const titles = new Map();
  const calls = [];
  const fn = async (url, opts = {}) => {
    calls.push({ url, opts });
    if (deny) return json(403, { success: false });
    const u = new URL(url);
    const parts = u.pathname.split('/'); // /client/v4/accounts/A/storage/kv/namespaces/...
    const i = parts.indexOf('namespaces');
    const ns = parts[i + 1];
    const method = opts.method || 'GET';
    if (!ns && method === 'GET') return json(200, { success: true, result: [...titles].map(([id, title]) => ({ id, title })) });
    if (!ns && method === 'POST') { const id = `ns${spaces.size + 1}`; spaces.set(id, new Map()); titles.set(id, JSON.parse(opts.body).title); return json(200, { success: true, result: { id } }); }
    const store = spaces.get(ns);
    if (parts[i + 2] === 'keys') return json(200, { success: true, result: [...store.keys()].map((name) => ({ name })), result_info: { cursor: '' } });
    const key = decodeURIComponent(parts[i + 3]);
    if (method === 'PUT') { store.set(key, Buffer.from(opts.body)); return json(200, { success: true }); }
    const buf = store.get(key);
    if (!buf) return json(404, {});
    return { ok: true, status: 200, headers: new Map([['content-type', 'application/octet-stream']]), arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length) };
  };
  fn.calls = calls;
  fn.spaces = spaces;
  return fn;
}
const env = { CF_ACCOUNT_ID: 'acc', CF_API_TOKEN: 'tok' };
const img = (n) => Buffer.concat([Buffer.from([0xff, 0xd8, 0xff]), Buffer.alloc(n)]);

test('ينشئ مساحة الأرشيف، يحفظ اللوحات، ويقرأها بعد إعادة التشغيل', async () => {
  const kv = fakeKv();
  const a1 = new Archive({ logger: {}, fetchImpl: kv, env });
  assert.deepEqual(await a1.init(), []);
  assert.ok(kv.calls.some((c) => c.opts.method === 'POST'), 'أنشأ المساحة');
  assert.equal(await a1.put('a0000000000aa', img(9000)), true);
  assert.equal(await a1.put('a0000000000bb', img(12000)), true);

  // "إعادة تشغيل": أرشيف جديد يجد المساحة نفسها ولا ينشئ أخرى
  const a2 = new Archive({ logger: {}, fetchImpl: kv, env });
  const ids = await a2.init();
  assert.deepEqual(ids.sort(), ['a0000000000aa', 'a0000000000bb']);
  assert.equal(kv.spaces.size, 1);
  assert.equal((await a2.get('a0000000000bb')).length, 12003);
});

test('المخزون يشمل الأرشيف فوراً، واللوحات الجديدة تُؤرشف تلقائياً', async () => {
  const kv = fakeKv();
  const seed = new Archive({ logger: {}, fetchImpl: kv, env });
  await seed.init();
  for (let i = 0; i < 20; i++) await seed.put(`a${String(i).padStart(12, '0')}`, img(9000));

  // الرسم: مزوّد وهمي يعيد صوراً
  const drawFetch = async (url, opts) => (url.includes('/ai/run/')
    ? { ok: true, status: 200, headers: new Map([['content-type', 'image/jpeg']]), arrayBuffer: async () => img(9500).buffer }
    : kv(url, opts));
  const pool = new AiImagePool({ logger: {}, fetchImpl: drawFetch, env: { ...env, AI_POOL_TARGET: '5' }, archive: new Archive({ logger: {}, fetchImpl: kv, env }) });
  pool.gapMs = 1;
  assert.equal(await pool.loadArchive(), 20);
  assert.equal(pool.size, 20, 'اللوحات المؤرشفة متاحة قبل أي رسم');
  const got = await pool.get('a000000000005');
  assert.equal(got.type, 'image/jpeg');

  pool.start();
  await waitFor(() => pool.archive.entries.size === 25, 5000, 'archived new');
  assert.equal(pool.size, 25);
});

test('الرمز بلا صلاحية KV: الأرشيف يتوقف بهدوء واللعبة تكمل', async () => {
  const a = new Archive({ logger: {}, fetchImpl: fakeKv({ deny: true }), env });
  assert.deepEqual(await a.init(), []);
  assert.equal(a.enabled, false);
  assert.equal(await a.put('a0000000000aa', img(9000)), false);
});

test('ذاكرة محدودة: تُحرَّر أقدم اللوحات المؤرشفة وتُجلب عند الحاجة', async () => {
  const kv = fakeKv();
  const seed = new Archive({ logger: {}, fetchImpl: kv, env });
  await seed.init();
  for (let i = 0; i < 6; i++) await seed.put(`a${String(i).padStart(12, '0')}`, img(9000));
  const pool = new AiImagePool({ logger: {}, fetchImpl: kv, env: { ...env, AI_MEM_CACHE: '2' }, archive: new Archive({ logger: {}, fetchImpl: kv, env }) });
  await pool.loadArchive();
  for (let i = 0; i < 6; i++) assert.ok(await pool.get(`a${String(i).padStart(12, '0')}`));
  const inMemory = [...pool.images.values()].filter((e) => e.buf).length;
  assert.equal(inMemory, 2);
  assert.ok(await pool.get('a000000000000'), 'تُجلب من جديد من الأرشيف');
});
