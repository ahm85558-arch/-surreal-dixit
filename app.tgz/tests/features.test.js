'use strict';
/** الإعدادات الجديدة: نمط الصور، مدة التصويت وتمديدها، والتفاعل بالإيموجي. */
const test = require('node:test');
const assert = require('node:assert');
const { Room, PHASES } = require('../server/Room');
const { ImageProvider } = require('../server/imageProvider');
const { RoomManager } = require('../server/RoomManager');
const { registerSocketHandlers } = require('../server/socketHandlers');
const { generateDreamSVG } = require('../server/dreamArt');
const { FAST_TRANSITIONS, waitFor, FakeIO } = require('./helpers');

const TIMERS = { STORYTELLER_PHASE: 5, PLAYERS_SUBMIT_PHASE: 5, VOTING_PHASE: 5, SCORING_PHASE: 5 };

test('الصور الجادة افتراضياً، والمضحكة باختيار المضيف', async () => {
  const room = new Room('ABCDEF', { imageProvider: new ImageProvider({ logger: {} }), timers: TIMERS, transitions: FAST_TRANSITIONS });
  const ps = ['أ', 'ب', 'ج'].map((n, i) => room.addPlayer(n, `s${i}`));
  assert.equal(room.imageStyle, 'serious');
  assert.throws(() => room.updateSettings(ps[1].id, { imageStyle: 'playful' }), { code: 'NOT_HOST' });
  assert.throws(() => room.updateSettings(ps[0].id, { imageStyle: 'x' }), { code: 'BAD_STYLE' });
  room.startGame(ps[0].id);
  await waitFor(() => room.phase === PHASES.STORYTELLER_PHASE);
  assert.ok(room.hands.get(ps[0].id).every((i) => /^s[0-9a-f]{12}$/.test(i.id)));
  room.updateSettings(ps[0].id, { imageStyle: 'playful' }); // مسموح أثناء اللعب، يسري من الجولة التالية
  assert.equal(room.imageStyle, 'playful');
  assert.match(generateDreamSVG('s0123456789ab'), /^<svg/);
  room.destroy();
});

test('مدة التصويت يضبطها المضيف، ويمكنه تمديدها أثناء التصويت', async () => {
  const room = new Room('ABCDEF', { imageProvider: new ImageProvider({ logger: {} }), timers: TIMERS, transitions: FAST_TRANSITIONS, votingSeconds: 60 });
  const ps = ['أ', 'ب', 'ج'].map((n, i) => room.addPlayer(n, `s${i}`));
  assert.equal(room.votingSeconds, 60);
  assert.throws(() => room.updateSettings(ps[0].id, { votingSeconds: 7 }), { code: 'BAD_VOTING_TIME' });
  room.updateSettings(ps[0].id, { votingSeconds: 90 });
  room.startGame(ps[0].id);
  await waitFor(() => room.phase === PHASES.STORYTELLER_PHASE);
  const st = room.storytellerId;
  room.storytellerSubmit(st, room.hands.get(st)[0].id, 'صمت طويل');
  ps.filter((p) => p.id !== st).forEach((p) => room.playerSubmit(p.id, room.hands.get(p.id)[0].id));
  await waitFor(() => room.phase === PHASES.VOTING_PHASE);
  assert.equal(room.phaseSeconds, 90);
  const before = room.deadline;
  room.extendVoting(ps[0].id);
  assert.equal(room.deadline - before, 15000);
  assert.equal(room.viewFor(ps[1].id).phaseSeconds, 105);
  for (let i = 0; i < 7; i++) room.extendVoting(ps[0].id); // المجموع 120 ثانية
  assert.throws(() => room.extendVoting(ps[0].id), { code: 'EXTEND_LIMIT' });
  assert.throws(() => room.extendVoting(ps[1].id), { code: 'NOT_HOST' });
  room.destroy();
});

test('التفاعل بالإيموجي يصل لكل اللاعبين، ويُرفض غير المسموح', async () => {
  const io = new FakeIO();
  const manager = new RoomManager(io, new ImageProvider({ logger: {} }), { timers: TIMERS, transitions: FAST_TRANSITIONS });
  registerSocketHandlers(io, manager);
  const a = io.connect();
  const r = await a.send('room:create', { name: 'هند', votingSeconds: 45, imageStyle: 'playful' });
  assert.equal(r.ok, true, r.error);
  const b = io.connect();
  await b.send('room:join', { code: r.code, name: 'علي' });
  assert.equal(b.state.settings.votingSeconds, 45);
  assert.equal(b.state.settings.imageStyle, 'playful');

  assert.equal((await a.send('room:react', { emoji: '🔥' })).ok, true);
  const got = b.received.filter(([ev]) => ev === 'reaction');
  assert.equal(got.length, 1);
  assert.equal(got[0][1].emoji, '🔥');
  assert.equal(got[0][1].name, 'هند');
  assert.equal((await a.send('room:react', { emoji: '<script>' })).code, 'BAD_REACTION');
  // الإغراق: تفاعل ثانٍ فوراً يُتجاهل
  await a.send('room:react', { emoji: '😂' });
  assert.equal(b.received.filter(([ev]) => ev === 'reaction').length, 1);
  assert.equal((await b.send('game:settings', { votingSeconds: 60 })).code, 'NOT_HOST');
  manager.close();
});
