'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { scoreRound, rankPlayers } = require('../server/scoring');

// الراوي S، اللاعبون A B C؛ البطاقات: s للراوي، a لـ A ...
const cardOwners = { s: 'S', a: 'A', b: 'B', c: 'C' };
const base = { storytellerId: 'S', storytellerCardId: 's', cardOwners, voterIds: ['A', 'B', 'C'] };

test('بعض اللاعبين أصابوا: الراوي +1 لكل مصيب، وصاحب الصورة المخادعة +1 لكل صوت', () => {
  const r = scoreRound({ ...base, votes: { A: 's', B: 's', C: 'a' } });
  assert.equal(r.outcome, 'SOME');
  assert.deepEqual(r.deltas, { S: 2, A: 1, B: 0, C: 0 });
});

test('الجميع أصاب: الراوي 0', () => {
  const r = scoreRound({ ...base, votes: { A: 's', B: 's', C: 's' } });
  assert.equal(r.outcome, 'ALL');
  assert.deepEqual(r.deltas, { S: 0, A: 0, B: 0, C: 0 });
});

test('لا أحد أصاب: الراوي +2، والخداع يُحتسب', () => {
  const r = scoreRound({ ...base, votes: { A: 'b', B: 'c', C: 'b' } });
  assert.equal(r.outcome, 'NONE');
  assert.deepEqual(r.deltas, { S: 2, A: 0, B: 2, C: 1 });
});

test('صوت على البطاقة الخاصة أو بطاقة محذوفة لا يُحتسب', () => {
  const r = scoreRound({ ...base, votes: { A: 'a', B: 'zzz', C: 's' } });
  // المصوّت الصالح الوحيد C أصاب → الجميع (من الأصوات الصالحة) أصاب
  assert.equal(r.outcome, 'ALL');
  assert.equal(r.deltas.S, 0);
});

test('لا أصوات صالحة: جولة ملغاة بلا نقاط', () => {
  const r = scoreRound({ ...base, votes: {} });
  assert.equal(r.outcome, 'VOID');
  assert.equal(r.deltas.S, 0);
});

test('الترتيب النهائي مع التعادل', () => {
  const ranked = rankPlayers([
    { id: 'a', score: 5, joinOrder: 0 }, { id: 'b', score: 7, joinOrder: 1 },
    { id: 'c', score: 5, joinOrder: 2 }, { id: 'd', score: 1, joinOrder: 3 },
  ]);
  assert.deepEqual(ranked.map((p) => [p.id, p.rank]), [['b', 1], ['a', 2], ['c', 2], ['d', 4]]);
});
