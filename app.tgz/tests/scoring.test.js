'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { scoreRound, rankPlayers } = require('../server/scoring');

// الراوي S، اللاعبون A B C؛ البطاقات: s للراوي، a لـ A ...
const cardOwners = { s: 'S', a: 'A', b: 'B', c: 'C' };
const base = { storytellerId: 'S', storytellerCardId: 's', cardOwners, voterIds: ['A', 'B', 'C'] };

test('عرفها بعضهم: الراوي +3، وكل من عرفها +3، وصاحب الصورة المخادعة +1 لكل صوت', () => {
  const r = scoreRound({ ...base, votes: { A: 's', B: 's', C: 'a' } });
  assert.equal(r.outcome, 'SOME');
  assert.deepEqual(r.deltas, { S: 3, A: 4, B: 3, C: 0 });
});

test('عرفها الجميع: الراوي 0، والباقون +2', () => {
  const r = scoreRound({ ...base, votes: { A: 's', B: 's', C: 's' } });
  assert.equal(r.outcome, 'ALL');
  assert.deepEqual(r.deltas, { S: 0, A: 2, B: 2, C: 2 });
});

test('لم يعرفها أحد: الراوي 0، والباقون +2، ونقاط الخداع تُضاف', () => {
  const r = scoreRound({ ...base, votes: { A: 'b', B: 'c', C: 'b' } });
  assert.equal(r.outcome, 'NONE');
  assert.deepEqual(r.deltas, { S: 0, A: 2, B: 4, C: 3 });
});

test('صوت على البطاقة الخاصة أو بطاقة محذوفة لا يُحتسب', () => {
  const r = scoreRound({ ...base, votes: { A: 'a', B: 'zzz', C: 's' } });
  assert.equal(r.outcome, 'ALL'); // المصوّت الصالح الوحيد C أصاب
  assert.equal(r.deltas.S, 0);
});

test('لا أصوات صالحة: جولة ملغاة بلا نقاط', () => {
  const r = scoreRound({ ...base, votes: {} });
  assert.equal(r.outcome, 'VOID');
  assert.equal(r.deltas.S, 0);
  assert.equal(r.deltas.A, 0);
});

test('الترتيب النهائي مع التعادل', () => {
  const ranked = rankPlayers([
    { id: 'a', score: 5, joinOrder: 0 }, { id: 'b', score: 7, joinOrder: 1 },
    { id: 'c', score: 5, joinOrder: 2 }, { id: 'd', score: 1, joinOrder: 3 },
  ]);
  assert.deepEqual(ranked.map((p) => [p.id, p.rank]), [['b', 1], ['a', 2], ['c', 2], ['d', 4]]);
});
