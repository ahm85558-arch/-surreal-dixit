'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { Room, PHASES } = require('../server/Room');
const { ImageProvider } = require('../server/imageProvider');
const { validateDescription, validateName } = require('../server/validation');
const { FAST_TIMERS, FAST_TRANSITIONS, waitFor, sleep } = require('./helpers');

function makeRoom(opts = {}) {
  return new Room('ABCDEF', {
    imageProvider: new ImageProvider({ logger: {} }),
    timers: FAST_TIMERS, transitions: FAST_TRANSITIONS, graceMs: 60, ...opts,
  });
}
const at = (room, phase) => waitFor(() => room.phase === phase, 3000, phase);

test('الحدود: أقل من 3 يمنع البدء، واللاعب رقم 21 يُرفض', () => {
  const room = makeRoom();
  const a = room.addPlayer('أحمد', 's1');
  room.addPlayer('سارة', 's2');
  assert.throws(() => room.startGame(a.id), { code: 'NOT_ENOUGH_PLAYERS' });
  for (let i = 3; i <= 20; i++) room.addPlayer(`لاعب ${i}`, `s${i}`);
  assert.throws(() => room.addPlayer('الزائد', 'x'), { code: 'ROOM_FULL' });
  room.destroy();
});

test('عدد الجولات يُحدد عند الإنشاء، والافتراضي = عدد اللاعبين', () => {
  const r1 = makeRoom({ rounds: 7 });
  assert.equal(r1.customRounds, 7);
  const r2 = makeRoom();
  const ps = ['أ', 'ب', 'ج', 'د'].map((n, i) => r2.addPlayer(n, `s${i}`));
  r2.startGame(ps[0].id);
  assert.equal(r2.totalRounds, 4);
  r1.destroy(); r2.destroy();
});

test('جولة كاملة: توزيع وسرية وتصويت ونقاط وتناوب', async () => {
  const room = makeRoom();
  const ps = ['هند', 'علي', 'منى', 'زياد'].map((n, i) => room.addPlayer(n, `s${i}`));
  room.setRounds(ps[0].id, 2);
  room.startGame(ps[0].id);
  await at(room, PHASES.STORYTELLER_PHASE);

  const all = ps.flatMap((p) => room.hands.get(p.id).map((i) => i.id));
  assert.equal(new Set(all).size, 20, '5 صور فريدة لكل لاعب');

  const st = room.storytellerId;
  const others = ps.filter((p) => p.id !== st);
  const v = room.viewFor(others[0].id);
  assert.deepEqual(v.hand.map((i) => i.id), room.hands.get(others[0].id).map((i) => i.id));

  const stImg = room.hands.get(st)[0].id;
  assert.throws(() => room.storytellerSubmit(others[0].id, room.hands.get(others[0].id)[0].id, 'x'), { code: 'NOT_STORYTELLER' });
  assert.throws(() => room.storytellerSubmit(st, stImg, 'قطة 😺'), { code: 'BAD_DESCRIPTION' });
  room.storytellerSubmit(st, stImg, 'قهوة الصباح في الفضاء');
  assert.equal(room.phase, PHASES.PLAYERS_SUBMIT_PHASE);
  assert.equal(JSON.stringify(room.viewFor(others[0].id)).includes(stImg), false, 'صورة الراوي سرية');

  others.forEach((p) => room.playerSubmit(p.id, room.hands.get(p.id)[0].id));
  assert.equal(room.phase, PHASES.SHUFFLE_REVEAL);
  const reveal = room.viewFor(others[0].id);
  assert.equal(reveal.table.length, 4);
  assert.ok(reveal.table.every((c) => Object.keys(c).sort().join() === 'cardId,fallback,url'), 'لا هوية للأصحاب');
  await at(room, PHASES.VOTING_PHASE);

  assert.throws(() => room.vote(st, room.table[0].cardId), { code: 'NOT_ALLOWED' });
  assert.throws(() => room.vote(others[0].id, room.ownCardOf(others[0].id)), { code: 'OWN_CARD' });

  // نحفظ الأيدي واللوحات الملعوبة قبل النتائج
  const handsBefore = new Map(ps.map((p) => [p.id, room.hands.get(p.id).map((i) => i.id)]));
  const played = new Map(room.submissions);
  room.vote(others[0].id, room.storytellerCardId);
  room.vote(others[1].id, room.storytellerCardId);
  room.vote(others[2].id, room.ownCardOf(others[0].id));
  assert.equal(room.phase, PHASES.SCORING_PHASE);
  assert.equal(room.players.get(st).score, 3);
  assert.equal(room.players.get(others[0].id).score, 4); // أصاب (+3) وخدع لاعباً (+1)
  assert.equal(room.players.get(others[2].id).score, 0);

  await at(room, PHASES.STORYTELLER_PHASE);
  assert.equal(room.storytellerId, room.order[(room.order.indexOf(st) + 1) % 4], 'Round-Robin');
  // كل لاعب احتفظ بلوحاته الأربع، وأُخذت الملعوبة، وأُضيفت لوحة جديدة واحدة
  const allNow = [];
  for (const p of ps) {
    const now = room.hands.get(p.id).map((i) => i.id);
    const kept = handsBefore.get(p.id).filter((id) => id !== played.get(p.id));
    assert.equal(now.length, 5);
    assert.deepEqual(now.slice(0, 4), kept);
    assert.ok(!now.includes(played.get(p.id)));
    allNow.push(...now);
  }
  assert.equal(new Set(allNow).size, 20, 'لا تكرار بين الأيدي');
  await at(room, PHASES.GAME_OVER);
  assert.equal(room.endReason, 'COMPLETED');
  room.destroy();
});

test('انقطاع قصير داخل المهلة: يعود اللاعب ويكمل جولته بأوراقه واختياره', async () => {
  const room = makeRoom({ graceMs: 5000 });
  const ps = ['أ', 'ب', 'ج', 'د'].map((n, i) => room.addPlayer(n, `s${i}`));
  room.startGame(ps[0].id);
  await at(room, PHASES.STORYTELLER_PHASE);
  const st = room.storytellerId;
  const others = ps.filter((p) => p.id !== st);
  room.storytellerSubmit(st, room.hands.get(st)[0].id, 'شيء غريب');
  const hand = room.hands.get(others[0].id).map((i) => i.id);
  room.playerSubmit(others[0].id, hand[2]);

  room.handleDisconnect(others[0].id);
  assert.equal(room.participants.has(others[0].id), true, 'يبقى في الجولة خلال المهلة');
  room.reconnect(others[0].token, 'new-socket');
  const v = room.viewFor(others[0].id);
  assert.deepEqual(v.hand.map((i) => i.id), hand);
  assert.equal(v.mySubmission, hand[2]);
  room.destroy();
});

test('انتهاء المهلة أثناء التصويت: تُحذف صورته وتُلغى الأصوات عليها', async () => {
  const room = makeRoom({ graceMs: 20, timers: { ...FAST_TIMERS, VOTING_PHASE: 5 } });
  const ps = ['أ', 'ب', 'ج', 'د'].map((n, i) => room.addPlayer(n, `s${i}`));
  room.startGame(ps[0].id);
  await at(room, PHASES.STORYTELLER_PHASE);
  const st = room.storytellerId;
  const others = ps.filter((p) => p.id !== st);
  room.storytellerSubmit(st, room.hands.get(st)[0].id, 'شيء غريب');
  others.forEach((p) => room.playerSubmit(p.id, room.hands.get(p.id)[0].id));
  await at(room, PHASES.VOTING_PHASE);

  const leaver = others[2];
  room.vote(others[0].id, room.ownCardOf(leaver.id));
  room.handleDisconnect(leaver.id);
  await sleep(60);
  assert.equal(room.table.length, 3);
  assert.equal(room.votes.has(others[0].id), false);
  room.vote(others[0].id, room.storytellerCardId);
  room.vote(others[1].id, room.storytellerCardId);
  assert.equal(room.phase, PHASES.SCORING_PHASE);
  assert.equal(room.lastResult.outcome, 'ALL');
  assert.equal(room.players.get(st).score, 0);
  assert.equal(room.players.get(others[0].id).score, 2);

  // يعود لاحقاً بنقاطه ويشارك من الجولة القادمة
  room.reconnect(leaver.token, 'x');
  assert.equal(room.players.get(leaver.id).away, false);
  room.destroy();
});

test('انتهاء مهلة الراوي يلغي الجولة، ونزول المتاحين تحت 3 ينهي اللعبة', async () => {
  const room = makeRoom({ graceMs: 10, timers: { ...FAST_TIMERS, STORYTELLER_PHASE: 5 } });
  const ps = ['أ', 'ب', 'ج', 'د'].map((n, i) => room.addPlayer(n, `s${i}`));
  room.startGame(ps[0].id);
  await at(room, PHASES.STORYTELLER_PHASE);
  room.handleDisconnect(room.storytellerId);
  await sleep(40);
  assert.equal(room.lastResult.cancelled, true);
  const remaining = ps.filter((p) => room.players.get(p.id).connected);
  room.handleDisconnect(remaining[0].id);
  await sleep(40);
  assert.equal(room.phase, PHASES.GAME_OVER);
  assert.equal(room.endReason, 'NOT_ENOUGH_PLAYERS');
  room.destroy();
});

test('التحقق وتنقية XSS', () => {
  assert.equal(validateDescription('حلم غريب').ok, true);
  assert.equal(validateDescription('انظر www.example.com').ok, false);
  assert.equal(validateDescription('🔥').ok, false);
  assert.equal(validateDescription('ا'.repeat(121)).ok, false);
  assert.equal(validateDescription('<script>alert(1)</script>قطة').value, 'alert(1) قطة');
  assert.equal(validateName('<img src=x onerror=alert(1)>سارة').value, 'سارة');
});
