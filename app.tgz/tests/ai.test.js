'use strict';
/** مخزون لوحات الذكاء الاصطناعي بخدمة وهمية (بلا شبكة). */
const test = require('node:test');
const assert = require('node:assert');
const { AiImagePool } = require('../server/aiImages');
const { ImageProvider } = require('../server/imageProvider');
const { waitFor } = require('./helpers');

function fakeFetch({ fail = false, quotaAfter = Infinity } = {}) {
  const calls = [];
  const fn = async (url, opts) => {
    calls.push({ url, opts });
    if (calls.length > quotaAfter) return { ok: false, status: 402, headers: new Map([['content-type', 'application/json']]), arrayBuffer: async () => new ArrayBuffer(0) };
    if (fail) return { ok: false, status: 429, headers: new Map([['content-type', 'application/json']]), arrayBuffer: async () => new ArrayBuffer(0) };
    return { ok: true, status: 200, headers: new Map([['content-type', 'image/jpeg']]), arrayBuffer: async () => new Uint8Array(20_000).buffer };
  };
  fn.calls = calls;
  return fn;
}

test('المخزون يمتلئ، والتوزيع يأخذ منه مع رابط بديل لكل لوحة', async () => {
  process.env.POLLINATIONS_KEY = 'sk_test';
  process.env.AI_POOL_TARGET = '12';
  const f = fakeFetch();
  const pool = new AiImagePool({ logger: {}, fetchImpl: f });
  pool.gapMs = 1;
  pool.start();
  await waitFor(() => pool.size === 12, 5000, 'pool');
  assert.match(f.calls[0].url, /^https:\/\/gen\.pollinations\.ai\/image\//);
  assert.match(decodeURIComponent(f.calls[0].url), /style of|surrealist/);
  assert.equal(f.calls[0].opts.headers.Authorization, 'Bearer sk_test');

  const provider = new ImageProvider({ logger: {}, aiPool: pool });
  const imgs = await provider.getImages(15, new Set(), 'realistic');
  assert.equal(imgs.length, 15);
  assert.equal(new Set(imgs.map((i) => i.id)).size, 15);
  const ai = imgs.filter((i) => i.id.startsWith('a'));
  assert.equal(ai.length, 12);
  assert.ok(ai.every((i) => /^\/ai\/a[0-9a-f]{12}\.jpg$/.test(i.url) && /^\/img\/n/.test(i.fallback)));
  delete process.env.POLLINATIONS_KEY;
  delete process.env.AI_POOL_TARGET;
});

test('تعطل الخدمة: لا شيء في المخزون والتوزيع يكمل بالمرسوم', async () => {
  const pool = new AiImagePool({ logger: {}, fetchImpl: fakeFetch({ fail: true }) });
  assert.equal(await pool.generateOne(), 'fail');
  const provider = new ImageProvider({ logger: {}, aiPool: pool });
  const imgs = await provider.getImages(5, new Set(), 'realistic');
  assert.equal(imgs.length, 5);
  assert.ok(imgs.every((i) => i.id.startsWith('n')));
});

test('بدون مفتاح: الرابط القديم المجاني وطلب واحد كل ~16 ثانية', () => {
  delete process.env.POLLINATIONS_KEY;
  const pool = new AiImagePool({ logger: {}, fetchImpl: fakeFetch() });
  assert.equal(pool.concurrency, 1);
  assert.ok(pool.gapMs >= 15000);
  assert.match(pool.buildUrl('x', 1), /^https:\/\/image\.pollinations\.ai\/prompt\//);
});

test('التوليد لا يبدأ مع تشغيل الخادم، بل عند إنشاء أول غرفة', async () => {
  const { RoomManager } = require('../server/RoomManager');
  const f = fakeFetch();
  const pool = new AiImagePool({ logger: {}, fetchImpl: f });
  pool.gapMs = 1;
  pool.anonGapMs = 1;
  pool.target = 3;
  const provider = new ImageProvider({ logger: {}, aiPool: pool });
  const io = { to: () => ({ emit() {} }) };
  const manager = new RoomManager(io, provider);
  await new Promise((r) => setTimeout(r, 50));
  assert.equal(f.calls.length, 0, 'لا طلبات قبل إنشاء غرفة');
  manager.createRoom();
  await waitFor(() => pool.size === 3, 5000, 'pool after room');
  manager.close();
});

test('نفاد رصيد المفتاح (402): تحويل تلقائي للخدمة المجانية بلا مفتاح', async () => {
  const f = fakeFetch({ quotaAfter: 2 });
  process.env.POLLINATIONS_KEY = 'sk_test';
  const pool = new AiImagePool({ logger: {}, fetchImpl: f });
  delete process.env.POLLINATIONS_KEY;
  pool.gapMs = 1;
  pool.anonGapMs = 1;
  pool.target = 4;
  // بعد أول 402 تنجح الطلبات المجانية
  const orig = pool.fetch;
  pool.fetch = async (url, opts) => (url.includes('image.pollinations.ai') ? { ok: true, status: 200, headers: new Map([['content-type', 'image/jpeg']]), arrayBuffer: async () => new Uint8Array(20_000).buffer } : orig(url, opts));
  pool.start();
  await waitFor(() => pool.size === 4, 5000, 'pool via anon');
  assert.equal(pool.mode(), 'anon');
  assert.ok(pool.quotaHitAt > 0);
  pool.disabled = true;
});
