'use strict';
/** مخزون لوحات الذكاء الاصطناعي بخدمات وهمية (بلا شبكة). */
const test = require('node:test');
const assert = require('node:assert');
const { AiImagePool } = require('../server/aiImages');
const { ImageProvider } = require('../server/imageProvider');
const { waitFor } = require('./helpers');

const jpeg = () => new Uint8Array(20_000).buffer;
const reply = (status, type, body) => ({
  ok: status >= 200 && status < 300, status,
  headers: new Map([['content-type', type]]),
  arrayBuffer: async () => (body instanceof ArrayBuffer ? body : new ArrayBuffer(0)),
  json: async () => body,
  text: async () => (typeof body === 'string' ? body : JSON.stringify(body || {})),
});

/** خدمة وهمية: route(url) → استجابة */
function fakeFetch(route) {
  const calls = [];
  const fn = async (url, opts = {}) => { calls.push({ url, opts }); return route(url, opts, calls.length); };
  fn.calls = calls;
  return fn;
}
function fastPool(opts) {
  const pool = new AiImagePool({ logger: {}, ...opts });
  pool.gapMs = 1;
  pool.anonGapMs = 1;
  return pool;
}

test('Cloudflare أولاً: صورة base64 داخل JSON، والتوزيع من المخزون', async () => {
  const f = fakeFetch(() => reply(200, 'application/json', { success: true, result: { image: Buffer.alloc(20_000, 1).toString('base64') } }));
  const pool = fastPool({ fetchImpl: f, env: { CF_ACCOUNT_ID: 'acc', CF_API_TOKEN: 'tok', AI_POOL_TARGET: '12' } });
  assert.deepEqual(pool.providers, ['cloudflare', 'anon']);
  pool.start();
  await waitFor(() => pool.size === 12, 5000, 'pool');
  const c = f.calls[0];
  assert.match(c.url, /^https:\/\/api\.cloudflare\.com\/client\/v4\/accounts\/acc\/ai\/run\/@cf\/black-forest-labs\/flux-1-schnell$/);
  assert.equal(c.opts.method, 'POST');
  assert.equal(c.opts.headers.Authorization, 'Bearer tok');
  assert.match(JSON.parse(c.opts.body).prompt, /style of|surrealist/);

  const provider = new ImageProvider({ logger: {}, aiPool: pool });
  const imgs = await provider.getImages(10, new Set(), 'realistic');
  assert.equal(imgs.length, 10);
  assert.ok(imgs.every((i) => /^\/ai\/a[0-9a-f]{12}\.jpg$/.test(i.url) && i.fallback === null));
});

test('لا صور مرسومة أبداً: إن لم يكفِ المخزون تنتظر الغرفة حتى تجهز اللوحات', async () => {
  const { Room, PHASES } = require('../server/Room');
  let allow = 3; // الخدمة ترسم 3 لوحات فقط ثم "تتوقف" حتى نسمح بالمزيد
  const f = fakeFetch(() => (allow-- > 0 ? reply(200, 'image/jpeg', jpeg()) : reply(500, 'text/plain', 'busy')));
  const pool = fastPool({ fetchImpl: f, env: { AI_POOL_TARGET: '30' } });
  pool.start();
  await waitFor(() => pool.size === 3, 5000, 'pool');
  const provider = new ImageProvider({ logger: {}, aiPool: pool });
  assert.deepEqual(await provider.getImages(5, new Set(), 'realistic'), []);

  const room = new Room('ABCDEF', { imageProvider: provider, timers: { STORYTELLER_PHASE: 5, PLAYERS_SUBMIT_PHASE: 5, VOTING_PHASE: 5, SCORING_PHASE: 5 }, transitions: { DEALING: 5, SHUFFLE_REVEAL: 5 } });
  room.prepareRetryMs = 20;
  const ps = ['أ', 'ب', 'ج'].map((n, i) => room.addPlayer(n, `s${i}`));
  assert.equal(room.viewFor(ps[0].id).images.ready, 3);
  assert.throws(() => room.startGame(ps[0].id), { code: 'IMAGES_NOT_READY' });

  // نملأ المخزون جزئياً: يكفي للبدء (15) ثم تنتظر الجولة إن نقص
  for (let i = 0; i < 12; i++) pool.images.set(`a${String(i).padStart(12, '0')}`, { buf: Buffer.alloc(9000), type: 'image/jpeg' });
  room.startGame(ps[0].id);
  await waitFor(() => room.phase === PHASES.STORYTELLER_PHASE, 3000, 'dealt');
  assert.ok([...room.hands.values()].flat().every((img) => img.id.startsWith('a') && img.fallback === null));
  pool.disabled = true;
  room.destroy();
});

test('نفاد حصة Cloudflare: الانتقال للمزوّد التالي حتى منتصف الليل UTC', async () => {
  const f = fakeFetch((url, _o, n) => {
    if (url.includes('cloudflare')) return n <= 2 ? reply(200, 'image/jpeg', jpeg()) : reply(429, 'application/json', { errors: [{ message: 'daily free allocation of 10,000 neurons exceeded' }] });
    return reply(200, 'image/jpeg', jpeg());
  });
  const pool = fastPool({ fetchImpl: f, env: { CF_ACCOUNT_ID: 'a', CF_API_TOKEN: 't', POLLINATIONS_KEY: 'sk_x', AI_POOL_TARGET: '6' } });
  pool.start();
  await waitFor(() => pool.size === 6, 5000, 'pool');
  assert.ok(pool.blockedUntil.cloudflare > Date.now() + 60_000);
  assert.equal(new Date(pool.blockedUntil.cloudflare).getUTCHours(), 0);
  assert.equal(pool.mode(), 'key');
  assert.ok(f.calls.some((c) => c.url.startsWith('https://gen.pollinations.ai/')));
});

test('التوليد لا يبدأ مع تشغيل الخادم، بل عند إنشاء أول غرفة', async () => {
  const { RoomManager } = require('../server/RoomManager');
  const f = fakeFetch(() => reply(200, 'image/jpeg', jpeg()));
  const pool = fastPool({ fetchImpl: f, env: { AI_POOL_TARGET: '3' } });
  const provider = new ImageProvider({ logger: {}, aiPool: pool });
  const manager = new RoomManager({ to: () => ({ emit() {} }) }, provider);
  await new Promise((r) => setTimeout(r, 50));
  assert.equal(f.calls.length, 0, 'لا طلبات قبل إنشاء غرفة');
  manager.createRoom();
  await waitFor(() => pool.size === 3, 5000, 'pool after room');
  manager.close();
});

test('بلا أي مفاتيح: الخدمة المجانية فقط، عامل واحد وطلب كل ~16 ثانية', () => {
  const pool = new AiImagePool({ logger: {}, fetchImpl: fakeFetch(() => reply(200, 'image/jpeg', jpeg())), env: {} });
  assert.deepEqual(pool.providers, ['anon']);
  assert.equal(pool.concurrency, 1);
  assert.ok(pool.anonGapMs >= 15000);
  assert.match(pool.pollinationsUrl('x', 1, 'anon'), /^https:\/\/image\.pollinations\.ai\/prompt\//);
});
