import { useGame } from './game/GameContext.jsx';
import JoinScreen from './screens/JoinScreen.jsx';
import LobbyScreen from './screens/LobbyScreen.jsx';
import GameScreen from './screens/GameScreen.jsx';
import Toasts from './components/Toasts.jsx';
import ZoomModal from './components/ZoomModal.jsx';

export default function App() {
  const { state, connected, ready } = useGame();

  let screen;
  if (!ready) screen = <p className="container center muted" style={{ paddingTop: '30vh' }}>جارٍ الاتصال…</p>;
  else if (!state) screen = <JoinScreen />;
  else if (state.phase === 'LOBBY') screen = <LobbyScreen />;
  else screen = <GameScreen />;

  return (
    <>
      {ready && !connected && (
        <div className="conn-banner" role="alert">انقطع الاتصال. نحاول إعادة الاتصال، ومكانك محفوظ لمدة قصيرة…</div>
      )}
      {screen}
      <Toasts />
      <ZoomModal />
    </>
  );
}
