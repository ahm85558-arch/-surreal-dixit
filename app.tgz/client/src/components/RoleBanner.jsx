import { useEffect, useState } from 'react';
import { useGame, usePlayerName } from '../game/GameContext.jsx';
import { cx } from '../lib/cx.js';
import styles from './Game.module.css';

/** ماذا يُطلب مني الآن؟ tone: act (دورك) أو wait (انتظار) */
export function roleInfo(state, nameOf) {
  const { phase, me } = state;
  const st = nameOf(state.storytellerId);
  const mine = state.players.find((p) => p.id === me.id);
  if (!me.participating && !['SCORING_PHASE', 'GAME_OVER'].includes(phase)) {
    return { tone: 'wait', title: 'تشارك من الجولة القادمة', detail: 'نقاطك محفوظة. تابع الجولة الحالية.' };
  }
  switch (phase) {
    case 'DEALING':
      return { tone: 'wait', title: 'نوزّع الصور', detail: 'خمس صور سرية لكل لاعب.' };
    case 'STORYTELLER_PHASE':
      return me.isStoryteller
        ? { tone: 'act', title: 'أنت الراوي', detail: 'اختر صورة من صورك واكتب وصفاً بالكلمات فقط.' }
        : { tone: 'wait', title: `${st} هو الراوي`, detail: 'ينتظر الجميع وصفه. تأمّل صورك في الأثناء.' };
    case 'PLAYERS_SUBMIT_PHASE':
      if (me.isStoryteller) return { tone: 'wait', title: 'اللاعبون يختارون', detail: 'كل لاعب يبحث في صوره عن أقربها لوصفك.' };
      return mine?.done
        ? { tone: 'wait', title: 'أُرسلت صورتك', detail: 'يمكنك تغييرها حتى يرسل الجميع.' }
        : { tone: 'act', title: 'دورك: اختر صورة', detail: 'أي صورك تناسب وصف الراوي؟' };
    case 'SHUFFLE_REVEAL':
      return { tone: 'wait', title: 'خلطنا الصور', detail: 'لا أحد يعرف صاحب أي صورة… إلا صاحبها.' };
    case 'VOTING_PHASE':
      if (me.isStoryteller) return { tone: 'wait', title: 'الراوي لا يصوّت', detail: 'راقب من سيعرف صورتك.' };
      return mine?.done
        ? { tone: 'wait', title: 'تم التصويت', detail: 'يمكنك تغيير صوتك حتى يصوّت الجميع.' }
        : { tone: 'act', title: 'دورك: صوّت', detail: 'أي صورة هي صورة الراوي؟' };
    case 'SCORING_PHASE':
      return { tone: 'wait', title: 'النتائج', detail: 'من خدع من؟' };
    default:
      return null;
  }
}

/** شريط الدور الدائم + لافتة كبيرة عابرة عند كل انتقال مرحلة */
export default function RoleBanner() {
  const { state } = useGame();
  const nameOf = usePlayerName();
  const info = roleInfo(state, nameOf);
  const phaseKey = `${state.round}:${state.phase}`;
  const [overlayKey, setOverlayKey] = useState(null);

  useEffect(() => {
    if (!['STORYTELLER_PHASE', 'PLAYERS_SUBMIT_PHASE', 'VOTING_PHASE', 'SCORING_PHASE'].includes(state.phase)) return undefined;
    setOverlayKey(phaseKey);
    const t = setTimeout(() => setOverlayKey(null), 1700);
    return () => clearTimeout(t);
  }, [phaseKey, state.phase]);

  if (!info) return null;
  return (
    <>
      <div className={cx(styles.banner, info.tone === 'act' && styles.bannerAct)} role="status">
        <strong>{info.title}</strong>
        <span>{info.detail}</span>
      </div>
      {overlayKey === phaseKey && (
        <div className={styles.overlay} aria-hidden="true">
          <div className={cx(styles.overlayCard, info.tone === 'act' && styles.overlayAct)}>{info.title}</div>
        </div>
      )}
    </>
  );
}
