import styles from './Game.module.css';

/** فقاعة وصف الراوي — العنصر الأبرز بصرياً في كل جولة */
export default function DescriptionBubble({ text, by }) {
  if (!text) return null;
  return (
    <figure className={styles.bubble}>
      <blockquote>«{text}»</blockquote>
      {by && <figcaption>{by}</figcaption>}
    </figure>
  );
}
