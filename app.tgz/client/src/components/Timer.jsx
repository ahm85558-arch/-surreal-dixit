import { useGame, useServerNow } from '../game/GameContext.jsx';
import { cx } from '../lib/cx.js';
import styles from './Game.module.css';

/** مؤقت دائري تنازلي متزامن مع ساعة الخادم */
export default function Timer() {
  const { state } = useGame();
  const now = useServerNow();
  if (!state?.deadline) return null;
  const left = Math.max(0, Math.ceil((state.deadline - now) / 1000));
  const total = state.phaseSeconds || 60;
  return (
    <div
      className={cx(styles.timer, left <= 10 && styles.low)}
      style={{ '--p': Math.min(1, left / total) }}
      role="timer"
      aria-label={`متبقٍ ${left} ثانية`}
    >
      <span>{left}</span>
    </div>
  );
}
