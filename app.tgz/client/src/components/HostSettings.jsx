import { useGame } from '../game/GameContext.jsx';
import { cx } from '../lib/cx.js';
import styles from './HostSettings.module.css';

const STYLE_LABELS = { serious: 'لوحات جادة', playful: 'ميمز مضحكة' };

/**
 * إعدادات المضيف: مدة التصويت ونمط الصور.
 * متاحة في شاشة الانتظار وأثناء اللعب (تسري من المرحلة أو الجولة التالية).
 * غير المضيف يرى الإعدادات الحالية فقط.
 */
export default function HostSettings({ inGame = false }) {
  const { state, send } = useGame();
  const { settings, me } = state;

  if (!me.isHost) {
    return (
      <p className={cx('muted', styles.summary)}>
        التصويت {settings.votingSeconds} ثانية · {STYLE_LABELS[settings.imageStyle]}
      </p>
    );
  }

  return (
    <div className={styles.wrap}>
      <div>
        <div className={styles.label}>مدة التصويت {inGame && <span className="muted">(تسري من التصويت القادم)</span>}</div>
        <div className={styles.chips} role="radiogroup" aria-label="مدة التصويت بالثواني">
          {settings.votingChoices.map((sec) => (
            <button
              key={sec} type="button" role="radio" aria-checked={settings.votingSeconds === sec}
              className={cx(styles.chip, settings.votingSeconds === sec && styles.chipOn)}
              onClick={() => send('game:settings', { votingSeconds: sec })}
            >
              {sec}ث
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className={styles.label}>نمط الصور {inGame && <span className="muted">(يسري من الجولة القادمة)</span>}</div>
        <div className={styles.chips} role="radiogroup" aria-label="نمط الصور">
          {Object.entries(STYLE_LABELS).map(([key, label]) => (
            <button
              key={key} type="button" role="radio" aria-checked={settings.imageStyle === key}
              className={cx(styles.chip, styles.wide, settings.imageStyle === key && styles.chipOn)}
              onClick={() => send('game:settings', { imageStyle: key })}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
