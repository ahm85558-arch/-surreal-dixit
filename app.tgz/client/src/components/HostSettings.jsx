import { useGame } from '../game/GameContext.jsx';
import { cx } from '../lib/cx.js';
import styles from './HostSettings.module.css';

/**
 * إعدادات المضيف: مدة التصويت.
 * متاحة في شاشة الانتظار وأثناء اللعب (تسري من المرحلة أو الجولة التالية).
 * غير المضيف يرى الإعدادات الحالية فقط.
 */
export default function HostSettings({ inGame = false }) {
  const { state, send } = useGame();
  const { settings, me } = state;

  if (!me.isHost) {
    return (
      <p className={cx('muted', styles.summary)}>
        مدة التصويت {settings.votingSeconds} ثانية
      </p>
    );
  }

  return (
    <div className={styles.wrap}>
      <div>
        <div className={styles.label}>مدة التصويت {inGame && <span className="muted">(تسري من التصويت القادم)</span>}</div>
        <div className={styles.chips} role="radiogroup" aria-label="مدة التصويت بالثواني">
          {settings.votingChoices.map((sec) => (
            <button
              key={sec} type="button" role="radio" aria-checked={settings.votingSeconds === sec}
              className={cx(styles.chip, settings.votingSeconds === sec && styles.chipOn)}
              onClick={() => send('game:settings', { votingSeconds: sec })}
            >
              {sec}ث
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
