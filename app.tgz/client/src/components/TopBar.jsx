import { useGame } from '../game/GameContext.jsx';
import { PHASE_LABEL } from '../lib/text.js';
import Timer from './Timer.jsx';
import styles from './Game.module.css';

export default function TopBar({ boardOpen, onToggleBoard }) {
  const { state, setHelpOpen } = useGame();
  const over = state.phase === 'GAME_OVER';
  return (
    <header className={styles.topbar}>
      <div className={styles.titleBlock}>
        <div className={styles.round}>{over ? 'انتهت اللعبة' : `الجولة ${state.round} من ${state.totalRounds}`}</div>
        <div className={styles.phase}>{PHASE_LABEL[state.phase]} · غرفة <span dir="ltr">{state.code}</span></div>
      </div>
      <div className="row">
        <button type="button" className={`btn ghost small ${styles.helpBtn}`} onClick={() => setHelpOpen(true)} aria-label="طريقة اللعب">؟</button>
        <button type="button" className={`btn ghost small ${styles.boardToggle}`} onClick={onToggleBoard} aria-expanded={boardOpen} aria-controls="leaderboard">
          {boardOpen ? 'إخفاء النقاط' : 'النقاط'}
        </button>
        <Timer />
      </div>
    </header>
  );
}
