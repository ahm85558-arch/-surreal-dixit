import { useEffect, useRef } from 'react';
import { useGame } from '../game/GameContext.jsx';
import styles from './HowToPlay.module.css';

const STEPS = [
  { title: 'التوزيع', text: 'كل لاعب يستلم 5 صور سرية لا يراها غيره.' },
  { title: 'الراوي يصف', text: 'في كل جولة لاعب مختلف هو الراوي. يختار صورة من صوره ويكتب عنها وصفاً قصيراً بالكلمات: كلمة، جملة، مثل شعبي، اسم أغنية، أو شعور.' },
  { title: 'الخداع', text: 'بقية اللاعبين يقرؤون الوصف، وكل واحد يختار من صوره الصورة الأقرب له ويرسلها سراً، ليظن الآخرون أنها صورة الراوي.' },
  { title: 'الخلط والكشف', text: 'تُخلط كل الصور وتُعرض دفعة واحدة بدون أسماء أصحابها.' },
  { title: 'التصويت', text: 'كل لاعب يصوّت على الصورة التي يظنها صورة الراوي. الراوي لا يصوّت، ولا أحد يصوّت على صورته.' },
  { title: 'النتائج', text: 'تُكشف الأسماء والأصوات وتُحسب النقاط، ثم ينتقل دور الراوي للاعب التالي. الفائز صاحب أعلى نقاط بعد آخر جولة.' },
];

const SCORING = [
  { when: 'بعض اللاعبين عرفوا صورة الراوي (وليس الجميع)', who: 'الراوي ومن عرفها', pts: '3 نقاط لكل واحد' },
  { when: 'كل اللاعبين عرفوها، أو لا أحد عرفها', who: 'الراوي', pts: 'صفر، والباقون نقطتان لكل واحد' },
  { when: 'لاعب صوّت على صورتك وأنت لست الراوي', who: 'أنت', pts: 'نقطة عن كل صوت' },
];

const TIPS = [
  'أيها الراوي: السر في وصف لا واضح جداً ولا غامض جداً. يكفي أن يعرف صورتك لاعب واحد على الأقل، لكن ليس الجميع.',
  'أيها اللاعب: اختر صورة تناسب الوصف فعلاً، فكل من يُخدع بها يعطيك نقطة.',
  'تستطيع تغيير صورتك أو صوتك حتى يُنهي الجميع. وإن انتهى الوقت يختار الخادم عنك عشوائياً.',
  'انقطع اتصالك؟ ارجع خلال 30 ثانية ومكانك وصورك محفوظة.',
  'اضغط زر 😂 في زاوية الشاشة لتتفاعل مع الجميع بالإيموجي.',
  'الصور لوحات مستوحاة من أساليب رواد السريالية: دالي، ماغريت، إرنست، ميرو، كاهلو، تانغي، دي شيريكو، ورواد السريالية المصرية رمسيس يونان وكامل التلمساني وفؤاد كامل، بعناصر من ألف ليلة وليلة، يرسمها الذكاء الاصطناعي.',
  'المضيف يختار عدد الجولات ومدة التصويت، ويستطيع تمديد وقت التصويت.',
];

/** نافذة "طريقة اللعب" — تُفتح من أي شاشة */
export default function HowToPlay() {
  const { helpOpen, setHelpOpen } = useGame();
  const ref = useRef(null);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (helpOpen && !d.open) d.showModal?.();
    if (!helpOpen && d.open) d.close();
  }, [helpOpen]);

  return (
    <dialog
      ref={ref} className={styles.dialog} aria-labelledby="howto-title"
      onClose={() => setHelpOpen(false)}
      onClick={(e) => { if (e.target === ref.current) setHelpOpen(false); }}
    >
      <div className={styles.body}>
        <header className={styles.head}>
          <h2 id="howto-title">طريقة اللعب</h2>
          <button type="button" className={styles.close} onClick={() => setHelpOpen(false)} aria-label="إغلاق">×</button>
        </header>

        <p className={styles.lede}>
          لعبة تخمين وخداع من 3 إلى 20 لاعباً. الراوي يصف صورة غريبة بكلمات قليلة،
          والبقية يحاولون خداع بعضهم بصور تشبه الوصف، ثم يخمّن الجميع أي صورة هي صورة الراوي.
        </p>

        <ol className={styles.steps}>
          {STEPS.map((s, i) => (
            <li key={s.title}>
              <span className={styles.num}>{i + 1}</span>
              <div><strong>{s.title}</strong><p>{s.text}</p></div>
            </li>
          ))}
        </ol>

        <h3 className={styles.section}>النقاط</h3>
        <ul className={styles.scoring}>
          {SCORING.map((s) => (
            <li key={s.when}>
              <span className={styles.when}>{s.when}</span>
              <span className={styles.pts}><b>{s.who}:</b> {s.pts}</span>
            </li>
          ))}
        </ul>

        <h3 className={styles.section}>نصائح</h3>
        <ul className={styles.tips}>
          {TIPS.map((t) => <li key={t}>{t}</li>)}
        </ul>

        <button type="button" className="btn block" onClick={() => setHelpOpen(false)}>فهمت، يلا نلعب</button>
      </div>
    </dialog>
  );
}
