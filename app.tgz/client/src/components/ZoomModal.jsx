import { useEffect, useRef } from 'react';
import { useGame } from '../game/GameContext.jsx';
import styles from './Game.module.css';

export default function ZoomModal() {
  const { zoomSrc, zoom } = useGame();
  const ref = useRef(null);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (zoomSrc && !d.open) d.showModal?.();
    if (!zoomSrc && d.open) d.close();
  }, [zoomSrc]);

  return (
    <dialog ref={ref} className={styles.zoomDialog} onClose={() => zoom(null)} onClick={(e) => { if (e.target === ref.current) zoom(null); }}>
      {zoomSrc && <img src={zoomSrc} alt="الصورة مكبّرة" />}
      <button type="button" className="btn ghost small" onClick={() => zoom(null)}>إغلاق</button>
    </dialog>
  );
}
