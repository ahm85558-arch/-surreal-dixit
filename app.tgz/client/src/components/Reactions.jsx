import { useMemo, useState } from 'react';
import { useGame } from '../game/GameContext.jsx';
import { cx } from '../lib/cx.js';
import styles from './Reactions.module.css';

/**
 * التفاعل بالإيموجي: زر عائم يفتح لوحة الإيموجي، والتفاعلات تطفو على الشاشة
 * عند كل اللاعبين مع اسم صاحبها.
 */
export default function Reactions() {
  const { state, reactions, react } = useGame();
  const [open, setOpen] = useState(false);
  const choices = state.settings.reactions || [];

  // موضع أفقي ثابت لكل تفاعل (مشتق من معرّفه) حتى لا يقفز عند إعادة الرسم
  const floating = useMemo(() => reactions.map((r) => {
    let h = 0;
    for (const ch of r.id) h = (h * 31 + ch.charCodeAt(0)) % 1000;
    return { ...r, left: 8 + (h % 70), drift: (h % 2 ? 1 : -1) * (10 + (h % 30)) };
  }), [reactions]);

  return (
    <>
      <div className={styles.layer} aria-hidden="true">
        {floating.map((r) => (
          <div key={r.id} className={styles.float} style={{ insetInlineStart: `${r.left}%`, '--drift': `${r.drift}px` }}>
            <span className={styles.emoji}>{r.emoji}</span>
            <span className={styles.who}>{r.name}</span>
          </div>
        ))}
      </div>

      <div className={styles.dock}>
        {open && (
          <div className={styles.panel} role="group" aria-label="تفاعل">
            {choices.map((e) => (
              <button key={e} type="button" className={styles.choice} onClick={() => react(e)} aria-label={`تفاعل ${e}`}>{e}</button>
            ))}
          </div>
        )}
        <button
          type="button" className={cx(styles.toggle, open && styles.toggleOpen)}
          onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label={open ? 'إغلاق التفاعلات' : 'تفاعل بالإيموجي'}
        >
          {open ? '×' : '😂'}
        </button>
      </div>
    </>
  );
}
