import { useGame } from '../game/GameContext.jsx';
import { cx } from '../lib/cx.js';
import styles from './Game.module.css';

/** لوحة النقاط: ثابتة على الشاشات الكبيرة، وقابلة للطي على الجوال */
export default function Leaderboard({ open }) {
  const { state } = useGame();
  const showDone = ['PLAYERS_SUBMIT_PHASE', 'VOTING_PHASE'].includes(state.phase);
  const sorted = [...state.players].sort((a, b) => b.score - a.score);

  return (
    <aside id="leaderboard" className={cx(styles.board, open && styles.boardOpen)} aria-label="لوحة النقاط">
      <h3>النقاط</h3>
      <ol className={styles.boardList}>
        {sorted.map((p) => {
          const status = p.away ? 'غادر' : !p.connected ? 'يعيد الاتصال…' : null;
          return (
            <li key={p.id} className={cx(p.isStoryteller && styles.boardSt, (p.away || !p.connected) && styles.boardOff)}>
              <span className={styles.boardName}>
                {showDone && p.inRound && !p.isStoryteller && (
                  <span className={cx(styles.dot, p.done && styles.dotDone)} title={p.done ? 'أنهى' : 'لم ينهِ بعد'} />
                )}
                <span>{p.name}{p.id === state.me.id ? ' (أنت)' : ''}</span>
                {p.isStoryteller && <span className={styles.badge}>الراوي</span>}
                {status && <span className={styles.status}>{status}</span>}
              </span>
              <span className={styles.boardScore}>{p.score}</span>
            </li>
          );
        })}
      </ol>
    </aside>
  );
}
