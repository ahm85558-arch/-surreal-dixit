import { useEffect, useState } from 'react';
import { useGame } from '../game/GameContext.jsx';
import { cx } from '../lib/cx.js';
import styles from './Card.module.css';

/**
 * بطاقة صورة داخل إطار ذهبي.
 * - إن فشل تحميل الصورة الخارجية نستخدم رابط fallback المولّد تلقائياً.
 * - زر التكبير منفصل عن زر الاختيار (لا أزرار متداخلة).
 */
export default function Card({
  image, selected = false, disabled = false, dimmed = false,
  tag, tagTone = 'dark', caption, voters, onSelect, index = 0, animate = false, label,
}) {
  const { zoom } = useGame();
  const [src, setSrc] = useState(image.url);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => { setSrc(image.url); setLoaded(false); }, [image.url]);

  const onError = () => {
    if (image.fallback && src !== image.fallback) setSrc(image.fallback);
  };
  // إن تأخر تحميل اللوحة كثيراً ننتقل للبديل حتى لا تتعطل الجولة
  useEffect(() => {
    if (loaded || !image.fallback || src === image.fallback) return undefined;
    const t = setTimeout(() => setSrc(image.fallback), 15000);
    return () => clearTimeout(t);
  }, [loaded, src, image.fallback]);

  const frameClass = cx(styles.frame, selected && styles.selected, dimmed && styles.dimmed, onSelect && !disabled && styles.clickable);
  const img = <img src={src} onError={onError} onLoad={() => setLoaded(true)} alt={label || 'صورة سريالية'} draggable={false} />;

  return (
    <div className={cx(styles.wrap, animate && styles.flip)} style={{ '--i': index }}>
      {onSelect ? (
        <button type="button" className={frameClass} onClick={onSelect} disabled={disabled} aria-pressed={selected} aria-label={label}>
          {img}
        </button>
      ) : (
        <div className={frameClass}>{img}</div>
      )}
      {tag && <span className={cx(styles.tag, styles[tagTone])}>{tag}</span>}
      <button type="button" className={styles.zoom} onClick={() => zoom(src)} aria-label="تكبير الصورة">
        <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
          <circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" strokeWidth="2.4" />
          <path d="M15.5 15.5 21 21M10.5 7.5v6M7.5 10.5h6" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
        </svg>
      </button>
      {caption && <div className={styles.caption}>{caption}</div>}
      {voters?.length > 0 && (
        <div className={styles.voters} aria-label="صوّت لها">
          {voters.map((v) => <span key={v}>{v}</span>)}
        </div>
      )}
    </div>
  );
}
