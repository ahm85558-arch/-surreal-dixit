import { useGame } from '../game/GameContext.jsx';
import { cx } from '../lib/cx.js';
import styles from './Game.module.css';

export default function Toasts() {
  const { toasts } = useGame();
  return (
    <div className={styles.toasts} role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={cx(styles.toast, t.tone === 'error' && styles.toastError)}>{t.message}</div>
      ))}
    </div>
  );
}
