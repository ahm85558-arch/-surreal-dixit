import { useGame, usePlayerName } from '../../game/GameContext.jsx';
import Card from '../../components/Card.jsx';
import DescriptionBubble from '../../components/DescriptionBubble.jsx';

/** الخلط والكشف: كل الصور تنقلب دفعة واحدة، بلا أسماء أصحابها */
export default function RevealPhase() {
  const { state } = useGame();
  const nameOf = usePlayerName();
  return (
    <section className="stack">
      <DescriptionBubble text={state.description} by={`وصف ${nameOf(state.storytellerId)}`} />
      <div className="card-grid">
        {state.table.map((c, i) => (
          <Card key={c.cardId} image={c} index={i} animate
            tag={c.cardId === state.myCardId ? 'صورتك' : null} tagTone={state.me.isStoryteller ? 'pink' : 'dark'} />
        ))}
      </div>
    </section>
  );
}
