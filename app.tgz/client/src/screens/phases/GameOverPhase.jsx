import { useGame } from '../../game/GameContext.jsx';
import styles from '../Screens.module.css';

export default function GameOverPhase() {
  const { state, send, leave } = useGame();
  const winners = state.final.filter((p) => p.rank === 1);
  const title = winners.length > 1 ? `تعادل على المركز الأول: ${winners.map((w) => w.name).join(' و')}` : `الفائز: ${winners[0]?.name ?? '—'}`;

  return (
    <section className="stack">
      <div className="panel stack">
        <h2>{title}</h2>
        {state.endReason === 'NOT_ENOUGH_PLAYERS' && (
          <p className="muted">انتهت اللعبة مبكراً لأن عدد اللاعبين المتاحين أصبح أقل من {state.settings.minPlayers}.</p>
        )}
        <ol className={styles.ranking}>
          {state.final.map((p) => (
            <li key={p.id} className={p.rank === 1 ? styles.first : undefined}>
              <span className={styles.rank}>{p.rank}</span>
              <span>{p.name}{p.id === state.me.id ? ' (أنت)' : ''}</span>
              <span className={styles.points}>{p.score}</span>
            </li>
          ))}
        </ol>
      </div>
      <div className="actions">
        {state.me.isHost
          ? <button type="button" className="btn" onClick={() => send('game:restart')}>لعبة جديدة بالغرفة نفسها</button>
          : <p className="muted">بانتظار المضيف لبدء لعبة جديدة.</p>}
        <button type="button" className="btn ghost" onClick={leave}>مغادرة الغرفة</button>
      </div>
    </section>
  );
}
