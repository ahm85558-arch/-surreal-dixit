import { useGame } from '../../game/GameContext.jsx';
import styles from '../Screens.module.css';

/** توزيع الصور: لحظة انتقالية، أو انتظار رسم لوحات الجولة إن لم تكفِ بعد */
export default function DealingPhase() {
  const { state } = useGame();
  const p = state.preparing;
  return (
    <div className={`panel center ${styles.dealing}`}>
      <div className={styles.deck} aria-hidden="true"><i /><i /><i /><i /><i /></div>
      <p className="display" style={{ fontSize: '1.4rem' }}>
        {p ? `نرسم لوحات الجولة… ${p.ready} من ${p.need}` : state.round > 1 ? 'كل لاعب يأخذ لوحة جديدة بدل التي لعبها…' : 'نوزّع خمس لوحات سرية على كل لاعب…'}
      </p>
    </div>
  );
}
