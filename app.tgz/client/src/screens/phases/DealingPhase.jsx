import styles from '../Screens.module.css';

/** توزيع الصور: لحظة انتقالية قصيرة */
export default function DealingPhase() {
  return (
    <div className={`panel center ${styles.dealing}`}>
      <div className={styles.deck} aria-hidden="true"><i /><i /><i /><i /><i /></div>
      <p className="display" style={{ fontSize: '1.4rem' }}>نوزّع خمس صور سرية على كل لاعب…</p>
    </div>
  );
}
