import { useState } from 'react';
import { useGame } from '../../game/GameContext.jsx';
import Card from '../../components/Card.jsx';
import { charCount, descriptionError } from '../../lib/text.js';
import styles from '../Screens.module.css';

export default function StorytellerPhase() {
  const { state, send } = useGame();
  const [selected, setSelected] = useState(null);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const hand = state.hand || [];

  if (!state.me.isStoryteller) {
    return (
      <section className="stack">
        <p className="muted">صورك لهذه الجولة. فكّر أيها قد يطابق وصفاً غامضاً.</p>
        <div className="card-grid">{hand.map((img, i) => <Card key={img.id} image={img} index={i} />)}</div>
      </section>
    );
  }

  const max = state.settings.descriptionMax;
  const error = descriptionError(text, max);
  const len = charCount(text);
  const canSend = selected && len > 0 && !error && !busy;

  async function submit() {
    setBusy(true);
    await send('round:describe', { imageId: selected, description: text });
    setBusy(false);
  }

  return (
    <section className="stack">
      <div className="card-grid">
        {hand.map((img, i) => (
          <Card
            key={img.id} image={img} index={i} selected={selected === img.id}
            onSelect={() => setSelected(img.id)} label={`صورة رقم ${i + 1}`}
          />
        ))}
      </div>
      <div className="panel">
        <label htmlFor="desc">وصفك</label>
        <textarea
          id="desc" rows={2} value={text} maxLength={max * 2}
          placeholder="مثلاً: صباح الإثنين بعد إجازة طويلة"
          onChange={(e) => setText(e.target.value)}
        />
        <div className={styles.fieldNote}>
          <span className={styles.fieldError}>{error}</span>
          <span className={len > max ? styles.fieldError : 'muted'} dir="ltr">{len} / {max}</span>
        </div>
      </div>
      <div className="actions">
        <button type="button" className="btn" disabled={!canSend} onClick={submit}>
          {selected ? 'إرسال الوصف' : 'اختر صورة أولاً'}
        </button>
      </div>
    </section>
  );
}
