import { useState } from 'react';
import { useGame, usePlayerName } from '../../game/GameContext.jsx';
import Card from '../../components/Card.jsx';
import DescriptionBubble from '../../components/DescriptionBubble.jsx';

export default function SubmitPhase() {
  const { state, send } = useGame();
  const nameOf = usePlayerName();
  const [selected, setSelected] = useState(null);
  const hand = state.hand || [];
  const by = state.autoDescription ? `وصف تلقائي بدلاً من ${nameOf(state.storytellerId)}` : `وصف ${nameOf(state.storytellerId)}`;
  const progress = <p className="muted center">أرسل {state.progress.done} من {state.progress.total} لاعبين صورهم</p>;

  if (state.me.isStoryteller) {
    return (
      <section className="stack">
        <DescriptionBubble text={state.description} by={by} />
        {progress}
        <div className="card-grid">
          {hand.map((img, i) => (
            <Card key={img.id} image={img} index={i} dimmed={img.id !== state.mySubmission}
              tag={img.id === state.mySubmission ? 'صورتك المختارة' : null} tagTone="pink" />
          ))}
        </div>
      </section>
    );
  }

  if (!state.me.participating) {
    return <DescriptionBubble text={state.description} by={by} />;
  }

  const chosen = selected ?? state.mySubmission;
  const submitted = !!state.mySubmission && chosen === state.mySubmission;

  return (
    <section className="stack">
      <DescriptionBubble text={state.description} by={by} />
      <div className="card-grid">
        {hand.map((img, i) => (
          <Card
            key={img.id} image={img} index={i} selected={chosen === img.id}
            tag={img.id === state.mySubmission ? 'أُرسلت' : null} tagTone="cyan"
            onSelect={() => setSelected(img.id)} label={`صورة رقم ${i + 1}`}
          />
        ))}
      </div>
      {progress}
      <div className="actions">
        <button type="button" className="btn" disabled={!chosen || submitted} onClick={() => send('round:submit', { imageId: chosen })}>
          {submitted ? 'أُرسلت صورتك' : state.mySubmission ? 'تغيير الصورة المرسلة' : 'إرسال الصورة سرّاً'}
        </button>
      </div>
    </section>
  );
}
