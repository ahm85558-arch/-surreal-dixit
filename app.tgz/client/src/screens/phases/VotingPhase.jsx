import { useState } from 'react';
import { useGame, usePlayerName } from '../../game/GameContext.jsx';
import Card from '../../components/Card.jsx';
import DescriptionBubble from '../../components/DescriptionBubble.jsx';

export default function VotingPhase() {
  const { state, send } = useGame();
  const nameOf = usePlayerName();
  const [selected, setSelected] = useState(null);
  const isST = state.me.isStoryteller;
  const canVote = state.me.participating && !isST;
  const chosen = selected ?? state.myVote;
  const voted = !!state.myVote && chosen === state.myVote;

  return (
    <section className="stack">
      <DescriptionBubble text={state.description} by={`وصف ${nameOf(state.storytellerId)}`} />
      <p className="muted center">صوّت {state.progress.done} من {state.progress.total}</p>
      <div className="card-grid">
        {state.table.map((c, i) => {
          const mine = c.cardId === state.myCardId;
          return (
            <Card
              key={c.cardId} image={c} index={i}
              selected={chosen === c.cardId}
              dimmed={mine}
              tag={mine ? 'صورتك' : c.cardId === state.myVote ? 'صوتك' : null}
              tagTone={mine ? (isST ? 'pink' : 'dark') : 'cyan'}
              disabled={!canVote || mine}
              onSelect={canVote && !mine ? () => setSelected(c.cardId) : undefined}
              label={`بطاقة رقم ${i + 1}`}
            />
          );
        })}
      </div>
      {canVote && (
        <div className="actions">
          <button type="button" className="btn" disabled={!chosen || voted} onClick={() => send('round:vote', { cardId: chosen })}>
            {voted ? 'تم التصويت' : state.myVote ? 'تغيير صوتي' : 'صوّت لهذه الصورة'}
          </button>
        </div>
      )}
    </section>
  );
}
