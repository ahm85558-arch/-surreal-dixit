import { useGame, usePlayerName } from '../../game/GameContext.jsx';
import Card from '../../components/Card.jsx';
import DescriptionBubble from '../../components/DescriptionBubble.jsx';
import { playersWord, pointsWord, signed } from '../../lib/text.js';
import styles from '../Screens.module.css';

export default function ScoringPhase() {
  const { state, send } = useGame();
  const nameOf = usePlayerName();
  const r = state.result;
  const isLast = state.round >= state.totalRounds;
  const next = state.me.isHost && (
    <div className="actions">
      <button type="button" className="btn gold" onClick={() => send('round:continue')}>
        {isLast ? 'عرض النتيجة النهائية' : 'الجولة التالية'}
      </button>
    </div>
  );

  if (!r) return null;
  if (r.cancelled) {
    const why = r.reason === 'STORYTELLER_LEFT'
      ? `انقطع الراوي ${r.storytellerName} ولم يعد خلال المهلة، فأُلغيت الجولة دون نقاط.`
      : 'لم يبق في الجولة عدد كافٍ من اللاعبين، فأُلغيت دون نقاط.';
    return <section className="stack"><p className={`panel ${styles.outcome}`}>{why}</p>{next}</section>;
  }

  const n = r.correctVoterIds.length;
  const outcome = {
    NONE: `لم يعرف أحد صورة ${r.storytellerName}، فيأخذ الراوي نقطتين`,
    ALL: 'عرفها الجميع. الوصف كان واضحاً جداً، فلا نقاط للراوي',
    SOME: `عرفها ${playersWord(n)}، فيأخذ الراوي ${pointsWord(n)}`,
    VOID: 'لم تُحتسب أصوات في هذه الجولة.',
  }[r.outcome];
  const gains = Object.entries(r.deltas).filter(([, d]) => d > 0).sort((a, b) => b[1] - a[1]);
  // نفس ترتيب البطاقات أثناء التصويت (عشوائي)، وصورة الراوي مميّزة بشارة فقط
  const cards = r.cards;

  return (
    <section className="stack">
      <DescriptionBubble text={r.description} by={`وصف ${r.storytellerName}`} />
      <div className="panel stack">
        <p className={styles.outcome}>{outcome}</p>
        {gains.length ? (
          <div className={styles.gains}>
            {gains.map(([id, d]) => <span key={id}><b>{signed(d)}</b> {nameOf(id)}</span>)}
          </div>
        ) : <p className="muted">لا نقاط في هذه الجولة.</p>}
        {r.autoPicked?.length > 0 && <p className="muted">اختار الخادم تلقائياً لمن انتهى وقته: {r.autoPicked.join('، ')}</p>}
      </div>
      <div className="card-grid">
        {cards.map((c, i) => (
          <Card
            key={c.cardId} image={c} index={i} animate
            tag={c.isStoryteller ? 'صورة الراوي' : null} tagTone="pink"
            caption={c.ownerName} voters={c.voters.map((v) => v.name)}
          />
        ))}
      </div>
      {next}
    </section>
  );
}
