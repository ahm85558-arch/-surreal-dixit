import { useEffect, useState } from 'react';
import { useGame } from '../game/GameContext.jsx';
import styles from './Screens.module.css';

export default function LobbyScreen() {
  const { state, send, leave, toast } = useGame();
  const { settings, me } = state;
  const connectedCount = state.players.filter((p) => p.connected).length;
  const enough = connectedCount >= settings.minPlayers;
  const [rounds, setRounds] = useState(settings.customRounds ?? '');
  useEffect(() => { setRounds(settings.customRounds ?? ''); }, [settings.customRounds]);

  const link = `${window.location.origin}/?room=${state.code}`;
  async function share() {
    try {
      if (navigator.share) await navigator.share({ title: 'ميمز سريالية', text: `انضم لغرفتي: ${state.code}`, url: link });
      else { await navigator.clipboard.writeText(link); toast('نُسخ رابط الدعوة.'); }
    } catch { /* ألغى المستخدم المشاركة */ }
  }

  async function saveRounds() {
    const value = rounds === '' ? null : Number(rounds);
    if (value === (settings.customRounds ?? null)) return;
    const res = await send('game:setRounds', { rounds: value });
    if (!res.ok) setRounds(settings.customRounds ?? '');
  }

  const host = state.players.find((p) => p.isHost);

  return (
    <div className="container stack" style={{ maxWidth: 820 }}>
      <section className={`panel ${styles.codePanel}`}>
        <p className="muted">كود الغرفة</p>
        <div className={styles.roomCode} dir="ltr">{state.code}</div>
        <button type="button" className="btn gold small" onClick={share}>مشاركة رابط الدعوة</button>
      </section>

      <section className="panel stack">
        <div className="row spread">
          <h2>اللاعبون</h2>
          <span className={styles.count}>{state.players.length} من {settings.maxPlayers}</span>
        </div>
        <ul className={styles.playerList}>
          {state.players.map((p) => (
            <li key={p.id} style={{ opacity: p.connected ? 1 : 0.5 }}>
              <span>{p.name}{p.id === me.id ? ' (أنت)' : ''}</span>
              {p.isHost && <span className={styles.hostBadge}>المضيف</span>}
              {!p.connected && <span className="muted">يعيد الاتصال…</span>}
            </li>
          ))}
        </ul>
        {!enough && <p className="muted">تحتاج {settings.minPlayers} لاعبين متصلين على الأقل. شارك الكود مع أصدقائك.</p>}
      </section>

      {me.isHost ? (
        <section className="panel stack">
          <div className="row spread">
            <label htmlFor="lobby-rounds" style={{ margin: 0 }}>عدد الجولات</label>
            <input
              id="lobby-rounds" type="number" inputMode="numeric" min={1} max={settings.maxRounds} style={{ maxWidth: 170 }}
              value={rounds} placeholder={`تلقائي: ${state.players.length}`}
              onChange={(e) => setRounds(e.target.value)} onBlur={saveRounds}
              onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
            />
          </div>
          <button type="button" className="btn block" disabled={!enough} onClick={() => send('game:start')}>ابدأ اللعبة</button>
        </section>
      ) : (
        <p className="panel center">بانتظار {host?.name ?? 'المضيف'} ليبدأ اللعبة.</p>
      )}

      <div className="center">
        <button type="button" className="btn ghost small" onClick={leave}>مغادرة الغرفة</button>
      </div>
    </div>
  );
}
