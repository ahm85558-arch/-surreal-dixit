import { useEffect, useMemo, useState } from 'react';
import { useGame } from '../game/GameContext.jsx';
import { loadName, saveName } from '../lib/session.js';
import styles from './Screens.module.css';

const randomHex = (n) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => b.toString(16).padStart(2, '0')).join('');

export default function JoinScreen() {
  const { enter, toast, setHelpOpen } = useGame();

  // أول زيارة: نعرض طريقة اللعب تلقائياً مرة واحدة
  useEffect(() => {
    try {
      if (!localStorage.getItem('surreal-dixit:seen-help')) {
        localStorage.setItem('surreal-dixit:seen-help', '1');
        setHelpOpen(true);
      }
    } catch { /* تجاهل */ }
  }, [setHelpOpen]);
  const presetCode = useMemo(() => (new URLSearchParams(window.location.search).get('room') || '').toUpperCase().slice(0, 6), []);
  const [name, setName] = useState(loadName);
  const [code, setCode] = useState(presetCode);
  const [rounds, setRounds] = useState('');
  const [busy, setBusy] = useState(false);
  const [showCreate, setShowCreate] = useState(!presetCode);
  const gallery = useMemo(() => [0, 1, 2].map(() => `/img/n${randomHex(6)}.svg`), []);

  async function go(event) {
    if (busy) return;
    const trimmed = name.trim();
    if (!trimmed) { toast('اكتب اسماً مستعاراً أولاً.', 'error'); return; }
    saveName(trimmed);
    setBusy(true);
    const payload = event === 'room:create'
      ? { name: trimmed, rounds: rounds === '' ? null : Number(rounds) }
      : { name: trimmed, code };
    await enter(event, payload);
    setBusy(false);
  }

  return (
    <div className={`container ${styles.join}`}>
      <section className={styles.hero}>
        <h1 className={styles.title}>
          لعبة الراوي <bdi className={styles.byline}>(A7med85)</bdi>
        </h1>
        <p className={styles.lede}>
          صف صورة عبثية بكلمات قليلة. أصدقاؤك يخلطون صورهم بصورتك ثم يحاولون تخمينها.
          لا تكن واضحاً جداً، ولا غامضاً جداً.
        </p>
        <div className={styles.gallery} aria-hidden="true">
          {gallery.map((src) => <div key={src} className={styles.galleryFrame}><img src={src} alt="" /></div>)}
        </div>
      </section>

      <section className="panel stack" aria-label="الدخول إلى اللعبة">
        <div>
          <label htmlFor="name">اسمك المستعار</label>
          <input id="name" value={name} maxLength={20} autoComplete="nickname" placeholder="مثلاً: سلطان الغموض" onChange={(e) => setName(e.target.value)} />
        </div>

        {showCreate && (
          <>
            <div>
              <label htmlFor="rounds">عدد الجولات</label>
              <input id="rounds" type="number" inputMode="numeric" min={1} max={50} value={rounds} placeholder="تلقائي: جولة لكل لاعب" onChange={(e) => setRounds(e.target.value)} />
            </div>
            <button type="button" className="btn block" disabled={busy} onClick={() => go('room:create')}>إنشاء غرفة جديدة</button>
            <div className={styles.or}>أو</div>
          </>
        )}

        <div>
          <label htmlFor="code">انضم بكود الغرفة</label>
          <input
            id="code" className={styles.codeInput} value={code} maxLength={6} autoComplete="off" autoCapitalize="characters" dir="ltr"
            placeholder="ABC123" onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))}
          />
        </div>
        <button type="button" className={`btn block ${showCreate ? 'gold' : ''}`} disabled={busy || code.length !== 6} onClick={() => go('room:join')}>
          انضمام إلى الغرفة
        </button>
        {!showCreate && (
          <button type="button" className="btn ghost small" onClick={() => setShowCreate(true)}>إنشاء غرفة جديدة بدلاً من ذلك</button>
        )}

        <button type="button" className="btn ghost small" onClick={() => setHelpOpen(true)}>طريقة اللعب</button>
      </section>
    </div>
  );
}
