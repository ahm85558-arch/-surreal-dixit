import { useState } from 'react';
import { useGame } from '../game/GameContext.jsx';
import TopBar from '../components/TopBar.jsx';
import Leaderboard from '../components/Leaderboard.jsx';
import RoleBanner from '../components/RoleBanner.jsx';
import DealingPhase from './phases/DealingPhase.jsx';
import StorytellerPhase from './phases/StorytellerPhase.jsx';
import SubmitPhase from './phases/SubmitPhase.jsx';
import RevealPhase from './phases/RevealPhase.jsx';
import VotingPhase from './phases/VotingPhase.jsx';
import ScoringPhase from './phases/ScoringPhase.jsx';
import GameOverPhase from './phases/GameOverPhase.jsx';
import styles from '../components/Game.module.css';

const PHASE_VIEWS = {
  DEALING: DealingPhase,
  STORYTELLER_PHASE: StorytellerPhase,
  PLAYERS_SUBMIT_PHASE: SubmitPhase,
  SHUFFLE_REVEAL: RevealPhase,
  VOTING_PHASE: VotingPhase,
  SCORING_PHASE: ScoringPhase,
  GAME_OVER: GameOverPhase,
};

export default function GameScreen() {
  const { state } = useGame();
  const [boardOpen, setBoardOpen] = useState(false);
  const View = PHASE_VIEWS[state.phase] || DealingPhase;

  return (
    <>
      <TopBar boardOpen={boardOpen} onToggleBoard={() => setBoardOpen((o) => !o)} />
      <div className={`container ${styles.layout}`}>
        <main className={styles.main}>
          <RoleBanner />
          {/* المفتاح يعيد ضبط الاختيارات المحلية عند كل مرحلة جديدة */}
          <View key={`${state.round}:${state.phase}`} />
        </main>
        <Leaderboard open={boardOpen} />
      </div>
    </>
  );
}
