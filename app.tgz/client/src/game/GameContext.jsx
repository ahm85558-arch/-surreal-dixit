import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { socket } from '../lib/socket.js';
import { clearSession, loadSession, saveSession } from '../lib/session.js';

/**
 * سياق اللعبة: آخر "منظور" من الخادم، حالة الاتصال، إرسال الأحداث، التنبيهات، وتكبير الصور.
 * العميل لا يحسب أي منطق لعب؛ يعرض ما يرسله الخادم ويرسل النوايا فقط.
 */
const GameContext = createContext(null);
let toastSeq = 0;

function emitWithAck(event, payload) {
  return new Promise((resolve) => {
    socket.timeout(8000).emit(event, payload, (err, res) => resolve(err ? { ok: false, timeout: true } : res || { ok: false }));
  });
}

export function GameProvider({ children }) {
  const [state, setState] = useState(null);
  const [connected, setConnected] = useState(socket.connected);
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [zoomSrc, setZoomSrc] = useState(null);
  const offsetRef = useRef(0);

  const toast = useCallback((message, tone = 'info') => {
    const id = ++toastSeq;
    setToasts((list) => [...list.slice(-2), { id, message, tone }]);
    setTimeout(() => setToasts((list) => list.filter((t) => t.id !== id)), 4000);
  }, []);

  const send = useCallback(async (event, payload = {}) => {
    const res = await emitWithAck(event, payload);
    if (res.timeout) toast('لم يرد الخادم. تحقق من اتصالك وحاول مجدداً.', 'error');
    else if (!res.ok && res.error) toast(res.error, 'error');
    return res;
  }, [toast]);

  useEffect(() => {
    const onConnect = async () => {
      setConnected(true);
      const saved = loadSession();
      if (saved?.code && saved?.sessionId) {
        const res = await emitWithAck('room:rejoin', saved);
        if (!res.ok && !res.timeout) {
          clearSession();
          setState(null);
          if (res.error) toast(res.error, 'error');
        }
      }
      setReady(true);
    };
    const onDisconnect = () => setConnected(false);
    const onState = (s) => {
      offsetRef.current = s.serverNow - Date.now();
      setState(s);
    };
    const onReplaced = () => {
      setState(null);
      toast('فُتحت اللعبة في تبويب آخر، فأُغلقت هنا.', 'error');
    };

    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('state', onState);
    socket.on('session:replaced', onReplaced);
    if (socket.connected) onConnect();
    // إن تعذّر الاتصال طويلاً نعرض شاشة الانضمام مع شريط "انقطع الاتصال"
    const fallback = setTimeout(() => setReady(true), 4000);

    return () => {
      clearTimeout(fallback);
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('state', onState);
      socket.off('session:replaced', onReplaced);
    };
  }, [toast]);

  /** إنشاء غرفة أو الانضمام إليها وحفظ معرّف الجلسة */
  const enter = useCallback(async (event, payload) => {
    const res = await send(event, payload);
    if (res.ok) {
      saveSession(res);
      window.history.replaceState(null, '', `?room=${res.code}`);
    }
    return res;
  }, [send]);

  const leave = useCallback(async () => {
    await send('room:leave');
    clearSession();
    setState(null);
    window.history.replaceState(null, '', window.location.pathname);
  }, [send]);

  const serverNow = useCallback(() => Date.now() + offsetRef.current, []);

  const value = useMemo(() => ({
    state, connected, ready, toasts, zoomSrc,
    send, enter, leave, toast, serverNow,
    zoom: setZoomSrc,
  }), [state, connected, ready, toasts, zoomSrc, send, enter, leave, toast, serverNow]);

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error('useGame must be used inside GameProvider');
  return ctx;
}

/** الوقت الحالي بتوقيت الخادم، يتحدّث 4 مرات في الثانية */
export function useServerNow() {
  const { serverNow } = useGame();
  const [now, setNow] = useState(serverNow);
  useEffect(() => {
    const t = setInterval(() => setNow(serverNow()), 250);
    return () => clearInterval(t);
  }, [serverNow]);
  return now;
}

/** اسم لاعب من المعرّف */
export function usePlayerName() {
  const { state } = useGame();
  return useCallback((id) => state?.players.find((p) => p.id === id)?.name ?? '—', [state]);
}
