'use strict';
/**
 * إعدادات اللعبة المركزية. القيم الزمنية بالثواني ما لم يُذكر غير ذلك.
 */
const num = (v, d) => (v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : d);

module.exports = Object.freeze({
  PORT: num(process.env.PORT, 3000),

  // حدود الغرفة واللعب
  MIN_PLAYERS: 3,
  MAX_PLAYERS: 20,
  HAND_SIZE: 5,
  MAX_ROUNDS: 50,
  NAME_MAX: 20,
  DESCRIPTION_MAX: 120,

  // مؤقتات المراحل (ثوانٍ) — ينفّذ الخادم إجراءً تلقائياً عند انتهائها
  TIMERS: Object.freeze({
    STORYTELLER_PHASE: num(process.env.T_STORYTELLER, 60),
    PLAYERS_SUBMIT_PHASE: num(process.env.T_SUBMIT, 45),
    VOTING_PHASE: num(process.env.T_VOTING, 30),
    SCORING_PHASE: num(process.env.T_SCORING, 20),
  }),

  // مراحل انتقالية للرسوم المتحركة (ميلي ثانية)
  TRANSITIONS_MS: Object.freeze({
    DEALING: 1600,
    SHUFFLE_REVEAL: 3000,
  }),

  // خيارات يضبطها المضيف
  VOTING_CHOICES: Object.freeze([15, 20, 30, 45, 60, 90, 120]),
  VOTING_EXTEND_SECONDS: 15,
  VOTING_EXTEND_MAX: 120, // أقصى تمديد إجمالي لجولة تصويت واحدة
  IMAGE_STYLES: Object.freeze(['serious', 'playful']),

  // التفاعل بالإيموجي
  REACTIONS: Object.freeze(['😂', '😮', '🤔', '😍', '👏', '🔥', '😱', '🤯']),
  REACTION_COOLDOWN_MS: 600,

  // مهلة إعادة الاتصال: يحتفظ اللاعب بمكانه ونقاطه وأوراقه خلالها
  RECONNECT_GRACE_MS: num(process.env.RECONNECT_GRACE_MS, 30_000),
  // حذف الغرفة إن بقيت بلا لاعبين متصلين لهذه المدة
  ROOM_IDLE_TTL_MS: 10 * 60_000,

  // مصدر الصور: generated | imgflip | reddit | folder
  IMAGE_SOURCE: (process.env.IMAGE_SOURCE || 'generated').toLowerCase(),

  // حد معدل الأحداث لكل اتصال
  RATE_LIMIT: Object.freeze({ EVENTS: 30, WINDOW_MS: 5_000 }),
});
