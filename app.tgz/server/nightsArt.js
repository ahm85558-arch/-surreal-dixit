'use strict';
/**
 * "ألف ليلة وليلة سريالية" — لوحات مولّدة تستلهم أساليب رواد السريالية
 * وتمزجها بعناصر ألف ليلة وليلة (المصباح السحري، البساط الطائر، القباب والمآذن،
 * الفوانيس، الجمال، سفينة السندباد، طائر الرخ، النجمة الثمانية، الهلال، المفاتيح).
 *
 * لا تنسخ أي لوحة بعينها؛ كل صورة تركيبة أصلية تستعير "لغة" الأسلوب فقط:
 *  - dali      صحراء حلم لا نهائية، أشياء لينة تذوب، سيقان طويلة نحيلة، ظلال طويلة
 *  - magritte  سماء نهارية نقية وغيوم، أشياء مألوفة في غير مكانها، ليل داخل نهار
 *  - ernst     غابات ليلية بملمس "الفروتاج"، حلقة قمر شاحبة، طيور غامضة
 *  - miro      أشكال عضوية وألوان أساسية وخطوط سوداء رفيعة ونجوم وأهلّة
 *  - kahlo     أوراق استوائية كثيفة، أزهار زاهية، رمان وأقفاص وأشرطة
 *  - tanguy    فضاء رمادي بلا أفق، كتل عضوية ناعمة بظلال حادة
 *  - chirico   ساحات ميتافيزيقية، أقواس في ظل عميق، سماء خضراء، وحدة مقلقة
 *  - egypt     روح جماعة "الفن والحرية" المصرية: ألوان ترابية، تشظّي، عيون وشقوق
 *
 * حتمي حسب المعرّف (المعرّف نفسه عشوائي تشفيرياً).
 */

const W = 300;
const H = 400;

function hashSeed(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0;
}
function makeRng(seed) {
  let a = seed;
  const r = () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return {
    r,
    range: (x, y) => x + r() * (y - x),
    int: (x, y) => Math.floor(x + r() * (y - x + 1)),
    pick: (arr) => arr[Math.floor(r() * arr.length)],
    chance: (p) => r() < p,
  };
}
const f = (n) => Math.round(n * 10) / 10;
const g = (x, y, s, inner, rot = 0, flip = false) =>
  `<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rot)}) scale(${flip ? -f(s) : f(s)} ${f(s)})">${inner}</g>`;

/* =====================================================================
 * عناصر ألف ليلة وليلة (مرسومة حول الأصل بحجم ~100)
 * ===================================================================== */

/** المصباح السحري */
function lamp(body, trim, { flame = false, smoke = null } = {}) {
  let s = '';
  if (smoke) {
    s += `<path d="M58 -16 C80 -40 50 -60 70 -90 C88 -118 60 -140 78 -170" fill="none" stroke="${smoke}" stroke-width="14" stroke-linecap="round" opacity=".35"/>`
      + `<path d="M58 -16 C78 -38 52 -62 72 -92 C86 -116 62 -138 80 -168" fill="none" stroke="${smoke}" stroke-width="6" stroke-linecap="round" opacity=".6"/>`;
  }
  s += `<path d="M-40 -4 C-62 -12 -64 16 -38 8" fill="none" stroke="${body}" stroke-width="6" stroke-linecap="round"/>`;
  s += `<path d="M-40 0 C-40 -24 30 -24 34 -4 L58 -18 C63 -21 66 -16 61 -12 L36 8 C28 20 -30 20 -40 0Z" fill="${body}"/>`;
  s += `<path d="M-30 -6 C-10 -14 14 -12 28 -4" fill="none" stroke="${trim}" stroke-width="2.5" opacity=".7"/>`;
  s += `<ellipse cx="-2" cy="-17" rx="14" ry="4" fill="${trim}"/><path d="M-9 -18 Q-2 -34 5 -18Z" fill="${body}"/><circle cx="-2" cy="-33" r="2.5" fill="${trim}"/>`;
  s += `<path d="M-14 14 L10 14 L14 22 L-18 22Z" fill="${body}"/>`;
  if (flame) s += `<path d="M62 -16 C58 -26 64 -32 66 -40 C70 -30 74 -24 66 -15Z" fill="#ffd36b"/>`;
  return s;
}

/** البساط الطائر: مستطيل منقوش بحواف متموجة وشرّابات */
function carpet(R, colors, w = 120, h = 60, wave = 8) {
  const [base, border, motif, fringe] = colors;
  const top = `M${-w / 2} ${-h / 2} Q${-w / 4} ${-h / 2 - wave} 0 ${-h / 2} T${w / 2} ${-h / 2}`;
  const outline = `${top} L${w / 2} ${h / 2} Q${w / 4} ${h / 2 + wave} 0 ${h / 2} T${-w / 2} ${h / 2}Z`;
  let s = `<path d="${outline}" fill="${border}"/>`;
  s += `<g transform="scale(.84 .72)"><path d="${outline}" fill="${base}"/></g>`;
  s += `<path d="M0 ${-h * 0.26} L${w * 0.16} 0 L0 ${h * 0.26} L${-w * 0.16} 0Z" fill="${motif}"/>`;
  s += `<path d="M0 ${-h * 0.13} L${w * 0.08} 0 L0 ${h * 0.13} L${-w * 0.08} 0Z" fill="${border}"/>`;
  for (const sx of [-1, 1]) {
    s += `<path d="M${sx * w * 0.34} ${-h * 0.18} L${sx * w * 0.4} 0 L${sx * w * 0.34} ${h * 0.18} L${sx * w * 0.28} 0Z" fill="${motif}" opacity=".8"/>`;
    for (let i = -3; i <= 3; i++) {
      const y = (i / 3.4) * (h / 2);
      s += `<line x1="${f(sx * w / 2)}" y1="${f(y)}" x2="${f(sx * (w / 2 + 7))}" y2="${f(y + R.range(-2, 2))}" stroke="${fringe}" stroke-width="1.6"/>`;
    }
  }
  return s;
}

/** هلال */
function crescent(r, color) {
  return `<path d="M0 ${-r} A${r} ${r} 0 1 0 0 ${r} A${f(r * 0.78)} ${f(r * 0.78)} 0 1 1 0 ${-r}Z" fill="${color}" transform="rotate(-25)"/>`;
}

/** النجمة الثمانية */
function star8(r, color, inner = null) {
  const pts = [];
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2 - Math.PI / 2;
    const rr = i % 2 ? r * 0.7 : r;
    pts.push(`${f(Math.cos(a) * rr)},${f(Math.sin(a) * rr)}`);
  }
  let s = `<polygon points="${pts.join(' ')}" fill="${color}"/>`;
  if (inner) s += `<circle r="${f(r * 0.32)}" fill="${inner}"/>`;
  return s;
}

/** قبة بصلية */
const onion = (w, h) => `M${-w} 0 C${-w} ${-h * 0.45} ${-w * 0.25} ${-h * 0.6} 0 ${-h} C${w * 0.25} ${-h * 0.6} ${w} ${-h * 0.45} ${w} 0Z`;

/** قوس إسلامي مدبّب */
const archPath = (w, h) => `M${-w} 0 V${-h * 0.62} Q${-w} ${-h * 0.92} 0 ${-h} Q${w} ${-h * 0.92} ${w} ${-h * 0.62} V0Z`;

/** قصر بقبة ومئذنتين */
function palace(c, glow = null) {
  let s = `<rect x="-38" y="-40" width="76" height="40" fill="${c}"/>`;
  s += `<path d="${onion(30, 58)}" transform="translate(0 -40)" fill="${c}"/>`;
  s += `<line x1="0" y1="-98" x2="0" y2="-108" stroke="${c}" stroke-width="2"/>${g(0, -113, 0.18, crescent(24, c))}`;
  for (const x of [-52, 52]) {
    s += `<rect x="${x - 5}" y="-92" width="10" height="92" fill="${c}"/><rect x="${x - 8}" y="-70" width="16" height="4" fill="${c}"/>`;
    s += `<path d="${onion(6, 16)}" transform="translate(${x} -92)" fill="${c}"/>`;
  }
  if (glow) {
    for (const x of [-22, 0, 22]) s += `<path d="${archPath(6, 20)}" transform="translate(${x} -6)" fill="${glow}"/>`;
  }
  return s;
}

/** جمل (سيقان قابلة للإطالة على طريقة دالي) مع هودج اختياري */
function camel(c, legLen = 38, howdah = null) {
  const top = -legLen;
  let s = '';
  for (const [x, dx] of [[-20, -3], [-11, 2], [14, -2], [23, 3]]) {
    s += `<path d="M${x} ${top + 4} L${x + dx} 0" stroke="${c}" stroke-width="${legLen > 60 ? 1.8 : 3.4}" stroke-linecap="round"/>`;
  }
  s += `<ellipse cx="0" cy="${top - 6}" rx="30" ry="13" fill="${c}"/>`;
  s += `<ellipse cx="-3" cy="${top - 17}" rx="16" ry="13" fill="${c}"/>`;
  s += `<path d="M24 ${top - 10} C34 ${top - 12} 36 ${top - 30} 42 ${top - 36} L48 ${top - 32} C42 ${top - 26} 40 ${top - 8} 28 ${top - 2}Z" fill="${c}"/>`;
  s += `<ellipse cx="48" cy="${top - 36}" rx="9" ry="5" fill="${c}"/>`;
  s += `<path d="M-30 ${top - 8} q-6 8 -4 16" stroke="${c}" stroke-width="2" fill="none"/>`;
  if (howdah) {
    s += `<rect x="-16" y="${top - 44}" width="26" height="16" fill="${howdah[0]}"/>`;
    s += `<path d="${onion(15, 20)}" transform="translate(-3 ${top - 44})" fill="${howdah[1]}"/>`;
  }
  return s;
}

/** نخلة */
function palm(R, c, h = 90) {
  const bend = R.range(-18, 18);
  let s = `<path d="M-3 0 Q${f(bend * 0.4)} ${f(-h * 0.5)} ${f(bend)} ${-h} L${f(bend + 4)} ${-h} Q${f(bend * 0.4 + 5)} ${f(-h * 0.5)} 3 0Z" fill="${c}"/>`;
  for (let i = 0; i < 8; i++) {
    const a = -Math.PI / 2 + (i - 3.5) * 0.42;
    const L = R.range(30, 44);
    const ex = bend + Math.cos(a) * L, ey = -h + Math.sin(a) * L * 0.7 + 10;
    s += `<path d="M${f(bend)} ${-h} Q${f(bend + Math.cos(a) * L * 0.5)} ${f(-h + Math.sin(a) * L * 0.6 - 10)} ${f(ex)} ${f(ey)} Q${f(bend + Math.cos(a) * L * 0.5)} ${f(-h + Math.sin(a) * L * 0.6 - 3)} ${f(bend)} ${-h + 3}Z" fill="${c}"/>`;
  }
  return s;
}

/** مركب شراعي (سفينة السندباد) */
function dhow(hull, sail) {
  return `<path d="M-46 -8 L46 -14 L34 4 L-36 4Z" fill="${hull}"/>`
    + `<line x1="-4" y1="-8" x2="-10" y2="-70" stroke="${hull}" stroke-width="2"/>`
    + `<path d="M-30 -58 L22 -76 L-4 -12Z" fill="${sail}"/>`;
}

/** طائر الرخ: أجنحة ضخمة ممدودة */
const roc = (c) => `<path d="M0 -6 C-20 -24 -60 -30 -110 -10 C-70 -16 -50 -4 -40 6 C-60 4 -80 14 -96 22 C-50 16 -20 12 -6 14 L0 30 L6 14 C20 12 50 16 96 22 C80 14 60 4 40 6 C50 -4 70 -16 110 -10 C60 -30 20 -24 0 -6Z" fill="${c}"/><ellipse cx="0" cy="-10" rx="6" ry="9" fill="${c}"/>`;

/** فانوس */
function lantern(body, light) {
  return `<circle cy="0" r="30" fill="${light}" opacity=".18"/>`
    + `<path d="M-10 -26 L10 -26 L6 -34 L-6 -34Z" fill="${body}"/><circle cy="-38" r="3" fill="none" stroke="${body}" stroke-width="1.6"/>`
    + `<path d="M-12 -26 L12 -26 L16 0 L12 24 L-12 24 L-16 0Z" fill="${light}"/>`
    + `<path d="M-12 -26 L-16 0 L-12 24 M12 -26 L16 0 L12 24 M0 -26 V24 M-16 0 H16" stroke="${body}" stroke-width="2" fill="none"/>`
    + `<path d="M-12 24 L12 24 L6 32 L-6 32Z" fill="${body}"/>`;
}

/** مفتاح قديم */
const key = (c) => `<circle cx="-40" r="16" fill="none" stroke="${c}" stroke-width="7"/><rect x="-26" y="-3.5" width="70" height="7" fill="${c}"/><rect x="30" y="3" width="6" height="12" fill="${c}"/><rect x="40" y="3" width="4" height="16" fill="${c}"/>`;

/** عين */
function eye(w, iris, pupil = '#111', white = '#f4ecd8') {
  return `<path d="M${-w} 0 Q0 ${-w * 0.7} ${w} 0 Q0 ${w * 0.7} ${-w} 0Z" fill="${white}"/>`
    + `<circle r="${f(w * 0.36)}" fill="${iris}"/><circle r="${f(w * 0.16)}" fill="${pupil}"/>`;
}

/** رمانة مشقوقة بحبات كالجواهر */
function pomegranate(R, skin, seeds) {
  let s = `<circle r="40" fill="${skin}"/><path d="M-10 -38 L-6 -52 L0 -44 L6 -52 L10 -38Z" fill="${skin}"/>`;
  s += '<path d="M-26 -6 Q0 -30 26 -6 Q10 28 -4 30 Q-24 20 -26 -6Z" fill="#f6d6c2"/>';
  for (let i = 0; i < 22; i++) s += `<circle cx="${f(R.range(-18, 18))}" cy="${f(R.range(-10, 20))}" r="${f(R.range(2.5, 4.2))}" fill="${seeds}"/>`;
  return s;
}

/** قفص طيور بقبة */
function cage(c) {
  let s = `<line x1="0" y1="-78" x2="0" y2="-66" stroke="${c}" stroke-width="2"/><circle cy="-80" r="4" fill="none" stroke="${c}" stroke-width="2"/>`;
  s += `<path d="${onion(30, 30)}" transform="translate(0 -36)" fill="none" stroke="${c}" stroke-width="2.5"/>`;
  for (let i = -3; i <= 3; i++) s += `<line x1="${i * 10}" y1="-36" x2="${i * 10}" y2="20" stroke="${c}" stroke-width="1.6"/>`;
  s += `<rect x="-34" y="18" width="68" height="6" fill="${c}"/><rect x="-32" y="-38" width="64" height="4" fill="${c}"/>`;
  return s;
}

/** ساعة رملية */
const hourglass = (frame, sand) => `<rect x="-26" y="-60" width="52" height="5" fill="${frame}"/><rect x="-26" y="55" width="52" height="5" fill="${frame}"/>`
  + `<path d="M-20 -55 L20 -55 L3 0 L20 55 L-20 55 L-3 0Z" fill="#fff" opacity=".2" stroke="${frame}" stroke-width="1.5"/>`
  + `<path d="M-12 -38 L12 -38 L2 -2 L-2 -2Z" fill="${sand}"/><path d="M-14 55 Q0 30 14 55Z" fill="${sand}"/><line x1="0" y1="0" x2="0" y2="40" stroke="${sand}" stroke-width="1"/>`;

/* =====================================================================
 * أدوات الخلفية
 * ===================================================================== */
function linGrad(id, stops, vertical = true) {
  const s = stops.map(([o, c]) => `<stop offset="${o}" stop-color="${c}"/>`).join('');
  return `<linearGradient id="${id}" x1="0" y1="0" x2="${vertical ? 0 : 1}" y2="${vertical ? 1 : 0}">${s}</linearGradient>`;
}
const GRAIN = '<filter id="grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .1"/></feComponentTransfer></filter>';
const grainRect = (op = 1) => `<rect width="${W}" height="${H}" filter="url(#grain)" opacity="${op}"/>`;

function puffyCloud(R, x, y, s, fill = '#fff', shade = '#dfe8f2') {
  let c = '';
  const blobs = [[-30, 6, 18], [-12, -6, 22], [10, -10, 24], [30, 2, 18], [0, 8, 20]];
  for (const [bx, by, r] of blobs) c += `<circle cx="${bx}" cy="${by + 4}" r="${r}" fill="${shade}"/>`;
  for (const [bx, by, r] of blobs) c += `<circle cx="${bx}" cy="${by}" r="${r - 2}" fill="${fill}"/>`;
  return g(x, y, s, c);
}

function shadowOf(x, y, w, len, ang, op = 0.35, color = '#000') {
  const dx = Math.cos(ang) * len, dy = Math.sin(ang) * len * 0.25;
  return `<path d="M${f(x - w / 2)} ${f(y)} L${f(x + w / 2)} ${f(y)} L${f(x + w / 2 + dx)} ${f(y + dy)} L${f(x - w / 2 + dx)} ${f(y + dy)}Z" fill="${color}" opacity="${op}"/>`;
}

/* =====================================================================
 * الأساليب
 * ===================================================================== */
const MODES = {
  /* ---------- دالي: صحراء الحلم ---------- */
  dali(R) {
    const hz = R.range(215, 250);
    let d = `<defs>${linGrad('sky', [[0, '#153f78'], [0.6, '#7fb0d6'], [1, '#f2e2b6']])}${linGrad('gr', [[0, '#e0bf82'], [1, '#9c7040']])}${GRAIN}</defs>`;
    d += `<rect width="${W}" height="${H}" fill="url(#sky)"/>`;
    d += `<rect y="${f(hz)}" width="${W}" height="${f(H - hz)}" fill="url(#gr)"/>`;
    // جرف صخري بعيد على جانب
    const side = R.chance(0.5) ? 0 : W;
    const dir = side ? -1 : 1;
    d += `<path d="M${side} ${f(hz - 60)} Q${side + dir * 40} ${f(hz - 70)} ${side + dir * 70} ${f(hz - 30)} Q${side + dir * 100} ${f(hz - 10)} ${side + dir * 140} ${f(hz)} L${side} ${f(hz)}Z" fill="#6b4a33"/>`;
    const ang = R.range(0.1, 0.4) * (R.chance(0.5) ? 1 : -1) + (R.chance(0.5) ? 0 : Math.PI);
    const kind = R.pick(['drape', 'camels', 'lampLedge', 'drape', 'camels']);

    if (kind === 'drape') {
      // بساط لين يذوب فوق غصن شجرة ميتة، يسنده عكّاز
      const tx = R.range(70, 110), base = hz + R.range(60, 100), by = base - R.range(120, 160);
      d += shadowOf(tx, base, 8, 140, ang, 0.3);
      d += `<path d="M${f(tx - 4)} ${f(base)} Q${f(tx - 8)} ${f((base + by) / 2)} ${f(tx)} ${f(by)} L${f(tx + 5)} ${f(by)} Q${f(tx)} ${f((base + by) / 2)} ${f(tx + 4)} ${f(base)}Z" fill="#3b2a1f"/>`;
      d += `<path d="M${f(tx + 2)} ${f(by + 6)} Q${f(tx + 50)} ${f(by - 10)} ${f(tx + 110)} ${f(by + 4)}" stroke="#3b2a1f" stroke-width="4" fill="none" stroke-linecap="round"/>`;
      const bx = tx + 80, byy = by + 2;
      const drape = `M${f(bx - 55)} ${f(byy + 70)} Q${f(bx - 50)} ${f(byy - 2)} ${f(bx)} ${f(byy - 2)} Q${f(bx + 45)} ${f(byy - 2)} ${f(bx + 42)} ${f(byy + 95)} Q${f(bx + 30)} ${f(byy + 110)} ${f(bx + 26)} ${f(byy + 90)} Q${f(bx + 22)} ${f(byy + 20)} ${f(bx)} ${f(byy + 14)} Q${f(bx - 30)} ${f(byy + 20)} ${f(bx - 40)} ${f(byy + 76)}Z`;
      d += `<defs><clipPath id="drape"><path d="${drape}"/></clipPath></defs>`;
      d += `<g clip-path="url(#drape)"><rect x="0" y="0" width="${W}" height="${H}" fill="#9e2b25"/>`;
      for (let y = byy - 10; y < byy + 120; y += 16) d += `<rect x="0" y="${f(y)}" width="${W}" height="5" fill="#e3b04b" opacity=".85"/><rect x="0" y="${f(y + 8)}" width="${W}" height="2" fill="#1f3b6e"/>`;
      d += '</g>';
      d += `<path d="${drape}" fill="none" stroke="#5a1611" stroke-width="1.5"/>`;
      // عكّاز خشبي يسند طرف البساط
      d += `<path d="M${f(bx + 36)} ${f(byy + 96)} L${f(bx + 58)} ${f(base + 4)}" stroke="#7a5230" stroke-width="3"/><path d="M${f(bx + 28)} ${f(byy + 94)} L${f(bx + 44)} ${f(byy + 98)}" stroke="#7a5230" stroke-width="4" stroke-linecap="round"/>`;
    } else if (kind === 'camels') {
      // قافلة جمال بسيقان طويلة جداً
      const n = R.int(1, 3);
      for (let i = 0; i < n; i++) {
        const x = 60 + i * R.range(60, 90) + R.range(-10, 10), base = hz + R.range(40, 110);
        const legs = R.range(110, 170) * (1 - i * 0.15), s = R.range(0.6, 0.9) * (1 - i * 0.12);
        d += shadowOf(x, base, 30 * s, 160, ang, 0.28);
        d += g(x, base, s, camel('#2c1d14', legs / s, ['#9e2b25', '#e3b04b']), 0, R.chance(0.5));
      }
    } else {
      // كتلة حجرية عليها مصباح يسيل طرفه كالشمع
      const x = R.range(110, 190), base = hz + R.range(70, 110);
      d += shadowOf(x, base, 90, 160, ang, 0.3);
      d += `<rect x="${f(x - 45)}" y="${f(base - 50)}" width="90" height="50" fill="#b8925e"/><rect x="${f(x - 45)}" y="${f(base - 50)}" width="90" height="6" fill="#d9b77e"/>`;
      d += g(x - 10, base - 72, 1.15, lamp('#c9962f', '#6b4a1a'));
      d += `<path d="M${f(x + 44)} ${f(base - 74)} C${f(x + 56)} ${f(base - 74)} ${f(x + 50)} ${f(base - 50)} ${f(x + 52)} ${f(base - 20)} C${f(x + 53)} ${f(base - 6)} ${f(x + 44)} ${f(base - 6)} ${f(x + 45)} ${f(base - 30)} C${f(x + 46)} ${f(base - 50)} ${f(x + 40)} ${f(base - 62)} ${f(x + 36)} ${f(base - 68)}Z" fill="#c9962f"/>`;
    }
    if (R.chance(0.5)) d += g(R.range(200, 270), hz + R.range(15, 40), 0.35, '<circle cy="-24" r="3.2" fill="#2c1d14"/><path d="M-3.6 -20 L3.6 -20 L4.6 -6 L2 0 L-2 0 L-4.6 -6Z" fill="#2c1d14"/>');
    return d + grainRect(0.8);
  },

  /* ---------- ماغريت: نهار صافٍ وأشياء في غير مكانها ---------- */
  magritte(R) {
    let d = `<defs>${linGrad('sky', [[0, '#4f8fcf'], [1, '#bcd9ef']])}${linGrad('sea', [[0, '#27496b'], [1, '#132a40']])}</defs>`;
    d += `<rect width="${W}" height="${H}" fill="url(#sky)"/>`;
    const hz = R.range(270, 310);
    for (let i = 0; i < R.int(3, 6); i++) d += puffyCloud(R, R.range(20, 280), R.range(30, hz - 40), R.range(0.5, 1.1));
    const ground = R.pick(['sea', 'stone']);
    if (ground === 'sea') d += `<rect y="${f(hz)}" width="${W}" height="${f(H - hz)}" fill="url(#sea)"/>`;
    else {
      d += `<rect y="${f(hz)}" width="${W}" height="${f(H - hz)}" fill="#b9ab97"/>`;
      for (let y = hz + 12; y < H; y += 18) d += `<line x1="0" y1="${f(y)}" x2="${W}" y2="${f(y)}" stroke="#8e8272" stroke-width="1"/>`;
    }
    const kind = R.pick(['lamp', 'nightWindow', 'cloudCarpet', 'archSky', 'key']);
    if (kind === 'lamp') {
      d += g(150, R.range(150, 200), R.range(1.5, 1.9), lamp('#caa04a', '#6d5020'), R.range(-8, 8));
      if (ground === 'stone') d += `<ellipse cx="150" cy="${f(hz + 40)}" rx="70" ry="8" fill="#000" opacity=".2"/>`;
    } else if (kind === 'nightWindow') {
      // نافذة مشربية على حامل: داخلها ليل بهلال ونجوم، وحولها نهار
      const x = R.range(110, 190), y = hz - 20, w = 80, h = 110;
      d += `<defs><clipPath id="win"><path d="${archPath(w / 2, h)}" transform="translate(${f(x)} ${f(y)})"/></clipPath></defs>`;
      d += `<path d="M${f(x - 30)} ${f(y)} L${f(x - 44)} ${f(hz + 50)} M${f(x + 30)} ${f(y)} L${f(x + 44)} ${f(hz + 50)} M${f(x)} ${f(y)} L${f(x)} ${f(hz + 40)}" stroke="#4a3a2a" stroke-width="3"/>`;
      d += `<g clip-path="url(#win)"><rect x="0" y="0" width="${W}" height="${H}" fill="#0c1633"/>`;
      for (let i = 0; i < 30; i++) d += `<circle cx="${f(x + R.range(-w / 2, w / 2))}" cy="${f(y - R.range(0, h))}" r="${f(R.range(0.5, 1.4))}" fill="#fff"/>`;
      d += g(x + 12, y - h * 0.65, 1, crescent(14, '#f4e7b5'));
      d += '</g>';
      d += `<path d="${archPath(w / 2, h)}" transform="translate(${f(x)} ${f(y)})" fill="none" stroke="#6b4a2a" stroke-width="6"/>`;
      d += `<path d="M${f(x)} ${f(y - h)} V${f(y)} M${f(x - w / 2)} ${f(y - h * 0.45)} H${f(x + w / 2)}" stroke="#6b4a2a" stroke-width="3"/>`;
    } else if (kind === 'cloudCarpet') {
      // بساط طائر يحمل غيمة
      const x = R.range(120, 180), y = R.range(170, 220);
      d += g(x, y, 1.1, carpet(R, ['#a3322b', '#e0b04a', '#1f3d6d', '#e0b04a'], 120, 50, 7), R.range(-8, 8));
      d += puffyCloud(R, x, y - 40, 0.9);
    } else if (kind === 'archSky') {
      // قوس قائم في البحر، من خلاله سماء ليلية
      const x = 150, y = hz + 10, w = 90, h = 170;
      d += `<defs><clipPath id="arc"><path d="${archPath(w / 2, h)}" transform="translate(${x} ${f(y)})"/></clipPath></defs>`;
      d += `<path d="${archPath(w / 2 + 16, h + 16)}" transform="translate(${x} ${f(y)})" fill="#d8cbb4"/>`;
      d += `<g clip-path="url(#arc)"><rect width="${W}" height="${H}" fill="#101a3d"/>${g(x - 10, y - h * 0.7, 1, star8(9, '#f3e3a8'))}`;
      for (let i = 0; i < 25; i++) d += `<circle cx="${f(x + R.range(-w / 2, w / 2))}" cy="${f(y - R.range(0, h))}" r="${f(R.range(0.5, 1.3))}" fill="#fff"/>`;
      d += '</g>';
    } else {
      // مفتاح عملاق معلّق بين الغيوم
      d += g(150, R.range(150, 210), R.range(1.4, 1.8), key('#b98c3a'), R.range(-30, 30));
    }
    return d;
  },

  /* ---------- إرنست: غابة ليلية بملمس الفروتاج ---------- */
  ernst(R) {
    const pal = R.pick([
      { sky: ['#0b1b2b', '#23465c'], wood: '#1a1410', wood2: '#3a2c1e', ring: '#e8e2c8' },
      { sky: ['#1b0f23', '#4a2c4f'], wood: '#120b0e', wood2: '#35202a', ring: '#f0d9b0' },
      { sky: ['#0f261f', '#3b6b5a'], wood: '#0d1511', wood2: '#2b3a2c', ring: '#e6efd7' },
    ]);
    let d = `<defs>${linGrad('sky', [[0, pal.sky[0]], [1, pal.sky[1]]])}${GRAIN}`
      + '<filter id="frot" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency=".015 .22" numOctaves="3" seed="3"/><feDisplacementMap in="SourceGraphic" scale="14"/></filter></defs>';
    d += `<rect width="${W}" height="${H}" fill="url(#sky)"/>`;
    // حلقة قمر شاحبة
    const mx = R.range(80, 220), my = R.range(60, 120), mr = R.range(22, 34);
    d += `<circle cx="${f(mx)}" cy="${f(my)}" r="${f(mr)}" fill="none" stroke="${pal.ring}" stroke-width="${f(mr * 0.28)}" opacity=".9"/>`;
    const kind = R.pick(['roc', 'lantern', 'smoke', 'palace']);
    if (kind === 'roc') d += g(R.range(110, 190), R.range(120, 170), R.range(0.9, 1.2), roc('#0a0707'));
    if (kind === 'smoke') {
      for (let i = 0; i < 3; i++) {
        d += `<path d="M${f(150 + R.range(-40, 40))} 330 C${f(R.range(60, 240))} 260 ${f(R.range(60, 240))} 200 ${f(R.range(90, 210))} ${f(R.range(90, 140))}" fill="none" stroke="#9c8ec9" stroke-width="${f(R.range(8, 20))}" stroke-linecap="round" opacity=".35"/>`;
      }
    }
    // الغابة: جذوع متلاصقة بقمم مسننة، مشوّهة بملمس الفروتاج
    const top = R.range(170, 220);
    let forest = '';
    for (let x = -10; x < W + 10; x += R.range(6, 12)) {
      const h1 = top + R.range(-40, 30), w = R.range(5, 12);
      forest += `<path d="M${f(x)} ${H} L${f(x)} ${f(h1)} L${f(x + w / 2)} ${f(h1 - R.range(10, 40))} L${f(x + w)} ${f(h1)} L${f(x + w)} ${H}Z" fill="${R.chance(0.5) ? pal.wood : pal.wood2}"/>`;
    }
    for (let i = 0; i < 40; i++) {
      const y = R.range(top, H);
      forest += `<line x1="0" y1="${f(y)}" x2="${W}" y2="${f(y + R.range(-4, 4))}" stroke="${pal.wood2}" stroke-width="${f(R.range(0.5, 2))}" opacity=".6"/>`;
    }
    d += `<g filter="url(#frot)">${forest}</g>`;
    if (kind === 'lantern') d += g(R.range(90, 210), R.range(top + 40, top + 110), 0.9, lantern('#1a120c', '#f2c35b'));
    if (kind === 'palace') d += g(R.range(110, 190), top + 10, 0.55, palace('#070505', '#e8b95a'));
    if (kind === 'smoke' || R.chance(0.3)) d += g(R.range(60, 240), R.range(top + 70, 340), 0.55, lamp('#b58b3a', '#5a4418', { flame: true }));
    return d + grainRect(1);
  },

  /* ---------- ميرو: نجوم وأهلّة وألوان أساسية ---------- */
  miro(R) {
    const bg = R.pick(['#efe2c4', '#e9dcc0', '#1d3f8f', '#f3e9d2']);
    const dark = bg === '#1d3f8f';
    const ink = dark ? '#f3ead2' : '#141414';
    const cols = ['#d7261e', '#1f4fa3', '#f2c230', '#2e8b57', '#141414'].filter((c) => !(dark && c === '#1f4fa3'));
    let d = `<rect width="${W}" height="${H}" fill="${bg}"/>`;
    // خطوط رفيعة تصل "كوكبة"
    const pts = Array.from({ length: R.int(5, 8) }, () => [R.range(30, 270), R.range(40, 360)]);
    d += `<polyline points="${pts.map((p) => p.map(f).join(',')).join(' ')}" fill="none" stroke="${ink}" stroke-width="1.4"/>`;
    for (const [x, y] of pts) d += `<circle cx="${f(x)}" cy="${f(y)}" r="3" fill="${ink}"/>`;
    const items = R.int(6, 9);
    for (let i = 0; i < items; i++) {
      const x = R.range(40, 260), y = R.range(50, 350), c = R.pick(cols), s = R.range(0.9, 1.9);
      const t = R.pick(['blob', 'blob', 'crescent', 'star8', 'eye', 'asterisk', 'lamp', 'circle', 'carpet']);
      if (t === 'blob') d += g(x, y, s, `<path d="M-30 0 C-34 -24 -6 -30 6 -20 C22 -34 40 -10 26 6 C36 22 6 34 -6 20 C-22 30 -34 16 -30 0Z" fill="${c}"/>`, R.range(0, 360));
      else if (t === 'crescent') d += g(x, y, s, crescent(22, c));
      else if (t === 'star8') d += g(x, y, s * 0.8, star8(22, c, bg));
      else if (t === 'eye') d += g(x, y, s * 0.8, `<path d="M-26 0 Q0 -20 26 0 Q0 20 -26 0Z" fill="${bg}" stroke="${ink}" stroke-width="2"/><circle r="7" fill="${c}"/><circle r="3" fill="${ink}"/>`);
      else if (t === 'asterisk') d += g(x, y, s, `<path d="M-14 0 H14 M0 -14 V14 M-10 -10 L10 10 M-10 10 L10 -10" stroke="${ink}" stroke-width="2"/>`);
      else if (t === 'lamp') d += g(x, y, s * 0.7, lamp(ink, c));
      else if (t === 'circle') d += `<circle cx="${f(x)}" cy="${f(y)}" r="${f(R.range(12, 30))}" fill="${c}"/>`;
      else d += g(x, y, s * 0.5, `<rect x="-40" y="-20" width="80" height="40" fill="${c}"/><path d="M-40 -20 L40 20 M-40 20 L40 -20 M0 -20 V20" stroke="${ink}" stroke-width="2"/>`, R.range(-20, 20));
    }
    return d;
  },

  /* ---------- كاهلو: أوراق استوائية وأزهار ورمان ---------- */
  kahlo(R) {
    let d = `<rect width="${W}" height="${H}" fill="#12351f"/>`;
    const greens = ['#1f5a32', '#2e7d45', '#3f9a58', '#16472a', '#5aa86b'];
    for (let i = 0; i < 46; i++) {
      const x = R.range(-20, 320), y = R.range(-20, 420), s = R.range(0.6, 1.4), c = R.pick(greens);
      d += g(x, y, s, `<path d="M0 0 C-14 -20 -10 -46 0 -60 C10 -46 14 -20 0 0Z" fill="${c}"/><path d="M0 -4 V-56" stroke="#0e2a18" stroke-width="1" opacity=".6"/>`, R.range(0, 360));
    }
    const flowers = ['#f28c28', '#e5446d', '#f7c948', '#c9184a'];
    for (let i = 0; i < 12; i++) {
      const x = R.range(10, 290), y = R.range(10, 390), c = R.pick(flowers), r = R.range(6, 12);
      let p = '';
      for (let k = 0; k < 8; k++) { const a = (k / 8) * Math.PI * 2; p += `<ellipse cx="${f(Math.cos(a) * r)}" cy="${f(Math.sin(a) * r)}" rx="${f(r * 0.6)}" ry="${f(r * 0.35)}" transform="rotate(${f((a * 180) / Math.PI)} ${f(Math.cos(a) * r)} ${f(Math.sin(a) * r)})" fill="${c}"/>`; }
      d += g(x, y, 1, `${p}<circle r="${f(r * 0.45)}" fill="#5a2a0c"/>`);
    }
    const kind = R.pick(['pomegranate', 'cage', 'lamp']);
    // شريط زخرفي فارغ (بلا نص) يلتف حول العنصر
    const ribbon = `<path d="M-90 40 C-40 20 40 60 90 36 L96 52 C40 76 -40 36 -86 56Z" fill="#f4e3c1" stroke="#7a1f2b" stroke-width="1.5"/>`;
    if (kind === 'pomegranate') d += g(150, 200, 1.3, pomegranate(R, '#b3202e', '#e8344e') + ribbon);
    else if (kind === 'cage') {
      d += g(150, 210, 1.35, `${cage('#e0b04a')}<path d="M-8 0 C-4 -10 8 -10 10 -2 L18 -6 L12 2 C8 10 -6 10 -8 0Z" fill="#2aa7a1"/>${ribbon}`);
    } else {
      d += g(150, 210, 1.5, lamp('#d9a03a', '#7a1f2b') + ribbon);
      for (let k = 0; k < 5; k++) d += `<circle cx="${f(120 + k * 14)}" cy="${f(186 + R.range(-6, 6))}" r="6" fill="${R.pick(flowers)}"/>`;
    }
    return d;
  },

  /* ---------- تانغي: فضاء بلا أفق وكتل عضوية ---------- */
  tanguy(R) {
    const pal = R.pick([
      ['#6f7f99', '#c6c7bf', '#8d978e'],
      ['#7d6f8a', '#d3c9c0', '#9a8f90'],
      ['#5d7a86', '#c8d2cc', '#7f9791'],
    ]);
    let d = `<defs>${linGrad('bg', [[0, pal[0]], [0.55, pal[1]], [1, pal[2]]])}${GRAIN}</defs>`;
    d += `<rect width="${W}" height="${H}" fill="url(#bg)"/>`;
    const n = R.int(7, 12);
    const forms = Array.from({ length: n }, () => ({ y: R.range(150, 380) })).sort((a, b) => a.y - b.y);
    forms.forEach((fm, i) => {
      const s = 0.5 + ((fm.y - 150) / 230) * 1.5, x = R.range(20, 280), y = fm.y;
      const light = R.pick(['#e9e4da', '#d8cfc2', '#c7bba8', '#b5c2c7']), dark = '#3d3a3a';
      const id = `fg${i}`;
      d += `<defs>${linGrad(id, [[0, light], [1, '#6e6a66']], false)}</defs>`;
      d += `<ellipse cx="${f(x + 26 * s)}" cy="${f(y + 2)}" rx="${f(34 * s)}" ry="${f(5 * s)}" fill="${dark}" opacity=".45"/>`;
      const t = R.pick(['bone', 'drop', 'dome', 'spout', 'stack']);
      let shape;
      if (t === 'bone') shape = '<path d="M-10 0 C-14 -20 -26 -30 -18 -44 C-10 -52 0 -40 2 -30 C6 -44 20 -50 22 -36 C24 -24 10 -18 10 0Z"/>';
      else if (t === 'drop') shape = '<path d="M0 -60 C14 -34 22 -14 12 -2 C6 4 -6 4 -12 -2 C-22 -14 -14 -34 0 -60Z"/>';
      else if (t === 'dome') shape = `<path d="${onion(20, 50)}"/>`;
      else if (t === 'spout') shape = '<path d="M-20 0 C-22 -18 4 -22 10 -12 L30 -28 C33 -30 36 -26 32 -22 L14 -2Z"/>';
      else shape = '<ellipse cx="0" cy="-8" rx="16" ry="8"/><ellipse cx="4" cy="-22" rx="10" ry="6"/><ellipse cx="0" cy="-32" rx="5" ry="4"/>';
      d += g(x, y, s, `<g fill="url(#${id})">${shape}</g>`);
      if (i > 0 && R.chance(0.25)) d += `<line x1="${f(x)}" y1="${f(y - 20 * s)}" x2="${f(x + R.range(-60, 60))}" y2="${f(y - R.range(40, 90))}" stroke="#3d3a3a" stroke-width=".8"/>`;
    });
    return d + grainRect(0.7);
  },

  /* ---------- دي شيريكو: ساحة ميتافيزيقية بأقواس إسلامية ---------- */
  chirico(R) {
    const hz = R.range(170, 200);
    let d = `<defs>${linGrad('sky', [[0, '#1f4a3c'], [0.7, '#8fae86'], [1, '#e6dc9c']])}${linGrad('pl', [[0, '#d78f45'], [1, '#9b5a26']])}${GRAIN}</defs>`;
    d += `<rect width="${W}" height="${H}" fill="url(#sky)"/>`;
    d += `<rect y="${f(hz)}" width="${W}" height="${f(H - hz)}" fill="url(#pl)"/>`;
    const left = R.chance(0.5);
    const sx = left ? 0 : W, dir = left ? 1 : -1;
    // مئذنة بعيدة
    const mx = left ? R.range(200, 260) : R.range(40, 100);
    d += `<rect x="${f(mx - 6)}" y="${f(hz - 110)}" width="12" height="110" fill="#c9a96e"/><rect x="${f(mx - 9)}" y="${f(hz - 80)}" width="18" height="4" fill="#8e6f3e"/>`;
    d += `<path d="${onion(7, 18)}" transform="translate(${f(mx)} ${f(hz - 110)})" fill="#c9a96e"/>`;
    d += `<rect x="${f(mx - 6)}" y="${f(hz - 110)}" width="5" height="110" fill="#000" opacity=".15"/>`;
    // رواق بأقواس في منظور
    // واجهة رواق تبتعد نحو الأفق: الحافة القريبة طويلة والبعيدة قصيرة
    const nearX = sx + dir * 6, farX = sx + dir * R.range(125, 150), nearTop = hz - R.range(140, 175), farTop = hz - R.range(45, 60);
    d += `<path d="M${sx} ${f(nearTop - 10)} L${f(nearX)} ${f(nearTop)} L${f(farX)} ${f(farTop)} L${f(farX)} ${f(hz)} L${f(nearX)} ${H} L${sx} ${H}Z" fill="#e6c08a"/>`;
    d += `<path d="M${f(nearX)} ${f(nearTop)} L${f(farX)} ${f(farTop)} L${f(farX)} ${f(farTop + 8)} L${f(nearX)} ${f(nearTop + 18)}Z" fill="#b98f55"/>`;
    const n = 5;
    for (let i = 0; i < n; i++) {
      // مسافات المنظور: الأقواس القريبة أعرض
      const p0 = 1 - Math.pow(1 - i / n, 1.25), p1 = 1 - Math.pow(1 - (i + 0.62) / n, 1.25);
      const t0 = p0, t1 = p1;
      const x0 = nearX + (farX - nearX) * t0, x1 = nearX + (farX - nearX) * t1;
      const top0 = nearTop + (farTop - nearTop) * t0, bot0 = H + (hz - H) * t0;
      const top1 = nearTop + (farTop - nearTop) * t1, bot1 = H + (hz - H) * t1;
      const a0 = top0 + (bot0 - top0) * 0.28, a1 = top1 + (bot1 - top1) * 0.28;
      const mid = (x0 + x1) / 2, peak = Math.min(a0, a1) - Math.abs(x1 - x0) * 0.55;
      d += `<path d="M${f(x0)} ${f(bot0)} L${f(x0)} ${f(a0)} Q${f(x0)} ${f(peak)} ${f(mid)} ${f(peak - 4)} Q${f(x1)} ${f(peak)} ${f(x1)} ${f(a1)} L${f(x1)} ${f(bot1)}Z" fill="#1c1410"/>`;
    }
    // ظل مائل كبير يقطع الساحة
    d += `<path d="M${f(nearX)} ${H} L${f(farX)} ${f(hz)} L${f(farX + dir * 50)} ${f(hz)} L${f(sx + dir * 250)} ${H}Z" fill="#2a160a" opacity=".5"/>`;
    // أفق: مركب شراعي أو قافلة
    if (R.chance(0.5)) d += g(left ? 250 : 60, hz, 0.28, dhow('#3a2a1a', '#efe3c4'));
    else for (let i = 0; i < 4; i++) d += g((left ? 200 : 40) + i * 14, hz + 1, 0.16, camel('#3a2a1a'));
    // شخص صغير بظل طويل، وتمثال/مصباح على قاعدة
    const fx = left ? R.range(190, 250) : R.range(50, 110), fy = hz + R.range(90, 150);
    d += `<path d="M${f(fx)} ${f(fy)} L${f(fx - dir * 90)} ${f(fy + 16)}" stroke="#2a160a" stroke-width="4" opacity=".6"/>`;
    d += g(fx, fy, 0.5, '<circle cy="-24" r="3.2" fill="#1c1410"/><path d="M-3.6 -20 L3.6 -20 L4.6 -6 L2 0 L-2 0 L-4.6 -6Z" fill="#1c1410"/>');
    if (R.chance(0.6)) {
      const px = left ? R.range(170, 230) : R.range(70, 130), py = hz + R.range(40, 70);
      d += `<rect x="${f(px - 14)}" y="${f(py - 26)}" width="28" height="26" fill="#efe3c4"/><rect x="${f(px)}" y="${f(py - 26)}" width="14" height="26" fill="#000" opacity=".2"/>`;
      d += g(px, py - 34, 0.3, lamp('#6f4a24', '#e8c16a'));
    }
    return d + grainRect(0.9);
  },

  /* ---------- مصر (الفن والحرية): تشظٍّ وعيون وشقوق ---------- */
  egypt(R) {
    const pal = R.pick([
      ['#1f140e', '#5e3f28', '#c79a5b'],
      ['#141414', '#3d352c', '#b9a27a'],
      ['#26110f', '#6a2e22', '#d4a15e'],
    ]);
    let d = `<defs>${linGrad('bg', [[0, pal[0]], [1, pal[1]]])}${GRAIN}</defs>`;
    d += `<rect width="${W}" height="${H}" fill="url(#bg)"/>`;
    // شقوق
    for (let i = 0; i < 10; i++) {
      let x = R.range(0, W), y = R.range(0, H), p = `M${f(x)} ${f(y)}`;
      for (let k = 0; k < 6; k++) { x += R.range(-30, 30); y += R.range(-30, 30); p += ` L${f(x)} ${f(y)}`; }
      d += `<path d="${p}" fill="none" stroke="#000" stroke-width="${f(R.range(0.6, 1.8))}" opacity=".5"/>`;
    }
    const kind = R.pick(['sliced', 'eyeWall', 'fragments']);
    if (kind === 'sliced') {
      // مصباح مشطور إلى شرائح منزاحة
      const x = 150, y = 210;
      for (let i = 0; i < 4; i++) {
        const y0 = y - 50 + i * 26;
        d += `<defs><clipPath id="sl${i}"><rect x="0" y="${f(y0)}" width="${W}" height="24"/></clipPath></defs>`;
        d += `<g clip-path="url(#sl${i})" transform="translate(${f((i % 2 ? 1 : -1) * R.range(12, 34))} 0)">${g(x, y, 1.6, lamp(pal[2], pal[0], { flame: true }))}</g>`;
      }
    } else if (kind === 'eyeWall') {
      // كتلة حجرية تحمل عيناً مفتوحة، وهلال معلّق
      d += `<rect x="70" y="120" width="160" height="200" fill="${pal[2]}" opacity=".85"/>`;
      d += `<rect x="70" y="120" width="160" height="200" fill="none" stroke="#000" stroke-width="2" opacity=".4"/>`;
      d += g(150, 210, 1.4, eye(40, '#2c5b6e', '#0b0b0b', '#efe4cc'));
      d += g(R.range(60, 240), R.range(60, 100), 1, crescent(18, '#e8d7ae'));
    } else {
      // شظايا عناصر متناثرة: قوس، مفتاح، نجمة، عين
      d += g(R.range(80, 130), R.range(110, 170), 0.9, `<path d="${archPath(30, 90)}" fill="${pal[2]}" opacity=".9"/>`, R.range(-20, 20));
      d += g(R.range(150, 230), R.range(220, 300), 0.8, key(pal[2]), R.range(-60, 60));
      d += g(R.range(170, 240), R.range(80, 150), 1, star8(26, pal[2], pal[0]), R.range(0, 45));
      d += g(R.range(70, 140), R.range(260, 330), 0.9, eye(30, '#9a3b2a', '#0b0b0b', '#e6d6b4'), R.range(-15, 15));
    }
    return d + grainRect(1);
  },
};

const MODE_KEYS = Object.keys(MODES);

/** نقطة الدخول: SVG كامل للمعرّف */
function generateNightsSVG(id) {
  const R = makeRng(hashSeed(`nights:${id}`));
  const mode = R.pick(MODE_KEYS);
  const body = MODES[mode](R);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${body}</svg>`;
}

module.exports = { generateNightsSVG, NIGHTS_MODES: MODE_KEYS, _MODES: MODES, _makeRng: makeRng };
