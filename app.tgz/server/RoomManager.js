'use strict';
/**
 * مدير الغرف: إنشاء الغرف بأكواد فريدة، وبث منظور كل لاعب إليه وحده، وتنظيف الغرف الخاملة.
 */
const cfg = require('./config');
const { roomCode } = require('./random');
const { Room, RoomError } = require('./Room');
const { normalizeRoomCode } = require('./validation');

class RoomManager {
  /**
   * @param {{to:(id:string)=>{emit:Function}}} io خادم Socket.IO (أو بديل متوافق في الاختبارات)
   * @param {import('./imageProvider').ImageProvider} imageProvider
   * @param {object} roomOptions خيارات إضافية لكل غرفة (مؤقتات مخصّصة في الاختبارات مثلاً)
   */
  constructor(io, imageProvider, roomOptions = {}) {
    this.io = io;
    this.imageProvider = imageProvider;
    this.roomOptions = roomOptions;
    this.rooms = new Map();
    this.sweeper = setInterval(() => this.sweep(), 60_000);
    this.sweeper.unref?.();
    // تحديث عدّاد اللوحات الجاهزة لمن ينتظر (شاشة الانتظار، أو جولة تنتظر اللوحات)
    this.lastPool = -1;
    this.poolTicker = setInterval(() => this.tickImages(), 3000);
    this.poolTicker.unref?.();
  }

  createRoom({ rounds = null, votingSeconds = null, imageStyle = null } = {}) {
    let code;
    do { code = roomCode(6); } while (this.rooms.has(code));
    const room = new Room(code, {
      ...this.roomOptions,
      rounds,
      votingSeconds,
      imageStyle,
      imageProvider: this.imageProvider,
      onChange: (r) => this.broadcast(r),
      onReaction: (r, reaction) => this.broadcastReaction(r, reaction),
    });
    this.rooms.set(code, room);
    // أول غرفة تُنشأ تبدأ توليد اللوحات الواقعية (لا يُصرف الرصيد على زيارات عابرة)
    this.imageProvider.warmUp?.();
    return room;
  }

  getRoom(rawCode) {
    const code = normalizeRoomCode(rawCode);
    if (!code) throw new RoomError('BAD_CODE', 'كود الغرفة يتكون من 6 أحرف وأرقام إنجليزية.');
    const room = this.rooms.get(code);
    if (!room) throw new RoomError('ROOM_NOT_FOUND', 'لا توجد غرفة بهذا الكود. تأكد منه أو أنشئ غرفة جديدة.');
    return room;
  }

  deleteRoom(code) {
    const room = this.rooms.get(code);
    if (room) room.destroy();
    this.rooms.delete(code);
  }

  /** إرسال حالة مخصّصة لكل لاعب متصل */
  broadcast(room) {
    for (const p of room.players.values()) {
      if (p.connected && p.socketId) this.io.to(p.socketId).emit('state', room.viewFor(p.id));
    }
  }

  tickImages() {
    const st = this.imageProvider.status?.();
    if (!st?.ai || st.ready === this.lastPool) return;
    this.lastPool = st.ready;
    for (const room of this.rooms.values()) {
      if (room.phase === 'LOBBY' || (room.phase === 'DEALING' && room.preparing)) this.broadcast(room);
    }
  }

  /** التفاعلات: نفس الحدث لكل اللاعبين المتصلين */
  broadcastReaction(room, reaction) {
    for (const p of room.players.values()) {
      if (p.connected && p.socketId) this.io.to(p.socketId).emit('reaction', reaction);
    }
  }

  sweep() {
    const now = Date.now();
    for (const [code, room] of this.rooms) {
      const idle = room.connectedPlayers().length === 0 && now - room.lastActivity > cfg.ROOM_IDLE_TTL_MS;
      if (idle || room.players.size === 0) this.deleteRoom(code);
    }
  }

  stats() {
    let players = 0;
    for (const r of this.rooms.values()) players += r.connectedPlayers().length;
    return { rooms: this.rooms.size, players };
  }

  close() {
    clearInterval(this.sweeper);
    clearInterval(this.poolTicker);
    for (const code of [...this.rooms.keys()]) this.deleteRoom(code);
  }
}

module.exports = { RoomManager };
