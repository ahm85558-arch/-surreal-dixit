'use strict';
/**
 * مدير الغرف: إنشاء الغرف بأكواد فريدة، وبث منظور كل لاعب إليه وحده، وتنظيف الغرف الخاملة.
 */
const cfg = require('./config');
const { roomCode } = require('./random');
const { Room, RoomError } = require('./Room');
const { normalizeRoomCode } = require('./validation');

class RoomManager {
  /**
   * @param {{to:(id:string)=>{emit:Function}}} io خادم Socket.IO (أو بديل متوافق في الاختبارات)
   * @param {import('./imageProvider').ImageProvider} imageProvider
   * @param {object} roomOptions خيارات إضافية لكل غرفة (مؤقتات مخصّصة في الاختبارات مثلاً)
   */
  constructor(io, imageProvider, roomOptions = {}) {
    this.io = io;
    this.imageProvider = imageProvider;
    this.roomOptions = roomOptions;
    this.rooms = new Map();
    this.sweeper = setInterval(() => this.sweep(), 60_000);
    this.sweeper.unref?.();
  }

  createRoom({ rounds = null, votingSeconds = null, imageStyle = null } = {}) {
    let code;
    do { code = roomCode(6); } while (this.rooms.has(code));
    const room = new Room(code, {
      ...this.roomOptions,
      rounds,
      votingSeconds,
      imageStyle,
      imageProvider: this.imageProvider,
      onChange: (r) => this.broadcast(r),
      onReaction: (r, reaction) => this.broadcastReaction(r, reaction),
    });
    this.rooms.set(code, room);
    return room;
  }

  getRoom(rawCode) {
    const code = normalizeRoomCode(rawCode);
    if (!code) throw new RoomError('BAD_CODE', 'كود الغرفة يتكون من 6 أحرف وأرقام إنجليزية.');
    const room = this.rooms.get(code);
    if (!room) throw new RoomError('ROOM_NOT_FOUND', 'لا توجد غرفة بهذا الكود. تأكد منه أو أنشئ غرفة جديدة.');
    return room;
  }

  deleteRoom(code) {
    const room = this.rooms.get(code);
    if (room) room.destroy();
    this.rooms.delete(code);
  }

  /** إرسال حالة مخصّصة لكل لاعب متصل */
  broadcast(room) {
    for (const p of room.players.values()) {
      if (p.connected && p.socketId) this.io.to(p.socketId).emit('state', room.viewFor(p.id));
    }
  }

  /** التفاعلات: نفس الحدث لكل اللاعبين المتصلين */
  broadcastReaction(room, reaction) {
    for (const p of room.players.values()) {
      if (p.connected && p.socketId) this.io.to(p.socketId).emit('reaction', reaction);
    }
  }

  sweep() {
    const now = Date.now();
    for (const [code, room] of this.rooms) {
      const idle = room.connectedPlayers().length === 0 && now - room.lastActivity > cfg.ROOM_IDLE_TTL_MS;
      if (idle || room.players.size === 0) this.deleteRoom(code);
    }
  }

  stats() {
    let players = 0;
    for (const r of this.rooms.values()) players += r.connectedPlayers().length;
    return { rooms: this.rooms.size, players };
  }

  close() {
    clearInterval(this.sweeper);
    for (const code of [...this.rooms.keys()]) this.deleteRoom(code);
  }
}

module.exports = { RoomManager };
