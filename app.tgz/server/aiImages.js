'use strict';
/**
 * لوحات "واقعية" بالذكاء الاصطناعي بأساليب رواد السريالية وعناصر ألف ليلة وليلة.
 *
 * الفكرة: الخادم يولّد اللوحات مسبقاً في الخلفية عبر Pollinations.ai ويحتفظ بها في الذاكرة
 * (مخزون/Pool)، ثم يوزّع منها على اللاعبين من رابط الموقع نفسه (/ai/<id>.jpg).
 * لماذا في الخلفية وليس لحظة التوزيع؟ لأن توليد الصورة يستغرق ثوانٍ، والخدمة المجانية
 * تحدّ عدد الطلبات؛ فالتوليد المسبق يجعل التوزيع فورياً.
 *
 * إن نقص المخزون أو تعطلت الخدمة، يكمل الخادم تلقائياً بلوحات ألف ليلة المرسومة محلياً،
 * ولكل لوحة رابط بديل يستخدمه المتصفح إن تعذّر تحميلها. فلا تتعطل اللعبة أبداً.
 *
 * متغيرات البيئة:
 *  POLLINATIONS_KEY   مفتاح مجاني من enter.pollinations.ai (أسرع، بلا علامة مائية). اختياري.
 *  AI_MODEL           نموذج الصور (افتراضي flux)
 *  AI_POOL_TARGET     حجم المخزون المستهدف (افتراضي 200)
 *  AI_CONCURRENCY     طلبات متوازية عند وجود مفتاح (افتراضي 3)
 *  AI_DISABLED=1      لإيقاف التوليد تماماً
 */
const { randomId, pick, randInt } = require('./random');

/* ---------- الأساليب: وصف أسلوبي لكل فنان (الأسلوب لا اللوحات) ---------- */
const ARTISTS = [
  { key: 'dali', style: 'surrealist oil painting in the style of Salvador Dali, hyperrealistic detail, vast barren dreamlike plain, soft melting forms, elongated spindly legs, long dramatic shadows, clear golden Mediterranean light' },
  { key: 'magritte', style: 'surrealist oil painting in the style of Rene Magritte, crisp clean realism, calm blue sky with soft white clouds, ordinary objects in impossible situations, quiet and mysterious' },
  { key: 'ernst', style: 'surrealist painting in the style of Max Ernst, decalcomania and frottage textures, petrified dark forest, strange bird forms, eerie pale moon ring' },
  { key: 'miro', style: 'surrealist painting in the style of Joan Miro, playful biomorphic shapes, bold primary colors red blue yellow, thin black lines, stars and crescents, poetic symbols on a warm background' },
  { key: 'kahlo', style: 'Mexican folk surrealist painting in the style of Frida Kahlo, vivid saturated colors, lush tropical leaves and flowers, symbolic still life, naive detailed brushwork, no people' },
  { key: 'tanguy', style: 'surrealist painting in the style of Yves Tanguy, infinite misty plain without horizon, smooth biomorphic stone forms casting sharp shadows, muted blue grey palette' },
  { key: 'chirico', style: 'metaphysical painting in the style of Giorgio de Chirico, empty piazza with arcades, long raking shadows, deep green evening sky, distant tower, silent melancholy' },
  { key: 'younan', style: '1940s Egyptian surrealist painting inspired by Ramses Younan and the Art et Liberte group, dreamlike fragmented forms, earthy ochre and deep blue palette, enigmatic symbolic imagery' },
  { key: 'telmissany', style: '1940s Egyptian surrealist painting inspired by Kamel El-Telmissany and the Art et Liberte group, dark expressive distorted forms, raw textured brushwork, haunting atmosphere' },
  { key: 'fouadkamel', style: 'Egyptian surrealist painting inspired by Fouad Kamel and the Art et Liberte group, abstract surreal textures, rich earthy colors, cracked surfaces, enigmatic floating shapes' },
];

/* ---------- عناصر ألف ليلة وليلة في مواقف سريالية ---------- */
const SUBJECTS = [
  'a flying carpet drifting over an endless desert',
  'a golden magic oil lamp releasing blue smoke that becomes a staircase',
  'a caravan of camels with impossibly long thin legs',
  'a palace with onion domes floating above the clouds',
  'a giant ancient key standing upright in the sand dunes',
  'a brass lantern glowing inside a hollow tree',
  'a wooden sailing dhow sailing across a sea of sand',
  'a giant roc bird casting its shadow over a city of minarets',
  'an ornate wooden door standing alone in the middle of the sea',
  'a birdcage holding the crescent moon',
  'a pomegranate cracked open revealing tiny glowing stars',
  'an hourglass pouring golden sand into the night sky',
  'a lonely minaret on a chessboard desert',
  'an arched mirror in the dunes reflecting a different sky',
  'a staircase of carpets climbing towards the moon',
  'a great stone arch with an eye looking through it',
  'fish swimming through a moonlit palace courtyard',
  'a tree whose branches hold hanging lanterns instead of leaves',
  'a melting brass coffee pot resting on a marble column',
  'an open book of tales from which a whole city rises',
  'a genie made of clouds pouring water into the desert',
  'a treasure chest overflowing with seashells on a mountain top',
  'a camel standing on a rooftop under three moons',
  'a mashrabiya window floating in an empty sky',
  'a boat sailing through a sky full of lanterns',
  'a clock tower sinking slowly into sand',
];

const SUFFIX = 'masterpiece, museum quality, rich texture, dreamlike atmosphere, no text, no letters, no watermark, no signature, family friendly';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class AiImagePool {
  constructor({ logger = console, fetchImpl = globalThis.fetch } = {}) {
    this.log = logger;
    this.fetch = fetchImpl;
    this.key = process.env.POLLINATIONS_KEY || '';
    this.model = process.env.AI_MODEL || 'flux';
    this.target = Number(process.env.AI_POOL_TARGET) || 200;
    this.concurrency = this.key ? Math.max(1, Number(process.env.AI_CONCURRENCY) || 3) : 1;
    // بلا مفتاح: طلب واحد كل ~16 ثانية احتراماً لحد الخدمة المجانية
    this.gapMs = this.key ? 500 : 16_000;
    this.disabled = process.env.AI_DISABLED === '1' || typeof this.fetch !== 'function';
    this.images = new Map(); // id → { buf, type, artist, subject, createdAt }
    this.running = false;
    this.failures = 0;
    this.generated = 0;
  }

  get size() { return this.images.size; }

  stats() {
    return { ai: !this.disabled, withKey: !!this.key, pool: this.images.size, target: this.target, generated: this.generated, failures: this.failures };
  }

  /** بدء التوليد في الخلفية حتى يكتمل المخزون */
  start() {
    if (this.disabled || this.running) return;
    this.running = true;
    this.log.info?.(`[ai] بدء توليد اللوحات (${this.key ? 'بمفتاح' : 'بدون مفتاح، أبطأ'}) — الهدف ${this.target}`);
    for (let i = 0; i < this.concurrency; i++) this.worker(i);
  }

  async worker(n) {
    await sleep(n * 1500);
    while (this.images.size < this.target && !this.disabled) {
      const ok = await this.generateOne();
      if (ok) {
        this.failures = 0;
        await sleep(this.gapMs);
      } else {
        this.failures += 1;
        // تراجع تدريجي عند الأخطاء (حد الطلبات أو تعطل الخدمة): حتى 5 دقائق
        await sleep(Math.min(300_000, 20_000 * 2 ** Math.min(this.failures, 4)));
      }
    }
    this.running = false;
  }

  buildUrl(prompt, seed) {
    const p = encodeURIComponent(prompt);
    if (this.key) {
      return `https://gen.pollinations.ai/image/${p}?model=${encodeURIComponent(this.model)}&width=600&height=800&seed=${seed}&nologo=true&safe=true&private=true&nofeed=true`;
    }
    return `https://image.pollinations.ai/prompt/${p}?model=${encodeURIComponent(this.model)}&width=600&height=800&seed=${seed}&safe=true&private=true&nofeed=true`;
  }

  async generateOne() {
    const artist = pick(ARTISTS);
    const subject = pick(SUBJECTS);
    const prompt = `${subject}, ${artist.style}, ${SUFFIX}`;
    const url = this.buildUrl(prompt, randInt(1_000_000_000));
    try {
      const res = await this.fetch(url, {
        headers: this.key ? { Authorization: `Bearer ${this.key}` } : {},
        signal: AbortSignal.timeout(90_000),
      });
      const type = res.headers.get('content-type') || '';
      if (!res.ok || !type.startsWith('image/')) {
        this.log.warn?.(`[ai] فشل التوليد: HTTP ${res.status} ${type}`);
        return false;
      }
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length < 8_000 || buf.length > 4_000_000) {
        this.log.warn?.(`[ai] صورة بحجم غير متوقع: ${buf.length}`);
        return false;
      }
      const id = `a${randomId(6)}`;
      this.images.set(id, { buf, type, artist: artist.key, subject, createdAt: Date.now() });
      this.generated += 1;
      if (this.generated % 10 === 1 || this.images.size === this.target) {
        this.log.info?.(`[ai] المخزون ${this.images.size}/${this.target} (آخر لوحة: ${artist.key})`);
      }
      return true;
    } catch (err) {
      this.log.warn?.(`[ai] خطأ في التوليد: ${err.message}`);
      return false;
    }
  }

  get(id) {
    return this.images.get(id) || null;
  }

  /**
   * صور من المخزون لم تُستخدم في اللعبة الحالية أولاً، ثم المستخدمة سابقاً.
   * نفضّل تنوع الفنانين داخل الجولة الواحدة.
   */
  take(count, used = new Set()) {
    const all = [...this.images.keys()];
    const fresh = all.filter((id) => !used.has(id));
    const old = all.filter((id) => used.has(id));
    const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = randInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    return [...shuffle(fresh), ...shuffle(old)].slice(0, count).map((id) => ({ id, url: `/ai/${id}.jpg` }));
  }
}

module.exports = { AiImagePool, ARTISTS, SUBJECTS };
