'use strict';
/**
 * لوحات "واقعية" بالذكاء الاصطناعي بأساليب رواد السريالية وعناصر ألف ليلة وليلة.
 *
 * عند إنشاء أول غرفة يبدأ الخادم توليد اللوحات في الخلفية ويحتفظ بها في الذاكرة (مخزون)،
 * ثم يوزّعها من رابط الموقع نفسه (/ai/<id>.jpg). التوليد المسبق يجعل التوزيع فورياً.
 *
 * مزوّدات التوليد بالترتيب (يُستخدم أول مزوّد متاح، وينتقل للتالي إن نفد رصيده):
 *  1. cloudflare — Cloudflare Workers AI (نموذج FLUX.1 schnell): 10,000 Neuron مجانية يومياً
 *                  تتجدد 00:00 UTC (~170 لوحة/يوم). يحتاج CF_ACCOUNT_ID و CF_API_TOKEN.
 *  2. key        — Pollinations بمفتاح POLLINATIONS_KEY.
 *  3. anon       — Pollinations المجانية بلا مفتاح (بطيئة ومحدودة).
 * إن نفد رصيد مزوّد يُتجنَّب حتى موعد تجدده (منتصف الليل UTC لـ Cloudflare، وساعة لغيره).
 *
 * إن نقص المخزون أو تعطلت كل المزوّدات، يكمل الخادم بلوحات ألف ليلة المرسومة محلياً.
 *
 * متغيرات أخرى: AI_POOL_TARGET (افتراضي 160)، AI_MODEL (لـ Pollinations، افتراضي flux)، AI_DISABLED=1.
 */
const { randomId, pick, randInt } = require('./random');
const { sniffType } = require('./archive');

/* ---------- الأساليب: وصف أسلوبي لكل فنان (الأسلوب لا اللوحات) ---------- */
const ARTISTS = [
  { key: 'dali', style: 'surrealist oil painting in the style of Salvador Dali, hyperrealistic detail, vast barren dreamlike plain, soft melting forms, elongated spindly legs, long dramatic shadows, clear golden Mediterranean light' },
  { key: 'magritte', style: 'surrealist oil painting in the style of Rene Magritte, crisp clean realism, calm blue sky with soft white clouds, ordinary objects in impossible situations, quiet and mysterious' },
  { key: 'ernst', style: 'surrealist painting in the style of Max Ernst, decalcomania and frottage textures, petrified dark forest, strange bird forms, eerie pale moon ring' },
  { key: 'miro', style: 'surrealist painting in the style of Joan Miro, playful biomorphic shapes, bold primary colors red blue yellow, thin black lines, stars and crescents, poetic symbols on a warm background' },
  { key: 'kahlo', style: 'Mexican folk surrealist painting in the style of Frida Kahlo, vivid saturated colors, lush tropical leaves and flowers, symbolic still life, naive detailed brushwork, no people' },
  { key: 'tanguy', style: 'surrealist painting in the style of Yves Tanguy, infinite misty plain without horizon, smooth biomorphic stone forms casting sharp shadows, muted blue grey palette' },
  { key: 'chirico', style: 'metaphysical painting in the style of Giorgio de Chirico, empty piazza with arcades, long raking shadows, deep green evening sky, distant tower, silent melancholy' },
  { key: 'younan', style: '1940s Egyptian surrealist painting inspired by Ramses Younan and the Art et Liberte group, dreamlike fragmented forms, earthy ochre and deep blue palette, enigmatic symbolic imagery' },
  { key: 'telmissany', style: '1940s Egyptian surrealist painting inspired by Kamel El-Telmissany and the Art et Liberte group, dark expressive distorted forms, raw textured brushwork, haunting atmosphere' },
  { key: 'fouadkamel', style: 'Egyptian surrealist painting inspired by Fouad Kamel and the Art et Liberte group, abstract surreal textures, rich earthy colors, cracked surfaces, enigmatic floating shapes' },
];

/* ---------- عناصر ألف ليلة وليلة في مواقف سريالية ---------- */
const SUBJECTS = [
  'a flying carpet drifting over an endless desert',
  'a golden magic oil lamp releasing blue smoke that becomes a staircase',
  'a caravan of camels with impossibly long thin legs',
  'a palace with onion domes floating above the clouds',
  'a giant ancient key standing upright in the sand dunes',
  'a brass lantern glowing inside a hollow tree',
  'a wooden sailing dhow sailing across a sea of sand',
  'a giant roc bird casting its shadow over a city of minarets',
  'an ornate wooden door standing alone in the middle of the sea',
  'a birdcage holding the crescent moon',
  'a pomegranate cracked open revealing tiny glowing stars',
  'an hourglass pouring golden sand into the night sky',
  'a lonely minaret on a chessboard desert',
  'an arched mirror in the dunes reflecting a different sky',
  'a staircase of carpets climbing towards the moon',
  'a great stone arch with an eye looking through it',
  'fish swimming through a moonlit palace courtyard',
  'a tree whose branches hold hanging lanterns instead of leaves',
  'a melting brass coffee pot resting on a marble column',
  'an open book of tales from which a whole city rises',
  'a genie made of clouds pouring water into the desert',
  'a treasure chest overflowing with seashells on a mountain top',
  'a camel standing on a rooftop under three moons',
  'a mashrabiya window floating in an empty sky',
  'a boat sailing through a sky full of lanterns',
  'a clock tower sinking slowly into sand',
];

const SUFFIX = 'masterpiece, museum quality, rich texture, dreamlike atmosphere, no text, no letters, no watermark, no signature, family friendly';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const CF_MODEL = '@cf/black-forest-labs/flux-1-schnell';
const nextUtcMidnight = () => { const d = new Date(); d.setUTCHours(24, 0, 30, 0); return d.getTime(); };

class AiImagePool {
  constructor({ logger = console, fetchImpl = globalThis.fetch, env = process.env, archive = null } = {}) {
    this.log = logger;
    this.archive = archive; // أرشيف دائم (Cloudflare KV) — اختياري
    this.memCache = Number(env.AI_MEM_CACHE) || 220; // أقصى عدد لوحات مؤرشفة نُبقيها في الذاكرة
    this.fetch = fetchImpl;
    this.cf = env.CF_ACCOUNT_ID && env.CF_API_TOKEN ? { account: env.CF_ACCOUNT_ID, token: env.CF_API_TOKEN } : null;
    this.key = env.POLLINATIONS_KEY || '';
    this.model = env.AI_MODEL || 'flux';
    this.target = Number(env.AI_POOL_TARGET) || 160; // لوحات جديدة نرسمها في كل تشغيل (يحدّها رصيد المزوّد)
    this.lru = []; // ترتيب استخدام اللوحات المؤرشفة المحمّلة في الذاكرة
    this.providers = [...(this.cf ? ['cloudflare'] : []), ...(this.key ? ['key'] : []), 'anon'];
    this.blockedUntil = { cloudflare: 0, key: 0, anon: 0 };
    this.concurrency = this.providers[0] === 'anon' ? 1 : 3;
    this.gapMs = 500;          // بين الطلبات للمزوّدات بمفتاح
    this.anonGapMs = 16_000;   // الخدمة المجانية بلا مفتاح: طلب كل ~16 ثانية
    this.quotaPauseMs = 60 * 60_000;
    this.disabled = env.AI_DISABLED === '1' || typeof this.fetch !== 'function';
    this.images = new Map(); // id → { buf|null, type, archived, artist?, subject?, provider? }
    this.running = false;
    this.failures = 0;
    this.generated = 0;
    this.quotaHitAt = 0;
  }

  get size() { return this.images.size; }

  /** أول مزوّد غير موقوف حالياً، أو null إن كانت كلها موقوفة */
  mode() {
    const now = Date.now();
    return this.providers.find((p) => now >= this.blockedUntil[p]) || null;
  }

  stats() {
    return {
      ai: !this.disabled, providers: this.providers, mode: this.mode(), running: this.running,
      pool: this.images.size, target: this.target, generated: this.generated, failures: this.failures,
      ...(this.archive ? this.archive.stats() : {}),
    };
  }

  /** تحميل قائمة اللوحات المؤرشفة عند تشغيل الخادم (بلا تحميل الصور نفسها) */
  async loadArchive() {
    if (!this.archive) return 0;
    const ids = await this.archive.init();
    for (const id of ids) if (!this.images.has(id)) this.images.set(id, { buf: null, type: null, archived: true });
    return ids.length;
  }

  /** بدء التوليد في الخلفية حتى يكتمل المخزون (يُستدعى عند إنشاء غرفة) */
  start() {
    if (this.disabled || this.running || this.generated >= this.target) return;
    this.running = true;
    this.log.info?.(`[ai] بدء توليد اللوحات (المزوّدات: ${this.providers.join(' ← ')}) — ${this.target} لوحة جديدة، والمخزون الحالي ${this.images.size}`);
    for (let i = 0; i < this.concurrency; i++) this.worker(i);
  }

  async worker(n) {
    await sleep(n * 700);
    while (this.generated < this.target && !this.disabled) {
      const mode = this.mode();
      if (!mode) {
        // كل المزوّدات موقوفة: ننتظر أقرب موعد تجدد (بحد أقصى 10 دقائق ثم نتحقق)
        const wait = Math.min(...Object.values(this.blockedUntil).filter((t) => t > Date.now())) - Date.now();
        await sleep(Math.max(5_000, Math.min(wait, 10 * 60_000)));
        continue;
      }
      // الخدمة المجانية بلا مفتاح: عامل واحد فقط احتراماً لحد الطلبات
      if (n > 0 && mode === 'anon') { await sleep(30_000); continue; }
      const result = await this.generateOne(mode);
      if (result === 'ok') {
        this.failures = 0;
        await sleep(mode === 'anon' ? this.anonGapMs : this.gapMs);
      } else if (result === 'quota') {
        const until = mode === 'cloudflare' ? nextUtcMidnight() : Date.now() + this.quotaPauseMs;
        if (this.blockedUntil[mode] < Date.now()) {
          this.log.info?.(`[ai] رصيد ${mode} نفد عند ${this.images.size} لوحة — نتجاوزه حتى ${new Date(until).toISOString()}`);
        }
        this.blockedUntil[mode] = until;
        this.quotaHitAt = Date.now();
      } else {
        this.failures += 1;
        // تراجع تدريجي عند الأخطاء العابرة: حتى 5 دقائق
        await sleep(Math.min(300_000, 5_000 * 2 ** Math.min(this.failures, 6)));
      }
    }
    this.running = false;
  }

  pollinationsUrl(prompt, seed, mode) {
    const p = encodeURIComponent(prompt);
    const q = `model=${encodeURIComponent(this.model)}&width=600&height=800&seed=${seed}&safe=true&private=true&nofeed=true`;
    return mode === 'key' ? `https://gen.pollinations.ai/image/${p}?${q}&nologo=true` : `https://image.pollinations.ai/prompt/${p}?${q}`;
  }

  /** طلب صورة من المزوّد المحدد؛ يعيد { status, buf?, type? } */
  async request(mode, prompt) {
    const seed = randInt(1_000_000_000);
    let res;
    if (mode === 'cloudflare') {
      res = await this.fetch(`https://api.cloudflare.com/client/v4/accounts/${this.cf.account}/ai/run/${CF_MODEL}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${this.cf.token}`, 'Content-Type': 'application/json' },
        // نموذج Cloudflare لا يقبل seed؛ كل طلب يعطي لوحة مختلفة أصلاً
        body: JSON.stringify({ prompt, steps: 4 }),
        signal: AbortSignal.timeout(90_000),
      });
    } else {
      res = await this.fetch(this.pollinationsUrl(prompt, seed, mode), {
        headers: mode === 'key' ? { Authorization: `Bearer ${this.key}` } : {},
        signal: AbortSignal.timeout(90_000),
      });
    }
    const type = res.headers.get('content-type') || '';
    if (res.status === 402 || res.status === 429) return { status: 'quota', code: res.status };
    if (!res.ok) {
      const text = typeof res.text === 'function' ? await res.text().catch(() => '') : '';
      // Cloudflare يعيد 4xx مع رسالة عند تجاوز الحصة اليومية
      if (/neuron|quota|limit|exceed|capacity/i.test(text)) return { status: 'quota', code: res.status };
      return { status: 'fail', code: res.status, detail: text.slice(0, 160) };
    }
    if (type.startsWith('image/')) return { status: 'ok', buf: Buffer.from(await res.arrayBuffer()), type };
    if (type.includes('json')) {
      const data = await res.json();
      const b64 = data?.result?.image;
      if (!b64) return { status: 'fail', code: res.status, detail: 'no image in response' };
      const buf = Buffer.from(b64, 'base64');
      const isPng = buf[0] === 0x89 && buf[1] === 0x50;
      return { status: 'ok', buf, type: isPng ? 'image/png' : 'image/jpeg' };
    }
    return { status: 'fail', code: res.status, detail: type };
  }

  async generateOne(mode = this.mode()) {
    if (!mode) return 'quota';
    const artist = pick(ARTISTS);
    const subject = pick(SUBJECTS);
    const prompt = `${subject}, ${artist.style}, ${SUFFIX}`;
    try {
      const r = await this.request(mode, prompt);
      if (r.status === 'quota') return 'quota';
      if (r.status !== 'ok') {
        this.log.warn?.(`[ai] فشل التوليد (${mode}): HTTP ${r.code} ${r.detail || ''}`);
        return 'fail';
      }
      if (r.buf.length < 8_000 || r.buf.length > 5_000_000) {
        this.log.warn?.(`[ai] صورة بحجم غير متوقع: ${r.buf.length}`);
        return 'fail';
      }
      const id = `a${randomId(6)}`;
      const entry = { buf: r.buf, type: r.type, archived: false, artist: artist.key, subject, provider: mode };
      this.images.set(id, entry);
      this.generated += 1;
      // حفظ دائم في الأرشيف (بلا انتظار)
      if (this.archive) {
        this.archive.put(id, r.buf).then((ok) => { if (ok) { entry.archived = true; this.touch(id); } });
      }
      if (this.generated % 10 === 1 || this.generated === this.target) {
        this.log.info?.(`[ai] رُسمت ${this.generated}/${this.target}، المخزون ${this.images.size} (آخر لوحة: ${artist.key}، المزوّد: ${mode})`);
      }
      return 'ok';
    } catch (err) {
      this.log.warn?.(`[ai] خطأ في التوليد (${mode}): ${err.message}`);
      return 'fail';
    }
  }

  /** لوحة جاهزة للإرسال: من الذاكرة، أو تُجلب من الأرشيف عند الحاجة */
  async get(id) {
    const entry = this.images.get(id);
    if (!entry) return null;
    if (!entry.buf && entry.archived && this.archive) {
      const buf = await this.archive.get(id);
      if (!buf) return null;
      entry.buf = buf;
      entry.type = sniffType(buf);
    }
    if (!entry.buf) return null;
    if (entry.archived) this.touch(id);
    return { buf: entry.buf, type: entry.type || sniffType(entry.buf) };
  }

  /** إبقاء الذاكرة محدودة: نحرّر أقدم اللوحات المؤرشفة (تبقى في الأرشيف) */
  touch(id) {
    const i = this.lru.indexOf(id);
    if (i !== -1) this.lru.splice(i, 1);
    this.lru.push(id);
    while (this.lru.length > this.memCache) {
      const old = this.images.get(this.lru.shift());
      if (old && old.archived) old.buf = null;
    }
  }

  /**
   * صور من المخزون لم تُستخدم في اللعبة الحالية أولاً، ثم المستخدمة سابقاً.
   * نفضّل تنوع الفنانين داخل الجولة الواحدة.
   */
  take(count, used = new Set(), exclude = new Set()) {
    const all = [...this.images.keys()].filter((id) => !exclude.has(id)); // exclude: لوحات في أيدي اللاعبين الآن
    const fresh = all.filter((id) => !used.has(id));
    const old = all.filter((id) => used.has(id));
    const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = randInt(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    return [...shuffle(fresh), ...shuffle(old)].slice(0, count).map((id) => ({ id, url: `/ai/${id}.jpg` }));
  }
}

module.exports = { AiImagePool, ARTISTS, SUBJECTS };
