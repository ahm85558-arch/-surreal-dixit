'use strict';
/**
 * التحقق من المدخلات وتنقيتها على الخادم (لا نثق بالعميل أبداً).
 * تنقية XSS: نزيل وسوم HTML وأقواسها والمحارف غير المرئية قبل التخزين،
 * والعميل (React) يعرض النصوص كنصوص فقط ولا يستخدم dangerouslySetInnerHTML إطلاقاً.
 */
const { DESCRIPTION_MAX, NAME_MAX, MAX_ROUNDS, VOTING_CHOICES, IMAGE_STYLES, TIMERS } = require('./config');
const { CODE_ALPHABET } = require('./random');

const EMOJI_RE = /[\p{Extended_Pictographic}\u{1F1E6}-\u{1F1FF}\u{1F3FB}-\u{1F3FF}\u200D\uFE0F\u20E3]/u;
const URL_RE = /(https?:\/\/|ftp:\/\/|www\.|\b[a-z0-9-]+\.(com|net|org|io|co|me|ly|gg|app|dev|xyz|info|biz|tv|sa|ae|eg|ai)\b)/i;
const CONTROL_RE = /[\u0000-\u001F\u007F-\u009F\u200B\u200E\u200F\u202A-\u202E\u2066-\u2069]/g;

const fail = (error) => ({ ok: false, error });

/** تنقية عامة: إزالة الوسوم والأقواس الزاوية وأحرف التحكم وتوحيد المسافات */
function sanitizeText(raw) {
  return String(raw)
    .replace(/<[^>]*>/g, ' ')
    .replace(/[<>`]/g, '')
    .replace(CONTROL_RE, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** وصف الراوي: كلمات فقط، ≤ 120 حرفاً، بلا إيموجي أو روابط */
function validateDescription(raw) {
  if (typeof raw !== 'string') return fail('الوصف مطلوب.');
  if (raw.length > DESCRIPTION_MAX * 4) return fail(`الوصف أطول من ${DESCRIPTION_MAX} حرفاً.`);
  const text = sanitizeText(raw);
  if (!text) return fail('اكتب وصفاً من كلمة واحدة على الأقل.');
  if ([...text].length > DESCRIPTION_MAX) return fail(`الوصف أطول من ${DESCRIPTION_MAX} حرفاً.`);
  if (EMOJI_RE.test(text)) return fail('الوصف يجب أن يكون كلمات فقط، بدون إيموجي.');
  if (URL_RE.test(text)) return fail('الروابط غير مسموحة في الوصف.');
  if (!/\p{L}/u.test(text)) return fail('الوصف يجب أن يحتوي على كلمات.');
  return { ok: true, value: text };
}

/** الاسم المستعار */
function validateName(raw) {
  if (typeof raw !== 'string') return fail('الاسم مطلوب.');
  if (raw.length > NAME_MAX * 4) return fail(`الاسم أطول من ${NAME_MAX} حرفاً.`);
  const name = sanitizeText(raw);
  if (!name) return fail('اكتب اسماً مستعاراً.');
  if ([...name].length > NAME_MAX) return fail(`الاسم أطول من ${NAME_MAX} حرفاً.`);
  if (EMOJI_RE.test(name)) return fail('استخدم حروفاً وأرقاماً فقط في الاسم.');
  if (!/[\p{L}\p{N}]/u.test(name)) return fail('الاسم يجب أن يحتوي على حرف أو رقم.');
  return { ok: true, value: name };
}

/** عدد الجولات: null/فارغ = تلقائي (عدد اللاعبين) */
function validateRounds(raw) {
  if (raw === null || raw === undefined || raw === '' || raw === 0 || raw === 'auto') return { ok: true, value: null };
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 1 || n > MAX_ROUNDS) return fail(`عدد الجولات بين 1 و${MAX_ROUNDS}.`);
  return { ok: true, value: n };
}

/** مدة التصويت: من الخيارات المسموحة فقط */
function validateVotingSeconds(raw) {
  if (raw === null || raw === undefined || raw === '') return { ok: true, value: TIMERS.VOTING_PHASE };
  const n = Number(raw);
  if (!VOTING_CHOICES.includes(n)) return fail(`مدة التصويت إحدى القيم: ${VOTING_CHOICES.join('، ')} ثانية.`);
  return { ok: true, value: n };
}

/** نمط الصور */
function validateImageStyle(raw) {
  if (raw === null || raw === undefined || raw === '') return { ok: true, value: 'serious' };
  if (!IMAGE_STYLES.includes(raw)) return fail('نمط الصور غير معروف.');
  return { ok: true, value: raw };
}

/** كود الغرفة: 6 أحرف/أرقام من الأبجدية المعتمدة */
function normalizeRoomCode(raw) {
  if (typeof raw !== 'string') return null;
  const code = raw.trim().toUpperCase();
  return new RegExp(`^[${CODE_ALPHABET}]{6}$`).test(code) ? code : null;
}

const isSafeId = (v) => typeof v === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(v);

module.exports = {
  sanitizeText, validateDescription, validateName, validateRounds, validateVotingSeconds, validateImageStyle, normalizeRoomCode, isSafeId,
};
