'use strict';
/**
 * نقطة الدخول: Express يقدّم واجهة React المبنية (dist/) والصور المولّدة، وSocket.IO للعب الفوري.
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const cfg = require('./config');
const { ImageProvider } = require('./imageProvider');
const { AiImagePool } = require('./aiImages');
const { RoomManager } = require('./RoomManager');
const { registerSocketHandlers } = require('./socketHandlers');
const { generateSurrealSVG } = require('./surrealArt');
const { generateDreamSVG } = require('./dreamArt');
const { generateNightsSVG } = require('./nightsArt');

const ROOT = path.join(__dirname, '..');
const DIST = path.join(ROOT, 'dist');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  maxHttpBufferSize: 16 * 1024, // رسائل اللعبة صغيرة؛ نرفض الحمولات الضخمة
  pingInterval: 10_000,
  pingTimeout: 8_000,
  cors: process.env.CLIENT_ORIGIN ? { origin: process.env.CLIENT_ORIGIN.split(',') } : undefined,
});

// لوحات الذكاء الاصطناعي: يبدأ توليدها عند إنشاء أول غرفة (انظر RoomManager.createRoom)
const aiPool = new AiImagePool();
const manager = new RoomManager(io, new ImageProvider({ source: cfg.IMAGE_SOURCE, aiPool }));
registerSocketHandlers(io, manager);

/* ---------------- HTTP ---------------- */
app.disable('x-powered-by');
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

// الصور المولّدة: n = ألف ليلة سريالية، s = لوحات حالمة، g = ميمز مضحكة. حتمية حسب المعرّف، فتُخزَّن مؤقتاً للأبد
const svgCache = new Map();
app.get('/img/:file', (req, res) => {
  const m = /^([gns][0-9a-f]{12})\.svg$/.exec(req.params.file);
  if (!m) return res.status(404).end();
  let svg = svgCache.get(m[1]);
  if (!svg) {
    const gen = { n: generateNightsSVG, s: generateDreamSVG, g: generateSurrealSVG }[m[1][0]];
    svg = gen(m[1]);
    if (svgCache.size > 5000) svgCache.delete(svgCache.keys().next().value);
    svgCache.set(m[1], svg);
  }
  res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
  res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  return res.send(svg);
});

// لوحات الذكاء الاصطناعي من المخزون
app.get('/ai/:file', (req, res) => {
  const m = /^(a[0-9a-f]{12})\.jpg$/.exec(req.params.file);
  const img = m && aiPool.get(m[1]);
  if (!img) return res.status(404).end();
  res.setHeader('Content-Type', img.type);
  res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  return res.send(img.buf);
});

// صور IMAGE_SOURCE=folder
app.use('/memes', express.static(path.join(ROOT, 'memes'), { maxAge: '1d' }));

app.get('/health', (_req, res) => res.json({ ok: true, ...manager.stats(), ...aiPool.stats() }));

// واجهة React المبنية
if (fs.existsSync(path.join(DIST, 'index.html'))) {
  app.use(express.static(DIST, {
    index: 'index.html',
    setHeaders(res, filePath) {
      // الصفحة الرئيسية بلا تخزين مؤقت: أي تحديث للموقع يظهر فوراً للاعبين
      if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
      // ملفات الواجهة المبنية أسماؤها تتغير مع كل تحديث، فتُخزَّن طويلاً
      else if (filePath.includes(`${path.sep}assets${path.sep}`)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      else res.setHeader('Cache-Control', 'public, max-age=3600');
    },
  }));
} else {
  app.get('/', (_req, res) => res.status(503).type('text/plain; charset=utf-8')
    .send('الواجهة غير مبنية بعد. شغّل: npm run build  ثم  npm start'));
}

server.listen(cfg.PORT, '0.0.0.0', () => {
  console.log(`Surreal Dixit يعمل على http://localhost:${cfg.PORT} (مصدر الصور: ${cfg.IMAGE_SOURCE})`);
});

module.exports = { app, server, io };
