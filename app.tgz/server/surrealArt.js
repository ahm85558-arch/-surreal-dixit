'use strict';
/**
 * مولّد صور سريالية بأسلوب الميمز (SVG) — حتمي حسب المعرّف.
 *
 * لماذا؟ الصور المولّدة محلياً:
 *  - آمنة 100% (لا محتوى مخل أو عنيف لأنها مرسومة من عناصر محددة مسبقاً).
 *  - لا تعتمد على واجهة خارجية قد تتوقف أو تُبطئ اللعبة.
 *  - لا نهائية العدد، فلا تتكرر صورة داخل الجولة.
 *
 * كل صورة = خلفية + تركيبة عبثية (توست بنظارات شمسية، سحابة بأرجل، عين عملاقة تطير ببالون...).
 * المعرّف نفسه عشوائي (crypto)، أما هذا الملف فيستخدم مولداً حتمياً ليعيد رسم الصورة نفسها دائماً.
 */

const W = 300;
const H = 400;
const INK = '#1d1631';

/* ---------- مولّد حتمي من البذرة ---------- */
function hashSeed(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}
function mulberry32(a) {
  return function next() {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function makeRng(seed) {
  const r = mulberry32(seed);
  const R = {
    r,
    range: (a, b) => a + r() * (b - a),
    int: (a, b) => Math.floor(a + r() * (b - a + 1)),
    pick: (arr) => arr[Math.floor(r() * arr.length)],
    chance: (p) => r() < p,
  };
  return R;
}
const f = (n) => Math.round(n * 10) / 10;

/* ---------- لوحات الألوان: [سماء1، سماء2، لون1، لون2] ---------- */
const PALETTES = [
  ['#7fb7e8', '#d6ecfa', '#ff6b9a', '#ffd166'],
  ['#f6a15b', '#fde0b5', '#3d5afe', '#7bd389'],
  ['#1b2a5c', '#4a3a86', '#ffd447', '#ff7aa2'],
  ['#9fe3c6', '#eafff6', '#ff5e5b', '#5b5fef'],
  ['#f2b5d4', '#ffe8f3', '#2ec4b6', '#ff9f1c'],
  ['#c9c3f5', '#f3f0ff', '#ff7f50', '#2f9e44'],
  ['#ffd23f', '#fff4c2', '#8338ec', '#3a86ff'],
];

/* ---------- الخلفيات ---------- */
function clouds(R, n, y0, y1) {
  let s = '';
  for (let i = 0; i < n; i++) {
    const x = R.range(20, 280), y = R.range(y0, y1), k = R.range(0.5, 1.1);
    s += `<g transform="translate(${f(x)} ${f(y)}) scale(${f(k)})" fill="#fff" opacity=".85">`
      + '<ellipse rx="34" ry="12"/><ellipse cx="-14" cy="-8" rx="16" ry="12"/><ellipse cx="12" cy="-10" rx="18" ry="14"/></g>';
  }
  return s;
}

function background(R, pal) {
  const kind = R.pick(['sky', 'desert', 'checker', 'space', 'ocean', 'void']);
  const defs = `<defs><linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">`
    + `<stop offset="0" stop-color="${pal[0]}"/><stop offset="1" stop-color="${pal[1]}"/></linearGradient>`
    + `<radialGradient id="vg" cx=".5" cy=".45" r=".7"><stop offset="0" stop-color="${pal[1]}"/>`
    + `<stop offset="1" stop-color="${pal[0]}"/></radialGradient></defs>`;
  let s = defs;
  let groundY = 330;

  if (kind === 'space') {
    s += `<rect width="${W}" height="${H}" fill="#140f2b"/>`;
    for (let i = 0; i < 45; i++) {
      s += `<circle cx="${f(R.range(0, W))}" cy="${f(R.range(0, H))}" r="${f(R.range(0.6, 2.2))}" fill="#fff" opacity="${f(R.range(0.4, 1))}"/>`;
    }
    s += `<circle cx="${f(R.range(40, 260))}" cy="${f(R.range(40, 110))}" r="${f(R.range(14, 26))}" fill="${pal[3]}" opacity=".9"/>`;
    groundY = 300;
  } else if (kind === 'void') {
    s += `<rect width="${W}" height="${H}" fill="url(#vg)"/>`;
    for (let r = 40; r < 320; r += 38) {
      s += `<circle cx="150" cy="190" r="${r}" fill="none" stroke="${pal[2]}" stroke-width="2" opacity=".25"/>`;
    }
    groundY = 310;
  } else {
    s += `<rect width="${W}" height="${H}" fill="url(#bg)"/>`;
    // الشمس — أحياناً تكون عيناً تحدّق
    const sx = R.range(40, 260), sy = R.range(45, 95);
    if (R.chance(0.3)) {
      s += `<g transform="translate(${f(sx)} ${f(sy)})"><circle r="24" fill="#fff" stroke="${INK}" stroke-width="3"/>`
        + `<circle r="11" fill="${pal[2]}"/><circle r="5" fill="${INK}"/></g>`;
    } else {
      s += `<circle cx="${f(sx)}" cy="${f(sy)}" r="${f(R.range(18, 30))}" fill="${pal[3]}"/>`;
    }
    s += clouds(R, R.int(1, 3), 50, 170);

    if (kind === 'desert') {
      groundY = 300;
      s += `<path d="M0 ${groundY} Q75 ${groundY - 25} 150 ${groundY} T300 ${groundY} V400 H0Z" fill="${pal[3]}" opacity=".85"/>`;
      s += `<path d="M0 ${groundY + 30} Q90 ${groundY + 10} 190 ${groundY + 35} T300 ${groundY + 25} V400 H0Z" fill="${pal[2]}" opacity=".35"/>`;
    } else if (kind === 'checker') {
      // أرضية شطرنجية بمنظور — لمسة ماغريت/دالي
      groundY = 250;
      const rows = 7, cols = 10, vp = 150;
      for (let i = 0; i < rows; i++) {
        const t0 = Math.pow(i / rows, 1.6), t1 = Math.pow((i + 1) / rows, 1.6);
        const y0 = groundY + t0 * (H - groundY), y1 = groundY + t1 * (H - groundY);
        for (let j = 0; j < cols; j++) {
          if ((i + j) % 2) continue;
          const xs = (k, t) => vp + (k - cols / 2) * (12 + t * 70);
          s += `<path d="M${f(xs(j, t0))} ${f(y0)} L${f(xs(j + 1, t0))} ${f(y0)} L${f(xs(j + 1, t1))} ${f(y1)} L${f(xs(j, t1))} ${f(y1)}Z" fill="${INK}" opacity=".78"/>`;
        }
      }
      s += `<rect y="${groundY}" width="${W}" height="${H - groundY}" fill="#fff" opacity=".12"/>`;
      groundY = 330;
    } else if (kind === 'ocean') {
      groundY = 280;
      s += `<rect y="${groundY}" width="${W}" height="${H - groundY}" fill="${pal[2]}" opacity=".55"/>`;
      for (let y = groundY + 12; y < H; y += 22) {
        s += `<path d="M0 ${y} q18 -10 36 0 t36 0 t36 0 t36 0 t36 0 t36 0 t36 0 t36 0 t36 0" fill="none" stroke="#fff" stroke-width="3" opacity=".6"/>`;
      }
      groundY = 330;
    } else {
      s += `<rect y="${groundY}" width="${W}" height="${H - groundY}" fill="${pal[3]}" opacity=".45"/>`;
    }
  }
  return { svg: s, groundY };
}

/* ---------- الكائنات (مرسومة حول نقطة الأصل، تقريباً في مربع ‎-50..50) ----------
 * لكل كائن: draw(pal) ، top/bottom/halfW للتعليق عليه ، face (موضع الوجه) إن كان قابلاً للوجه.
 */
const st = `stroke="${INK}" stroke-width="3" stroke-linejoin="round"`;
const SUBJECTS = {
  eye: {
    top: -32, bottom: 22, halfW: 50, face: null,
    draw: (p) => {
      let s = `<path d="M-50 0 Q0 -40 50 0 Q0 40 -50 0Z" fill="#fff" ${st}/>`
        + `<circle r="18" fill="${p[2]}" stroke="${INK}" stroke-width="2"/><circle r="8" fill="${INK}"/><circle cx="-5" cy="-5" r="3" fill="#fff"/>`;
      for (let i = 1; i < 8; i++) {
        const t = i / 8, x = -50 + 100 * t, y = -40 * t * (1 - t) * 2;
        s += `<line x1="${f(x)}" y1="${f(y)}" x2="${f(x * 1.15)}" y2="${f(y - 13)}" stroke="${INK}" stroke-width="3" stroke-linecap="round"/>`;
      }
      return s;
    },
  },
  clock: {
    top: -50, bottom: 55, halfW: 40, face: null,
    draw: () => {
      let s = '<path d="M-40 -10 A40 40 0 0 1 40 -10 L40 5 C40 25 30 20 28 35 C26 55 14 55 14 38 C14 25 0 30 -6 42 C-12 55 -24 50 -22 30 C-20 18 -40 25 -40 5Z" fill="#fff8e7" '
        + `${st}/>`;
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        s += `<line x1="${f(Math.cos(a) * 30)}" y1="${f(-10 + Math.sin(a) * 30)}" x2="${f(Math.cos(a) * 35)}" y2="${f(-10 + Math.sin(a) * 35)}" stroke="${INK}" stroke-width="2"/>`;
      }
      return s + `<line x1="0" y1="-10" x2="0" y2="-34" stroke="${INK}" stroke-width="4" stroke-linecap="round"/>`
        + `<line x1="0" y1="-10" x2="17" y2="-2" stroke="${INK}" stroke-width="3" stroke-linecap="round"/><circle cy="-10" r="3.5" fill="${INK}"/>`;
    },
  },
  fish: {
    top: -28, bottom: 22, halfW: 50, face: { x: -22, y: -3, w: 24 },
    draw: (p) => `<path d="M28 0 L52 -20 L48 0 L52 20Z" fill="${p[3]}" ${st}/>`
      + `<path d="M-10 -18 Q0 -36 12 -20" fill="${p[2]}" ${st}/>`
      + `<path d="M-45 0 Q-10 -35 30 0 Q-10 35 -45 0Z" fill="${p[3]}" ${st}/>`
      + `<path d="M0 -8 q6 8 0 16 M10 -8 q6 8 0 16" fill="none" stroke="${INK}" stroke-width="2" opacity=".5"/>`,
  },
  toast: {
    top: -55, bottom: 45, halfW: 48, face: { x: 0, y: 5, w: 42 },
    draw: () => {
      const d = 'M-38 45 L-38 -15 Q-50 -20 -48 -35 Q-44 -55 -20 -52 Q0 -60 20 -52 Q44 -55 48 -35 Q50 -20 38 -15 L38 45Z';
      return `<path d="${d}" fill="#c98a4b" ${st}/><path d="${d}" fill="#f3d19c" transform="translate(0 4) scale(.82)"/>`;
    },
  },
  cloud: {
    top: -38, bottom: 32, halfW: 48, face: { x: 0, y: 2, w: 40 },
    draw: () => {
      const cs = [[-25, 5, 22], [0, -10, 28], [25, 5, 22], [0, 12, 20]];
      return cs.map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${r + 3}" fill="${INK}"/>`).join('')
        + cs.map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#fff"/>`).join('');
    },
  },
  teacup: {
    top: -45, bottom: 46, halfW: 48, face: { x: 0, y: 10, w: 40 },
    draw: (p) => '<path d="M-12 -24 q-8 -8 0 -16 t0 -16 M8 -24 q-8 -8 0 -16 t0 -16" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".9"/>'
      + `<ellipse cy="38" rx="48" ry="9" fill="#fff8e7" ${st}/>`
      + `<path d="M33 -5 q22 0 18 18 q-3 12 -20 10" fill="none" stroke="${INK}" stroke-width="5"/>`
      + `<path d="M-35 -15 L35 -15 Q33 35 0 35 Q-33 35 -35 -15Z" fill="${p[2]}" ${st}/>`
      + `<ellipse cy="-15" rx="35" ry="7" fill="#8b5a2b" ${st}/>`,
  },
  planet: {
    top: -36, bottom: 36, halfW: 60, face: { x: 0, y: -2, w: 36 },
    draw: (p) => `<g transform="rotate(-18)"><ellipse rx="62" ry="15" fill="none" stroke="${p[3]}" stroke-width="7"/></g>`
      + `<circle r="35" fill="${p[2]}" ${st}/>`
      + '<path d="M-33 -10 Q0 -2 33 -10 M-30 14 Q0 22 30 14" fill="none" stroke="#fff" stroke-width="4" opacity=".35"/>'
      + `<g transform="rotate(-18)"><path d="M-62 0 A62 15 0 0 0 62 0" fill="none" stroke="${p[3]}" stroke-width="7"/></g>`,
  },
  pear: {
    top: -60, bottom: 46, halfW: 42, face: { x: 0, y: 16, w: 38 },
    draw: (p) => `<path d="M0 -48 L5 -60" stroke="${INK}" stroke-width="4" stroke-linecap="round"/>`
      + '<ellipse cx="14" cy="-56" rx="10" ry="5" fill="#2f9e44" transform="rotate(-25 14 -56)"/>'
      + `<path d="M0 -48 C14 -48 16 -28 18 -18 C40 0 42 44 0 46 C-42 44 -40 0 -18 -18 C-16 -28 -14 -48 0 -48Z" fill="${p[3]}" ${st}/>`,
  },
  sock: {
    top: -50, bottom: 52, halfW: 30, face: { x: -3, y: 0, w: 28 },
    draw: (p) => `<path d="M-20 -50 L15 -50 L15 10 Q15 20 30 25 Q55 33 50 45 Q45 56 20 50 L-10 44 Q-25 40 -22 20Z" fill="#fff" ${st}/>`
      + `<path d="M-20 -40 H15 M-20 -28 H15" stroke="${p[2]}" stroke-width="6"/>`,
  },
  egg: {
    top: -38, bottom: 36, halfW: 48, face: { x: 5, y: 0, w: 26 },
    draw: () => `<path d="M-45 5 C-50 -30 -10 -40 10 -32 C40 -38 55 -10 45 12 C40 38 5 40 -15 34 C-40 32 -42 20 -45 5Z" fill="#fff" ${st}/>`
      + `<circle cx="5" r="18" fill="#ffc93c" ${st}/>`,
  },
  mushroom: {
    top: -48, bottom: 46, halfW: 48, face: { x: 0, y: 24, w: 24 },
    draw: (p) => `<path d="M-14 2 L-18 42 Q0 48 18 42 L14 2Z" fill="#fff8e7" ${st}/>`
      + `<path d="M-48 5 Q-45 -45 0 -48 Q45 -45 48 5 Q0 15 -48 5Z" fill="${p[2]}" ${st}/>`
      + '<g fill="#fff"><circle cx="-25" cy="-20" r="7"/><circle cx="8" cy="-32" r="6"/><circle cx="28" cy="-12" r="8"/><circle cx="-4" cy="-8" r="5"/></g>',
  },
  banana: {
    top: -34, bottom: 36, halfW: 50, face: { x: 4, y: 18, w: 26 },
    draw: () => `<path d="M-45 -30 C-40 30 30 45 50 10 C35 25 -20 20 -35 -32Z" fill="#ffd93d" ${st}/>`
      + `<path d="M-45 -30 L-43 -36 L-35 -32" fill="${INK}"/>`,
  },
  duck: {
    top: -40, bottom: 44, halfW: 50, face: { x: -22, y: -20, w: 26 },
    draw: () => `<ellipse cx="5" cy="20" rx="42" ry="24" fill="#ffd93d" ${st}/>`
      + `<path d="M10 12 q20 -4 26 12 q-14 6 -26 -12Z" fill="#f4b400" ${st}/>`
      + `<circle cx="-22" cy="-18" r="21" fill="#ffd93d" ${st}/>`
      + `<path d="M-40 -14 L-60 -9 L-40 -4Z" fill="#ff8c42" ${st}/>`,
  },
  house: {
    top: -56, bottom: 35, halfW: 46, face: null,
    draw: (p) => `<rect x="-35" y="-15" width="70" height="50" fill="${p[3]}" ${st}/>`
      + `<path d="M-46 -15 L0 -56 L46 -15Z" fill="${p[2]}" ${st}/>`
      + `<rect x="-8" y="10" width="16" height="25" fill="${INK}"/>`
      + `<rect x="-28" y="-6" width="14" height="12" fill="#fff" ${st}/><rect x="14" y="-6" width="14" height="12" fill="#fff" ${st}/>`,
  },
};
const SUBJECT_KEYS = Object.keys(SUBJECTS);

/* ---------- الإضافات العبثية ---------- */
function face(R, a) {
  const { x, y, w } = a;
  const kind = R.pick(['googly', 'googly', 'googly', 'shades', 'sleepy', 'cyclops']);
  let s = '';
  if (kind === 'shades') {
    const lw = w * 0.36, lh = w * 0.2;
    s += `<g fill="${INK}"><rect x="${f(x - w * 0.46)}" y="${f(y - lh)}" width="${f(lw)}" height="${f(lh)}" rx="3"/>`
      + `<rect x="${f(x + w * 0.1)}" y="${f(y - lh)}" width="${f(lw)}" height="${f(lh)}" rx="3"/>`
      + `<rect x="${f(x - w * 0.12)}" y="${f(y - lh * 0.9)}" width="${f(w * 0.24)}" height="2.5"/></g>`
      + `<line x1="${f(x - w * 0.4)}" y1="${f(y - lh * 0.7)}" x2="${f(x - w * 0.3)}" y2="${f(y - lh * 0.7)}" stroke="#fff" stroke-width="2"/>`;
  } else if (kind === 'sleepy') {
    s += `<path d="M${f(x - w * 0.38)} ${f(y - 4)} q${f(w * 0.12)} 6 ${f(w * 0.24)} 0 M${f(x + w * 0.14)} ${f(y - 4)} q${f(w * 0.12)} 6 ${f(w * 0.24)} 0" fill="none" stroke="${INK}" stroke-width="2.5" stroke-linecap="round"/>`;
  } else {
    const eyes = kind === 'cyclops' ? [[x, w * 0.3]] : [[x - w * 0.25, w * 0.2], [x + w * 0.25, w * 0.22]];
    for (const [ex, r] of eyes) {
      const px = ex + R.range(-r * 0.45, r * 0.45), py = y - 4 + R.range(-r * 0.45, r * 0.45);
      s += `<circle cx="${f(ex)}" cy="${f(y - 4)}" r="${f(r)}" fill="#fff" stroke="${INK}" stroke-width="2"/>`
        + `<circle cx="${f(px)}" cy="${f(py)}" r="${f(r * 0.48)}" fill="${INK}"/>`;
    }
  }
  const my = y + w * 0.28;
  const mouth = R.pick(['smile', 'o', 'flat', 'grin', 'tongue']);
  if (mouth === 'smile') s += `<path d="M${f(x - w * 0.2)} ${f(my)} q${f(w * 0.2)} ${f(w * 0.2)} ${f(w * 0.4)} 0" fill="none" stroke="${INK}" stroke-width="2.5" stroke-linecap="round"/>`;
  else if (mouth === 'o') s += `<ellipse cx="${f(x)}" cy="${f(my + 2)}" rx="${f(w * 0.08)}" ry="${f(w * 0.12)}" fill="${INK}"/>`;
  else if (mouth === 'flat') s += `<line x1="${f(x - w * 0.15)}" y1="${f(my)}" x2="${f(x + w * 0.15)}" y2="${f(my)}" stroke="${INK}" stroke-width="2.5" stroke-linecap="round"/>`;
  else if (mouth === 'grin') s += `<rect x="${f(x - w * 0.22)}" y="${f(my - 3)}" width="${f(w * 0.44)}" height="${f(w * 0.16)}" rx="2" fill="#fff" stroke="${INK}" stroke-width="2"/><line x1="${f(x)}" y1="${f(my - 3)}" x2="${f(x)}" y2="${f(my - 3 + w * 0.16)}" stroke="${INK}" stroke-width="1.5"/>`;
  else s += `<path d="M${f(x - w * 0.18)} ${f(my)} q${f(w * 0.18)} ${f(w * 0.12)} ${f(w * 0.36)} 0" fill="none" stroke="${INK}" stroke-width="2.5"/><path d="M${f(x - 3)} ${f(my + 2)} q3 ${f(w * 0.25)} 7 0Z" fill="#ff5e7e" stroke="${INK}" stroke-width="1.5"/>`;
  if (R.chance(0.2)) s += `<path d="M${f(x)} ${f(my - 5)} q-10 -6 -16 2 q6 -2 8 2 M${f(x)} ${f(my - 5)} q10 -6 16 2 q-6 -2 -8 2" fill="${INK}" stroke="${INK}" stroke-width="2"/>`;
  if (R.chance(0.3)) s += `<circle cx="${f(x - w * 0.42)}" cy="${f(y + w * 0.12)}" r="${f(w * 0.08)}" fill="#ff8fab" opacity=".7"/><circle cx="${f(x + w * 0.42)}" cy="${f(y + w * 0.12)}" r="${f(w * 0.08)}" fill="#ff8fab" opacity=".7"/>`;
  return s;
}

function legs(R, sub) {
  const b = sub.bottom - 3, dx = Math.min(sub.halfW * 0.45, 20), len = R.range(24, 42);
  const shoe = R.pick(['#e63946', INK, '#3a86ff', '#fff']);
  const kick = R.range(-12, 12);
  return `<g stroke="${INK}" stroke-width="3.5" stroke-linecap="round" fill="none">`
    + `<path d="M${f(-dx)} ${f(b)} l${f(-4 + kick)} ${f(len)}"/><path d="M${f(dx)} ${f(b)} l${f(4 + kick)} ${f(len)}"/></g>`
    + `<ellipse cx="${f(-dx - 8 + kick)}" cy="${f(b + len + 2)}" rx="10" ry="5" fill="${shoe}" ${st}/>`
    + `<ellipse cx="${f(dx + 8 + kick)}" cy="${f(b + len + 2)}" rx="10" ry="5" fill="${shoe}" ${st}/>`;
}

function arms(R, sub) {
  const x = sub.halfW * 0.85, wave = R.chance(0.5) ? -1 : 1;
  return `<g stroke="${INK}" stroke-width="3" stroke-linecap="round" fill="none">`
    + `<path d="M${f(-x)} 0 q-18 ${10 * wave} -26 ${-24}"/><path d="M${f(x)} 0 q18 ${-10 * wave} 28 ${-6}"/></g>`
    + `<circle cx="${f(-x - 26)}" cy="-24" r="5" fill="#fff" ${st}/><circle cx="${f(x + 28)}" cy="-6" r="5" fill="#fff" ${st}/>`;
}

function hat(R, sub, pal) {
  const t = sub.top + 2;
  const kind = R.pick(['top', 'party', 'crown']);
  const tilt = f(R.range(-15, 15));
  let s = `<g transform="translate(0 ${t}) rotate(${tilt})">`;
  if (kind === 'top') s += `<rect x="-26" y="-4" width="52" height="7" rx="3" fill="${INK}"/><rect x="-16" y="-38" width="32" height="36" fill="${INK}"/><rect x="-16" y="-12" width="32" height="6" fill="${pal[2]}"/>`;
  else if (kind === 'party') s += `<path d="M-18 0 L0 -46 L18 0Z" fill="${pal[2]}" ${st}/><circle cx="0" cy="-48" r="6" fill="${pal[3]}" ${st}/><circle cx="-5" cy="-14" r="3" fill="#fff"/><circle cx="5" cy="-26" r="3" fill="#fff"/>`;
  else s += `<path d="M-24 0 L-24 -26 L-12 -12 L0 -32 L12 -12 L24 -26 L24 0Z" fill="#ffd23f" ${st}/>`;
  return s + '</g>';
}

function wings(sub) {
  const x = sub.halfW * 0.8;
  return `<ellipse cx="${f(-x - 14)}" cy="-14" rx="26" ry="12" fill="#fff" ${st} transform="rotate(-25 ${f(-x - 14)} -14)"/>`
    + `<ellipse cx="${f(x + 14)}" cy="-14" rx="26" ry="12" fill="#fff" ${st} transform="rotate(25 ${f(x + 14)} -14)"/>`;
}

function balloon(R, sub, pal) {
  const bx = R.range(-30, 30), by = sub.top - 70;
  return `<path d="M0 ${sub.top} Q${f(bx - 10)} ${f(sub.top - 30)} ${f(bx)} ${f(by + 26)}" fill="none" stroke="${INK}" stroke-width="1.5"/>`
    + `<ellipse cx="${f(bx)}" cy="${f(by)}" rx="20" ry="25" fill="${pal[2]}" ${st}/><ellipse cx="${f(bx - 7)}" cy="${f(by - 9)}" rx="4" ry="7" fill="#fff" opacity=".6"/>`;
}

/** كائن كامل مع إضافاته، يعيد مجموعة SVG */
function character(R, pal, key, { x, y, s, rot = 0, flip = false, decorate = true }) {
  const sub = SUBJECTS[key];
  let behind = '', front = '';
  if (decorate) {
    if (R.chance(0.25)) behind += wings(sub);
    if (R.chance(0.2)) behind += balloon(R, sub, pal);
    if (R.chance(0.55)) behind += legs(R, sub);
    if (R.chance(0.35)) front += arms(R, sub);
    if (sub.face) front += face(R, sub.face);
    if (R.chance(0.4)) front += hat(R, sub, pal);
  } else if (sub.face && R.chance(0.5)) {
    front += face(R, sub.face);
  }
  const tf = `translate(${f(x)} ${f(y)}) rotate(${f(rot)}) scale(${flip ? -f(s) : f(s)} ${f(s)})`;
  return `<g transform="${tf}">${behind}${sub.draw(pal)}${front}</g>`;
}

function shadow(x, y, w, float) {
  return `<ellipse cx="${f(x)}" cy="${f(y)}" rx="${f(w)}" ry="${f(w * 0.18)}" fill="${INK}" opacity="${float ? 0.12 : 0.22}"/>`;
}

/** نقطة الدخول: يعيد نص SVG كامل للمعرّف المعطى */
function generateSurrealSVG(id) {
  const R = makeRng(hashSeed(String(id)));
  const pal = R.pick(PALETTES);
  const bg = background(R, pal);
  let body = bg.svg;
  const layout = R.pick(['hero', 'hero', 'swarm', 'stack', 'duo']);
  const main = R.pick(SUBJECT_KEYS);
  let other = R.pick(SUBJECT_KEYS);
  if (other === main) other = SUBJECT_KEYS[(SUBJECT_KEYS.indexOf(main) + 3) % SUBJECT_KEYS.length];

  if (layout === 'swarm') {
    // مطر من كائنات صغيرة خلف البطل
    const n = R.int(8, 14);
    for (let i = 0; i < n; i++) {
      body += character(R, pal, other, { x: R.range(15, 285), y: R.range(20, 250), s: R.range(0.22, 0.38), rot: R.range(-40, 40), decorate: false });
    }
  }

  if (layout === 'hero' || layout === 'swarm') {
    const s = R.range(1.25, 1.6);
    const float = R.chance(0.35);
    const sub = SUBJECTS[main];
    const y = Math.min(bg.groundY - sub.bottom * s - (float ? 55 : 8), 260);
    body += shadow(150, bg.groundY + 6, sub.halfW * s * 0.8, float);
    body += character(R, pal, main, { x: 150, y, s, rot: R.range(-10, 10), flip: R.chance(0.5) });
    if (layout === 'hero') {
      const corner = R.pick([[62, 78], [238, 70], [245, 150], [55, 160]]);
      body += character(R, pal, other, { x: corner[0], y: corner[1], s: R.range(0.4, 0.55), rot: R.range(-25, 25) });
    }
  } else if (layout === 'stack') {
    // برج عبثي: كائن يقف فوق كائن
    const a = SUBJECTS[main], b = SUBJECTS[other];
    const s1 = R.range(0.95, 1.15), s2 = R.range(0.7, 0.9);
    const y1 = bg.groundY - a.bottom * s1;
    const y2 = y1 + a.top * s1 - b.bottom * s2 + 6;
    body += shadow(150, bg.groundY + 6, a.halfW * s1 * 0.8, false);
    body += character(R, pal, main, { x: 150, y: y1, s: s1, decorate: false });
    body += character(R, pal, other, { x: 150 + R.range(-10, 10), y: Math.max(y2, 70), s: s2, rot: R.range(-12, 12) });
  } else {
    // ثنائي يتحدق أحدهما في الآخر
    const s = R.range(0.8, 0.95);
    for (const [k, x, flip] of [[main, 88, false], [other, 212, true]]) {
      const sub = SUBJECTS[k];
      body += shadow(x, bg.groundY + 6, sub.halfW * s * 0.8, false);
      body += character(R, pal, k, { x, y: bg.groundY - sub.bottom * s - 6, s, flip });
    }
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${body}</svg>`;
}

module.exports = { generateSurrealSVG, SUBJECT_KEYS };
