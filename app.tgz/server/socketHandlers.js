'use strict';
/**
 * أحداث Socket.IO. كل حدث يمر بـ: حد المعدل ← تحديد الغرفة واللاعب ← منطق Room (يتحقق من كل شيء) ← ack.
 * منفصل عن server.js ليُختبر بخادم وهمي دون شبكة.
 */
const cfg = require('./config');
const { RoomError } = require('./Room');

function registerSocketHandlers(io, manager) {
  /** غلاف موحّد: حد المعدل + تحويل الأخطاء إلى ack({ok:false}) */
  function handler(socket, fn) {
    return async (payload, ack) => {
      const reply = typeof ack === 'function' ? ack : () => {};
      const now = Date.now();
      const rl = socket.data.rate;
      if (now - rl.start > cfg.RATE_LIMIT.WINDOW_MS) { rl.start = now; rl.count = 0; }
      if (++rl.count > cfg.RATE_LIMIT.EVENTS) {
        return reply({ ok: false, code: 'RATE_LIMIT', error: 'طلبات كثيرة جداً. تمهّل قليلاً.' });
      }
      try {
        const result = await fn(payload && typeof payload === 'object' ? payload : {});
        return reply({ ok: true, ...(result || {}) });
      } catch (err) {
        if (err instanceof RoomError) return reply({ ok: false, code: err.code, error: err.message });
        console.error('[socket] unexpected error', err);
        return reply({ ok: false, code: 'SERVER_ERROR', error: 'حدث خطأ غير متوقع في الخادم.' });
      }
    };
  }

  function context(socket) {
    const { code, playerId } = socket.data;
    const room = code && manager.rooms.get(code);
    if (!room || !playerId || !room.players.has(playerId)) throw new RoomError('NOT_IN_ROOM', 'انضم إلى غرفة أولاً.');
    return { room, playerId };
  }

  /** ربط الاتصال باللاعب وإغلاق أي تبويب قديم للجلسة نفسها */
  function bind(socket, room, player, previousSocketId) {
    if (previousSocketId && previousSocketId !== socket.id) {
      const old = io.sockets.sockets.get(previousSocketId);
      if (old) { old.data.playerId = null; old.data.code = null; old.emit('session:replaced'); }
    }
    socket.data.code = room.code;
    socket.data.playerId = player.id;
    socket.join(room.code);
  }

  function detach(socket) {
    const { code, playerId } = socket.data;
    const room = code && manager.rooms.get(code);
    if (room && playerId) {
      room.leave(playerId);
      if (room.players.size === 0) manager.deleteRoom(code);
    }
    if (code) socket.leave(code);
    socket.data.code = null;
    socket.data.playerId = null;
  }

  const session = (room, player) => ({ code: room.code, playerId: player.id, sessionId: player.token });

  io.on('connection', (socket) => {
    socket.data.rate = { start: Date.now(), count: 0 };

    socket.on('room:create', handler(socket, ({ name, rounds, votingSeconds, imageStyle }) => {
      detach(socket);
      const room = manager.createRoom({ rounds, votingSeconds, imageStyle });
      try {
        const player = room.addPlayer(name, socket.id);
        bind(socket, room, player);
        room.emit();
        return session(room, player);
      } catch (err) {
        manager.deleteRoom(room.code);
        throw err;
      }
    }));

    socket.on('room:join', handler(socket, ({ code, name }) => {
      const room = manager.getRoom(code);
      detach(socket);
      const player = room.addPlayer(name, socket.id);
      bind(socket, room, player);
      room.emit();
      return session(room, player);
    }));

    socket.on('room:rejoin', handler(socket, ({ code, sessionId }) => {
      const room = manager.getRoom(code);
      const prev = room.findByToken(sessionId)?.socketId;
      const player = room.reconnect(sessionId, socket.id);
      bind(socket, room, player, prev);
      room.emit();
      return session(room, player);
    }));

    socket.on('room:leave', handler(socket, () => { detach(socket); }));

    socket.on('game:setRounds', handler(socket, ({ rounds }) => {
      const { room, playerId } = context(socket);
      room.setRounds(playerId, rounds);
    }));

    socket.on('game:settings', handler(socket, ({ rounds, votingSeconds, imageStyle }) => {
      const { room, playerId } = context(socket);
      room.updateSettings(playerId, { rounds, votingSeconds, imageStyle });
    }));

    socket.on('round:extendVoting', handler(socket, () => {
      const { room, playerId } = context(socket);
      room.extendVoting(playerId);
    }));

    socket.on('room:react', handler(socket, ({ emoji }) => {
      const { room, playerId } = context(socket);
      room.react(playerId, emoji);
    }));

    socket.on('game:start', handler(socket, () => {
      const { room, playerId } = context(socket);
      room.startGame(playerId);
    }));

    socket.on('round:describe', handler(socket, ({ imageId, description }) => {
      const { room, playerId } = context(socket);
      room.storytellerSubmit(playerId, imageId, description);
    }));

    socket.on('round:submit', handler(socket, ({ imageId }) => {
      const { room, playerId } = context(socket);
      room.playerSubmit(playerId, imageId);
    }));

    socket.on('round:vote', handler(socket, ({ cardId }) => {
      const { room, playerId } = context(socket);
      room.vote(playerId, cardId);
    }));

    socket.on('round:continue', handler(socket, () => {
      const { room, playerId } = context(socket);
      room.continueFromScoring(playerId);
    }));

    socket.on('game:restart', handler(socket, () => {
      const { room, playerId } = context(socket);
      room.restart(playerId);
    }));

    socket.on('disconnect', () => {
      const { code, playerId } = socket.data;
      const room = code && manager.rooms.get(code);
      const player = room?.players.get(playerId);
      // نتجاهل انقطاع اتصال قديم إن كان اللاعب انتقل لاتصال جديد
      if (player && player.socketId === socket.id) room.handleDisconnect(playerId);
    });
  });
}

module.exports = { registerSocketHandlers };
