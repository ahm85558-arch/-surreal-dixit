'use strict';
/**
 * أرشيف دائم للوحات المولّدة في Cloudflare Workers KV (مجاني).
 *
 * لماذا؟ ذاكرة الخادم تُمسح عند كل تحديث أو عند نوم الموقع، فتضيع اللوحات ورصيد الرسم.
 * الأرشيف يحفظ كل لوحة تُرسم، فتبقى متاحة دائماً وتتراكم يوماً بعد يوم،
 * وعند نفاد رصيد الرسم تستمر اللعبة بلوحات الأرشيف.
 *
 * حدود الخطة المجانية (تتجدد 00:00 UTC): 1GB تخزين، 1000 كتابة/يوم، 100,000 قراءة/يوم.
 * نتوقف عن الأرشفة قبل امتلاء المساحة (ARCHIVE_MAX_MB، افتراضي 950).
 *
 * يحتاج: CF_ACCOUNT_ID، ورمزاً بصلاحية "Workers KV Storage: Edit"
 * (CF_KV_TOKEN، أو CF_API_TOKEN نفسه إن أُضيفت له الصلاحية).
 * مساحة التخزين (namespace) تُنشأ تلقائياً باسم surreal-dixit-archive، أو حدّدها بـ CF_KV_NAMESPACE_ID.
 *
 * اسم كل مفتاح: <معرّف اللوحة>_<حجمها بالبايت> — ليعرف الخادم الحجم الكلي من قائمة المفاتيح فقط.
 */

const API = 'https://api.cloudflare.com/client/v4';
const TITLE = 'surreal-dixit-archive';

class Archive {
  constructor({ logger = console, fetchImpl = globalThis.fetch, env = process.env } = {}) {
    this.log = logger;
    this.fetch = fetchImpl;
    this.account = env.CF_ACCOUNT_ID || '';
    this.token = env.CF_KV_TOKEN || env.CF_API_TOKEN || '';
    this.namespace = env.CF_KV_NAMESPACE_ID || '';
    this.maxBytes = (Number(env.ARCHIVE_MAX_MB) || 950) * 1024 * 1024;
    this.enabled = !!(this.account && this.token && typeof this.fetch === 'function') && env.ARCHIVE_DISABLED !== '1';
    this.ready = false;
    this.entries = new Map(); // id → size
    this.totalBytes = 0;
  }

  headers(extra = {}) {
    return { Authorization: `Bearer ${this.token}`, ...extra };
  }

  base() {
    return `${API}/accounts/${this.account}/storage/kv/namespaces`;
  }

  async api(path, opts = {}) {
    const res = await this.fetch(`${this.base()}${path}`, {
      ...opts,
      headers: this.headers(opts.headers),
      signal: AbortSignal.timeout(30_000),
    });
    return res;
  }

  /** إيجاد مساحة التخزين أو إنشاؤها، ثم قراءة قائمة اللوحات المؤرشفة */
  async init() {
    if (!this.enabled) return [];
    try {
      if (!this.namespace) {
        const res = await this.api('?per_page=100');
        if (res.status === 401 || res.status === 403) return this.denied(res.status);
        const data = await res.json();
        const found = (data.result || []).find((n) => n.title === TITLE);
        if (found) {
          this.namespace = found.id;
        } else {
          const created = await this.api('', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: TITLE }),
          });
          if (created.status === 401 || created.status === 403) return this.denied(created.status);
          const c = await created.json();
          if (!c.success) throw new Error(JSON.stringify(c.errors || c).slice(0, 200));
          this.namespace = c.result.id;
          this.log.info?.(`[archive] أُنشئت مساحة الأرشيف ${TITLE}`);
        }
      }
      // قائمة المفاتيح (1000 مفتاح لكل طلب)
      let cursor = '';
      do {
        const res = await this.api(`/${this.namespace}/keys?limit=1000${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
        if (res.status === 401 || res.status === 403) return this.denied(res.status);
        const data = await res.json();
        for (const k of data.result || []) {
          const m = /^(a[0-9a-f]{12})_(\d+)$/.exec(k.name);
          if (m) { this.entries.set(m[1], Number(m[2])); this.totalBytes += Number(m[2]); }
        }
        cursor = data.result_info?.cursor || '';
      } while (cursor);
      this.ready = true;
      this.log.info?.(`[archive] الأرشيف جاهز: ${this.entries.size} لوحة (${Math.round(this.totalBytes / 1048576)}MB)`);
      return [...this.entries.keys()];
    } catch (err) {
      this.log.warn?.(`[archive] تعذّر فتح الأرشيف: ${err.message}`);
      this.enabled = false;
      return [];
    }
  }

  denied(status) {
    this.log.warn?.(`[archive] الرمز لا يملك صلاحية Workers KV (HTTP ${status}) — الأرشيف متوقف`);
    this.enabled = false;
    return [];
  }

  has(id) {
    return this.entries.has(id);
  }

  /** حفظ لوحة. يعيد true عند النجاح */
  async put(id, buf) {
    if (!this.ready || this.entries.has(id)) return false;
    if (this.totalBytes + buf.length > this.maxBytes) return false; // اقتربنا من حد المساحة المجانية
    try {
      const res = await this.api(`/${this.namespace}/values/${id}_${buf.length}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: buf,
      });
      if (!res.ok) {
        this.log.warn?.(`[archive] فشل الحفظ: HTTP ${res.status}`);
        return false;
      }
      this.entries.set(id, buf.length);
      this.totalBytes += buf.length;
      return true;
    } catch (err) {
      this.log.warn?.(`[archive] خطأ في الحفظ: ${err.message}`);
      return false;
    }
  }

  /** قراءة لوحة من الأرشيف (Buffer أو null) */
  async get(id) {
    const size = this.entries.get(id);
    if (!this.ready || size === undefined) return null;
    try {
      const res = await this.api(`/${this.namespace}/values/${id}_${size}`);
      if (!res.ok) return null;
      return Buffer.from(await res.arrayBuffer());
    } catch {
      return null;
    }
  }

  stats() {
    return { archive: this.ready, archived: this.entries.size, archiveMB: Math.round(this.totalBytes / 1048576) };
  }
}

/** نوع الصورة من أول بايتات */
function sniffType(buf) {
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf[0] === 0x52 && buf[1] === 0x49) return 'image/webp';
  return 'image/jpeg';
}

module.exports = { Archive, sniffType };
