'use strict';
/**
 * مزوّد الصور — صور فريدة لكل جولة، مع رابط بديل (fallback) لكل صورة.
 *
 * IMAGE_SOURCE:
 *  - generated (افتراضي ومضمون): صور يرسمها الخادم حسب اختيار المضيف — ألف ليلة سريالية
 *    مستوحاة من رواد السريالية (nightsArt.js)، أو لوحات حالمة (dreamArt.js)، أو ميمز مضحكة (surrealArt.js).
 *    لا تعتمد على الإنترنت، آمنة 100%، ولا تنفد فلا تتكرر داخل الجولة.
 *  - imgflip: قوالب الميمز الشهيرة من api.imgflip.com (بلا مفتاح) + فلتر كلمات.
 *  - reddit: ميمز سريالية من meme-api.com + فلتر nsfw/spoiler/كلمات.
 *  - folder: صور منتقاة يدوياً في مجلد memes/ بجانب package.json.
 *
 * في المصادر الخارجية: لكل صورة fallback مولّد محلياً يستخدمه المتصفح إن تعذّر تحميلها،
 * وإن فشل الـ API كله يكمل الخادم بالصور المولّدة. لذلك لا تتعطل الجولة أبداً بسبب الصور.
 */
const fs = require('fs');
const path = require('path');
const { randomId, shuffle } = require('./random');

const MEMES_DIR = path.join(__dirname, '..', 'memes');
const IMAGE_EXT = /\.(jpe?g|png|gif|webp|svg)$/i;
const REMOTE_TTL_MS = 6 * 60 * 60 * 1000;

// فلتر المحتوى للمصادر الخارجية
const BLOCKED_WORDS = [
  'nsfw', 'nude', 'naked', 'sex', 'porn', 'boob', 'dick', 'butt', 'gore', 'blood', 'dead', 'death', 'kill',
  'murder', 'gun', 'shoot', 'suicide', 'drug', 'weed', 'drunk', 'beer', 'nazi', 'hitler', 'war', 'bomb',
  'terror', 'rape', 'abuse', 'racist', 'religion', 'god', 'jesus', 'allah', 'church', 'politic', 'trump',
  'biden', 'putin', 'hell', 'devil', 'satan',
];
const SUBREDDITS = ['surrealmemes', 'wholesomememes'];

const hasBlockedWord = (text) => {
  const t = String(text || '').toLowerCase();
  return BLOCKED_WORDS.some((w) => t.includes(w));
};

function isSafeRemote({ url, title, nsfw, spoiler }) {
  if (nsfw || spoiler) return false;
  if (typeof url !== 'string' || !/^https:\/\//.test(url) || !IMAGE_EXT.test(url)) return false;
  return !hasBlockedWord(title);
}

/**
 * صورة مولّدة جديدة (id عشوائي تشفيرياً). البادئة تحدد المولّد:
 * nights → ألف ليلة سريالية (nightsArt، n) · serious → لوحات حالمة (dreamArt، s) · playful → ميمز مضحكة (surrealArt، g)
 */
const STYLE_PREFIX = { nights: 'n', serious: 's', playful: 'g', realistic: 'n' };
function generatedImage(style = 'nights') {
  const id = `${STYLE_PREFIX[style] || 'n'}${randomId(6)}`;
  return { id, url: `/img/${id}.svg`, fallback: null };
}

class ImageProvider {
  constructor({ source = 'generated', logger = console, fetchImpl = globalThis.fetch, aiPool = null } = {}) {
    this.source = source;
    this.aiPool = aiPool; // لوحات الذكاء الاصطناعي المولّدة مسبقاً (اختياري)
    this.log = logger;
    this.fetch = fetchImpl;
    this.remote = [];          // [{id,url}]
    this.remoteLoadedAt = 0;
    this.loading = null;
    this.folder = [];

    if (source === 'folder') {
      try {
        this.folder = fs.readdirSync(MEMES_DIR)
          .filter((n) => IMAGE_EXT.test(n))
          .map((n) => ({ id: `f-${n.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 50)}`, url: `/memes/${encodeURIComponent(n)}` }));
        this.log.info?.(`[images] ${this.folder.length} صورة من مجلد memes/`);
      } catch {
        this.log.warn?.('[images] مجلد memes/ غير موجود — سنستخدم الصور المولّدة.');
      }
    }
  }

  /** تجهيز مسبق: يبدأ توليد اللوحات الواقعية (يُستدعى عند إنشاء غرفة) */
  warmUp() {
    this.aiPool?.start();
  }

  /**
   * @param {number} count
   * @param {Set<string>} used معرّفات استُخدمت في اللعبة (نتجنبها)
   * @param {'realistic'|'nights'|'serious'|'playful'} style نمط الصور (يختاره المضيف)
   * @returns {Promise<{id:string,url:string,fallback:string|null}[]>}
   */
  async getImages(count, used = new Set(), style = 'realistic') {
    // اللوحات الواقعية: من مخزون الذكاء الاصطناعي، مع بديل مرسوم محلياً لكل لوحة،
    // وإكمال أي نقص بلوحات ألف ليلة المولّدة
    if (style === 'realistic') {
      const ai = this.aiPool ? this.aiPool.take(count, used) : [];
      const out = ai.map((img) => ({ ...img, fallback: generatedImage('nights').url }));
      while (out.length < count) out.push(generatedImage('nights'));
      return out;
    }

    let pool = [];
    if (this.source === 'folder') pool = this.folder;
    else if (this.source === 'imgflip' || this.source === 'reddit') {
      await this.ensureRemote();
      pool = this.remote;
    }

    const out = [];
    const taken = new Set();
    // نفضّل الصور غير المستخدمة في هذه اللعبة، ثم نعيد استخدام صور جولات سابقة إن نفدت
    const fresh = shuffle(pool.filter((i) => !used.has(i.id)));
    const old = shuffle(pool.filter((i) => used.has(i.id)));
    for (const img of [...fresh, ...old]) {
      if (out.length >= count) break;
      if (taken.has(img.id)) continue;
      taken.add(img.id);
      out.push({ id: img.id, url: img.url, fallback: generatedImage(style).url });
    }
    // الإكمال بالمولّد دائماً: لا تكرار داخل الجولة مهما كان عدد اللاعبين
    while (out.length < count) out.push(generatedImage(style));
    return out;
  }

  async ensureRemote() {
    const fresh = this.remote.length && Date.now() - this.remoteLoadedAt < REMOTE_TTL_MS;
    if (fresh || typeof this.fetch !== 'function') return;
    if (!this.loading) {
      this.loading = (this.source === 'imgflip' ? this.loadImgflip() : this.loadReddit())
        .then((list) => {
          if (list.length) { this.remote = list; this.remoteLoadedAt = Date.now(); }
        })
        .catch((err) => this.log.warn?.(`[images] فشل المصدر الخارجي: ${err.message}`))
        .finally(() => { this.loading = null; });
    }
    await this.loading;
  }

  async getJson(url) {
    const res = await this.fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  async loadImgflip() {
    const data = await this.getJson('https://api.imgflip.com/get_memes');
    return (data?.data?.memes || [])
      .filter((m) => isSafeRemote({ url: m.url, title: m.name }))
      .map((m) => ({ id: `i-${String(m.id).replace(/[^a-zA-Z0-9]/g, '')}`, url: m.url }));
  }

  async loadReddit() {
    const list = [];
    const seen = new Set();
    for (const sub of SUBREDDITS) {
      try {
        const data = await this.getJson(`https://meme-api.com/gimme/${sub}/50`);
        for (const m of data.memes || []) {
          if (!isSafeRemote(m)) continue;
          const id = `r-${Buffer.from(m.url).toString('base64url').slice(-40)}`;
          if (!seen.has(id)) { seen.add(id); list.push({ id, url: m.url }); }
        }
      } catch (err) {
        this.log.warn?.(`[images] r/${sub}: ${err.message}`);
      }
    }
    return list;
  }
}

module.exports = { ImageProvider, generatedImage, isSafeRemote };
