'use strict';
/**
 * احتساب نقاط الجولة بقواعد Dixit الأصلية — دالة نقية (بدون حالة) لتسهيل الاختبار.
 *
 *  - عرف الجميع صورة الراوي، أو لم يعرفها أحد → الراوي 0، وكل لاعب آخر +2
 *    (الوصف كان واضحاً جداً أو غامضاً جداً).
 *  - عرفها بعضهم فقط → الراوي +3، وكل من عرفها +3، ومن لم يعرفها 0.
 *  - في كل الحالات: كل لاعب (غير الراوي) +1 عن كل صوت على صورته (نقاط الخداع).
 *
 * @param {object}   p
 * @param {string}   p.storytellerId
 * @param {string}   p.storytellerCardId
 * @param {Object<string,string>} p.cardOwners  cardId → playerId (البطاقات الموجودة على الطاولة فقط)
 * @param {Object<string,string>} p.votes       voterId → cardId
 * @param {string[]} p.voterIds  المصوّتون المؤهلون (لاعبون نشطون غير الراوي)
 */
function scoreRound({ storytellerId, storytellerCardId, cardOwners, votes, voterIds }) {
  const deltas = {};
  const add = (id, n) => { deltas[id] = (deltas[id] || 0) + n; };
  add(storytellerId, 0);
  voterIds.forEach((v) => add(v, 0));

  // نحتسب الأصوات الصالحة فقط: بطاقة موجودة، وليست بطاقة المصوّت نفسه
  const valid = voterIds.filter((v) => {
    const card = votes[v];
    return card && cardOwners[card] && cardOwners[card] !== v;
  });

  if (valid.length === 0) {
    return { deltas, outcome: 'VOID', correctVoters: [], validVoters: [] };
  }

  const correctVoters = valid.filter((v) => votes[v] === storytellerCardId);
  let outcome;
  if (correctVoters.length === 0 || correctVoters.length === valid.length) {
    outcome = correctVoters.length === 0 ? 'NONE' : 'ALL';
    voterIds.forEach((v) => add(v, 2));
  } else {
    outcome = 'SOME';
    add(storytellerId, 3);
    correctVoters.forEach((v) => add(v, 3));
  }

  // نقاط الخداع: كل صوت على بطاقة لاعب غير الراوي يمنح صاحبها نقطة
  for (const v of valid) {
    const owner = cardOwners[votes[v]];
    if (owner !== storytellerId) add(owner, 1);
  }

  return { deltas, outcome, correctVoters, validVoters: valid };
}

/**
 * ترتيب نهائي مع معالجة التعادل (ترتيب تنافسي: 1، 1، 3...).
 * المتعادلون في النقاط يتشاركون المركز نفسه.
 */
function rankPlayers(players) {
  const sorted = [...players].sort((a, b) => b.score - a.score || a.joinOrder - b.joinOrder);
  let rank = 0;
  return sorted.map((p, i) => {
    if (i === 0 || p.score !== sorted[i - 1].score) rank = i + 1;
    return { ...p, rank };
  });
}

module.exports = { scoreRound, rankPlayers };
