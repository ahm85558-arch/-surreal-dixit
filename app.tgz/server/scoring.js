'use strict';
/**
 * احتساب نقاط الجولة — دالة نقية (بدون حالة) لتسهيل الاختبار.
 *
 * القواعد:
 *  - أصاب لاعب واحد أو أكثر (وليس الجميع) → الراوي +1 لكل مصيب.
 *  - أصاب الجميع → الراوي 0.
 *  - لم يصب أحد → الراوي +2.
 *  - كل صوت على صورة لاعب آخر (غير الراوي) → صاحب الصورة +1.
 *
 * @param {object}   p
 * @param {string}   p.storytellerId
 * @param {string}   p.storytellerCardId
 * @param {Object<string,string>} p.cardOwners  cardId → playerId (البطاقات الموجودة على الطاولة فقط)
 * @param {Object<string,string>} p.votes       voterId → cardId
 * @param {string[]} p.voterIds  المصوّتون المؤهلون (لاعبون نشطون غير الراوي)
 */
function scoreRound({ storytellerId, storytellerCardId, cardOwners, votes, voterIds }) {
  const deltas = {};
  const add = (id, n) => { deltas[id] = (deltas[id] || 0) + n; };
  add(storytellerId, 0);
  voterIds.forEach((v) => add(v, 0));

  // نحتسب الأصوات الصالحة فقط: بطاقة موجودة، وليست بطاقة المصوّت نفسه
  const valid = voterIds.filter((v) => {
    const card = votes[v];
    return card && cardOwners[card] && cardOwners[card] !== v;
  });

  if (valid.length === 0) {
    return { deltas, outcome: 'VOID', correctVoters: [], validVoters: [] };
  }

  const correctVoters = valid.filter((v) => votes[v] === storytellerCardId);
  let outcome;
  if (correctVoters.length === 0) {
    outcome = 'NONE';
    add(storytellerId, 2);
  } else if (correctVoters.length === valid.length) {
    outcome = 'ALL';
  } else {
    outcome = 'SOME';
    add(storytellerId, correctVoters.length);
  }

  // نقاط الخداع: كل صوت على بطاقة لاعب غير الراوي يمنح صاحبها نقطة
  for (const v of valid) {
    const owner = cardOwners[votes[v]];
    if (owner !== storytellerId) add(owner, 1);
  }

  return { deltas, outcome, correctVoters, validVoters: valid };
}

/**
 * ترتيب نهائي مع معالجة التعادل (ترتيب تنافسي: 1، 1، 3...).
 * المتعادلون في النقاط يتشاركون المركز نفسه.
 */
function rankPlayers(players) {
  const sorted = [...players].sort((a, b) => b.score - a.score || a.joinOrder - b.joinOrder);
  let rank = 0;
  return sorted.map((p, i) => {
    if (i === 0 || p.score !== sorted[i - 1].score) rank = i + 1;
    return { ...p, rank };
  });
}

module.exports = { scoreRound, rankPlayers };
