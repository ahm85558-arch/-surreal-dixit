'use strict';
/**
 * مولّد لوحات سريالية "جادة" بأسلوب حالم قريب من بطاقات Dixit ولوحات ماغريت ودالي:
 * سماء متدرجة، أفق هادئ، ضباب، ظلال طويلة، وعنصر غامض واحد (باب مضيء في الصحراء،
 * سلّم ينتهي في الفراغ، حوت يسبح في السماء، شجرة معلّقة فوق الغيوم...).
 * بلا وجوه كرتونية ولا خطوط سميكة — ظلال وضوء فقط، مع ملمس حبيبي خفيف.
 *
 * حتمي حسب المعرّف: المعرّف نفسه عشوائي تشفيرياً، والرسم يعاد بنفس الشكل دائماً.
 */

const W = 300;
const H = 400;

function hashSeed(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0;
}
function makeRng(seed) {
  let a = seed;
  const r = () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return {
    r,
    range: (x, y) => x + r() * (y - x),
    int: (x, y) => Math.floor(x + r() * (y - x + 1)),
    pick: (arr) => arr[Math.floor(r() * arr.length)],
    chance: (p) => r() < p,
  };
}
const f = (n) => Math.round(n * 10) / 10;

/* ---------- لوحات ألوان هادئة ---------- */
// sky: [أعلى، وسط، أفق] · ground · shadow (الظلال والصور الظلية) · light (الضوء) · accent (لمسة لون واحدة)
const PALETTES = [
  { name: 'dusk', sky: ['#1c2442', '#5d4e86', '#f0a07a'], ground: '#2a2140', shadow: '#16122a', light: '#ffe3b8', accent: '#e8574a', stars: false },
  { name: 'dawn', sky: ['#2b3b5c', '#8aa3c4', '#f3d4b4'], ground: '#3b465a', shadow: '#1e2536', light: '#fff1d6', accent: '#d9534f', stars: false },
  { name: 'night', sky: ['#050918', '#18224a', '#3e4275'], ground: '#0b0e24', shadow: '#03050f', light: '#f4efd9', accent: '#d8b45a', stars: true },
  { name: 'desert', sky: ['#35264a', '#c4744c', '#f1c488'], ground: '#6e4230', shadow: '#2a1a1f', light: '#fff0cc', accent: '#2f6f8f', stars: false },
  { name: 'sea', sky: ['#0d2533', '#2c6873', '#a9d2c6'], ground: '#0a1d28', shadow: '#061219', light: '#f2f7ea', accent: '#e0703f', stars: false },
  { name: 'fog', sky: ['#383d48', '#878c97', '#d9d5cc'], ground: '#2b2d34', shadow: '#1b1c21', light: '#fbf7ee', accent: '#b8342f', stars: false },
  { name: 'crimson', sky: ['#260c1b', '#732b39', '#dfa27a'], ground: '#3a1622', shadow: '#16060d', light: '#ffe2c0', accent: '#f2c14e', stars: true },
];

/* ---------- عناصر مساعدة ---------- */
function defs(P) {
  return '<defs>'
    + `<linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${P.sky[0]}"/><stop offset=".55" stop-color="${P.sky[1]}"/><stop offset="1" stop-color="${P.sky[2]}"/></linearGradient>`
    + `<linearGradient id="ground" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${P.ground}"/><stop offset="1" stop-color="${P.shadow}"/></linearGradient>`
    + `<radialGradient id="glow"><stop offset="0" stop-color="${P.light}" stop-opacity=".9"/><stop offset=".35" stop-color="${P.light}" stop-opacity=".35"/><stop offset="1" stop-color="${P.light}" stop-opacity="0"/></radialGradient>`
    + `<linearGradient id="beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${P.light}" stop-opacity=".55"/><stop offset="1" stop-color="${P.light}" stop-opacity="0"/></linearGradient>`
    + '<linearGradient id="fog" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".22"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'
    + '<radialGradient id="vignette" cx=".5" cy=".45" r=".75"><stop offset=".6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".5"/></radialGradient>'
    + '<filter id="grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" stitchTiles="stitch"/>'
    + '<feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .09"/></feComponentTransfer></filter>'
    + '<filter id="soft"><feGaussianBlur stdDeviation="2"/></filter>'
    + '</defs>';
}

function stars(R, n, maxY) {
  let s = '';
  for (let i = 0; i < n; i++) {
    s += `<circle cx="${f(R.range(0, W))}" cy="${f(R.range(0, maxY))}" r="${f(R.range(0.4, 1.4))}" fill="#fff" opacity="${f(R.range(0.3, 0.95))}"/>`;
  }
  return s;
}

function celestial(R, P, { x, y, r, moon }) {
  let s = `<circle cx="${f(x)}" cy="${f(y)}" r="${f(r * 3.2)}" fill="url(#glow)" opacity=".7"/>`;
  s += `<circle cx="${f(x)}" cy="${f(y)}" r="${f(r)}" fill="${P.light}"/>`;
  if (moon) {
    for (let i = 0; i < 4; i++) {
      s += `<circle cx="${f(x + R.range(-r * 0.5, r * 0.5))}" cy="${f(y + R.range(-r * 0.5, r * 0.5))}" r="${f(r * R.range(0.08, 0.2))}" fill="${P.shadow}" opacity=".08"/>`;
    }
  }
  return s;
}

function clouds(R, P, n, y0, y1, op = 0.35) {
  let s = '';
  for (let i = 0; i < n; i++) {
    const x = R.range(-20, 320), y = R.range(y0, y1), w = R.range(50, 120);
    s += `<ellipse cx="${f(x)}" cy="${f(y)}" rx="${f(w)}" ry="${f(w * 0.12)}" fill="${P.light}" opacity="${f(op * R.range(0.5, 1))}"/>`;
  }
  return s;
}

function birds(R, P, n, x0, y0, spread) {
  let s = `<g fill="none" stroke="${P.shadow}" stroke-width="1.3" stroke-linecap="round" opacity=".8">`;
  for (let i = 0; i < n; i++) {
    const x = x0 + R.range(-spread, spread), y = y0 + R.range(-spread * 0.4, spread * 0.4), w = R.range(3, 6);
    s += `<path d="M${f(x - w)} ${f(y)} q${f(w / 2)} ${f(-w / 2)} ${f(w)} 0 q${f(w / 2)} ${f(-w / 2)} ${f(w)} 0"/>`;
  }
  return `${s}</g>`;
}

/** شخص صغير كصورة ظلية — يعطي إحساس الحجم والوحدة */
function figure(R, P, x, y, s = 1, variant = null) {
  const v = variant || R.pick(['stand', 'umbrella', 'balloon', 'stand']);
  const c = P.shadow;
  let g = `<g transform="translate(${f(x)} ${f(y)}) scale(${f(s)})">`;
  g += `<circle cx="0" cy="-21" r="3.2" fill="${c}"/>`;
  g += `<path d="M-3.6 -17 L3.6 -17 L4.6 -6 L2.2 -6 L2 0 L0.6 0 L0 -6 L-0.6 0 L-2 0 L-2.2 -6 L-4.6 -6Z" fill="${c}"/>`;
  if (v === 'umbrella') {
    g += `<path d="M3 -12 L3 -28" stroke="${c}" stroke-width="1"/><path d="M-9 -27 Q3 -40 15 -27Z" fill="${c}"/>`;
  } else if (v === 'balloon') {
    g += `<path d="M4 -12 Q9 -30 6 -46" stroke="${c}" stroke-width=".6" fill="none"/><ellipse cx="6" cy="-51" rx="5" ry="6" fill="${P.accent}"/>`;
  }
  return `${g}</g>`;
}

function longShadow(P, x, y, w, len, angle = 0) {
  return `<path d="M${f(x - w / 2)} ${f(y)} L${f(x + w / 2)} ${f(y)} L${f(x + w / 2 + len * Math.cos(angle))} ${f(y + len * 0.18)} L${f(x - w / 2 + len * Math.cos(angle))} ${f(y + len * 0.18)}Z" fill="${P.shadow}" opacity=".45"/>`;
}

/* ---------- الأرضية ---------- */
function landscape(R, P, horizon) {
  const kind = R.pick(['plain', 'plain', 'sea', 'dunes', 'clouds']);
  let s = '';
  if (kind === 'sea') {
    s += `<rect y="${horizon}" width="${W}" height="${H - horizon}" fill="url(#ground)"/>`;
    for (let y = horizon + 6; y < H; y += R.range(7, 14)) {
      const x = R.range(0, W), w = R.range(20, 90) * (1 + (y - horizon) / 80);
      s += `<line x1="${f(x - w / 2)}" y1="${f(y)}" x2="${f(x + w / 2)}" y2="${f(y)}" stroke="${P.light}" stroke-width=".8" opacity="${f(R.range(0.08, 0.25))}"/>`;
    }
  } else if (kind === 'dunes') {
    s += `<path d="M0 ${horizon} Q80 ${horizon - 12} 160 ${horizon + 4} T300 ${horizon - 4} V400 H0Z" fill="${P.ground}"/>`;
    s += `<path d="M0 ${horizon + 40} Q120 ${horizon + 18} 220 ${horizon + 46} T300 ${horizon + 40} V400 H0Z" fill="${P.shadow}" opacity=".35"/>`;
  } else if (kind === 'clouds') {
    // الأرض بحر من الغيوم: العالم معلّق فوق السماء
    s += `<rect y="${horizon}" width="${W}" height="${H - horizon}" fill="${P.sky[2]}"/>`;
    for (let i = 0; i < 16; i++) {
      const x = R.range(-20, 320), y = horizon + R.range(0, H - horizon), r = R.range(20, 45);
      s += `<circle cx="${f(x)}" cy="${f(y)}" r="${f(r)}" fill="${P.light}" opacity="${f(R.range(0.25, 0.55))}"/>`;
    }
  } else {
    s += `<rect y="${horizon}" width="${W}" height="${H - horizon}" fill="url(#ground)"/>`;
  }
  s += `<rect y="${horizon - 25}" width="${W}" height="50" fill="url(#fog)"/>`;
  return { svg: s, kind };
}

/* ---------- العناصر الغامضة ---------- */
const SUBJECTS = {
  // باب مضيء قائم وحده
  door(R, P, c) {
    const x = R.range(110, 190), s = R.range(0.9, 1.25), w = 46 * s, h = 88 * s;
    const float = R.chance(0.3) ? R.range(20, 60) : 0;
    const base = c.horizon + R.range(30, 70) - float;
    let g = `<ellipse cx="${f(x)}" cy="${f(base - h / 2)}" rx="${f(w * 1.8)}" ry="${f(h)}" fill="url(#glow)" opacity=".55"/>`;
    if (!float) g += `<path d="M${f(x - w / 2)} ${f(base)} L${f(x + w / 2)} ${f(base)} L${f(x + w * 1.6)} ${f(H)} L${f(x - w * 1.6)} ${f(H)}Z" fill="url(#beam)" opacity=".6"/>`;
    g += `<rect x="${f(x - w / 2 - 4)}" y="${f(base - h - 4)}" width="${f(w + 8)}" height="${f(h + 4)}" fill="${P.shadow}"/>`;
    g += `<rect x="${f(x - w / 2)}" y="${f(base - h)}" width="${f(w)}" height="${f(h)}" fill="${P.light}"/>`;
    g += `<path d="M${f(x - w / 2)} ${f(base - h)} L${f(x - w / 2 - w * 0.55)} ${f(base - h + 8)} L${f(x - w / 2 - w * 0.55)} ${f(base + 4)} L${f(x - w / 2)} ${f(base)}Z" fill="${P.shadow}"/>`;
    if (R.chance(0.6)) g += figure(R, P, x + w * 1.4, c.horizon + 60, 1, 'stand');
    return g;
  },

  // سلّم يصعد وينتهي في الفراغ
  stairs(R, P, c) {
    const steps = R.int(9, 14), sw = R.range(14, 18), sh = R.range(11, 15);
    const dir = R.chance(0.5) ? 1 : -1;
    const x0 = dir > 0 ? R.range(40, 80) : R.range(220, 260), y0 = c.horizon + 60;
    let g = '';
    for (let i = 0; i < steps; i++) {
      const x = x0 + dir * i * sw, y = y0 - i * sh;
      g += `<rect x="${f(dir > 0 ? x : x - sw)}" y="${f(y - sh)}" width="${f(sw + 0.6)}" height="${f(sh + (i === 0 ? 0 : 6))}" fill="${P.shadow}"/>`;
    }
    const tx = x0 + dir * (steps - 0.5) * sw, ty = y0 - steps * sh;
    g += `<circle cx="${f(tx)}" cy="${f(ty - 30)}" r="40" fill="url(#glow)" opacity=".45"/>`;
    if (R.chance(0.7)) g += figure(R, P, tx, ty, 0.9, R.pick(['stand', 'balloon']));
    return g;
  },

  // سلّم خشبي طويل نحو القمر
  ladder(R, P, c) {
    const mx = R.range(90, 210), my = R.range(60, 100), mr = R.range(32, 46);
    let g = celestial(R, P, { x: mx, y: my, r: mr, moon: true });
    const bx = mx + R.range(-60, 60), by = c.horizon + 55;
    const tx = mx + R.range(-10, 10), ty = my + mr - 6;
    const dx = 7;
    g += `<path d="M${f(bx - dx)} ${f(by)} L${f(tx - dx * 0.5)} ${f(ty)} M${f(bx + dx)} ${f(by)} L${f(tx + dx * 0.5)} ${f(ty)}" stroke="${P.shadow}" stroke-width="2.4"/>`;
    for (let t = 0.05; t < 1; t += 0.055) {
      const k = 1 - t * 0.5;
      const x = bx + (tx - bx) * t, y = by + (ty - by) * t;
      g += `<line x1="${f(x - dx * k)}" y1="${f(y)}" x2="${f(x + dx * k)}" y2="${f(y)}" stroke="${P.shadow}" stroke-width="1.6"/>`;
    }
    g += figure(R, P, bx + 22, by + 2, 1, 'stand');
    return g;
  },

  // شجرة عارية — أحياناً معلّقة على جزيرة طائرة، وأحياناً تحمل فوانيس
  tree(R, P, c) {
    const floating = R.chance(0.4);
    const x = R.range(120, 180);
    const baseY = floating ? R.range(210, 250) : c.horizon + R.range(40, 70);
    let branches = '';
    const lamps = [];
    const lanterns = R.chance(0.45);
    const grow = (x1, y1, len, ang, depth) => {
      const x2 = x1 + Math.cos(ang) * len, y2 = y1 + Math.sin(ang) * len;
      branches += `<line x1="${f(x1)}" y1="${f(y1)}" x2="${f(x2)}" y2="${f(y2)}" stroke="${P.shadow}" stroke-width="${f(Math.max(0.6, depth * 1.6))}" stroke-linecap="round"/>`;
      if (depth <= 1) { if (lanterns && R.chance(0.35)) lamps.push([x2, y2]); return; }
      const n = R.chance(0.3) ? 3 : 2;
      for (let i = 0; i < n; i++) grow(x2, y2, len * R.range(0.66, 0.8), ang + R.range(-0.62, 0.62), depth - 1);
    };
    grow(x, baseY, R.range(52, 64), -Math.PI / 2 + R.range(-0.08, 0.08), 7);
    let g = '';
    if (floating) {
      g += `<path d="M${f(x - 50)} ${f(baseY)} Q${f(x)} ${f(baseY - 6)} ${f(x + 50)} ${f(baseY)} L${f(x + 12)} ${f(baseY + 50)} L${f(x - 6)} ${f(baseY + 68)} L${f(x - 22)} ${f(baseY + 40)}Z" fill="${P.shadow}"/>`;
      for (let i = 0; i < 6; i++) {
        const rx = x + R.range(-20, 20);
        g += `<path d="M${f(rx)} ${f(baseY + 30)} q${f(R.range(-10, 10))} 25 ${f(R.range(-6, 6))} ${f(R.range(40, 70))}" stroke="${P.shadow}" stroke-width=".8" fill="none" opacity=".8"/>`;
      }
    } else {
      g += longShadow(P, x, baseY, 10, R.range(90, 160));
    }
    g += branches;
    for (const [lx, ly] of lamps) {
      g += `<circle cx="${f(lx)}" cy="${f(ly + 4)}" r="9" fill="url(#glow)"/><rect x="${f(lx - 2)}" y="${f(ly + 1)}" width="4" height="6" rx="1" fill="${P.light}"/>`;
    }
    return g;
  },

  // حوت يسبح في السماء
  whale(R, P, c) {
    const x = R.range(90, 210), y = R.range(110, 170), s = R.range(0.9, 1.3), flip = R.chance(0.5) ? -1 : 1;
    let g = `<g transform="translate(${f(x)} ${f(y)}) scale(${f(s * flip)} ${f(s)})">`;
    g += `<path d="M-70 4 C-66 -26 -20 -34 18 -24 C40 -18 56 -8 66 -16 C72 -26 80 -30 88 -34 C84 -22 82 -12 88 2 C78 -2 70 -4 64 0 C50 18 10 26 -20 24 C-50 22 -70 18 -70 4Z" fill="${P.shadow}"/>`;
    g += `<path d="M-30 18 C-26 30 -14 34 -6 30 C-12 26 -18 22 -20 16Z" fill="${P.shadow}"/>`;
    g += '</g>';
    g += `<ellipse cx="${f(x)}" cy="${f(c.horizon + 40)}" rx="${f(70 * s)}" ry="6" fill="${P.shadow}" opacity=".3"/>`;
    g += figure(R, P, x + R.range(-40, 40), c.horizon + 48, 1, R.pick(['stand', 'umbrella']));
    return g;
  },

  // جزر معلّقة في الهواء
  islands(R, P) {
    let g = '';
    const n = R.int(3, 5);
    for (let i = 0; i < n; i++) {
      const x = R.range(40, 260), y = R.range(90, 280), w = R.range(18, 48);
      g += `<path d="M${f(x - w)} ${f(y)} Q${f(x)} ${f(y - w * 0.18)} ${f(x + w)} ${f(y)} L${f(x + w * 0.2)} ${f(y + w * 1.1)} L${f(x - w * 0.3)} ${f(y + w * 0.7)}Z" fill="${P.shadow}" opacity="${f(0.7 + i * 0.07)}"/>`;
      if (R.chance(0.5)) g += `<rect x="${f(x - 5)}" y="${f(y - 11)}" width="10" height="10" fill="${P.shadow}"/><path d="M${f(x - 7)} ${f(y - 11)} L${f(x)} ${f(y - 18)} L${f(x + 7)} ${f(y - 11)}Z" fill="${P.shadow}"/><rect x="${f(x - 1.5)}" y="${f(y - 7)}" width="3" height="3" fill="${P.light}"/>`;
    }
    return g;
  },

  // قمر عملاق قريب جداً من الأفق
  giantMoon(R, P, c) {
    const x = R.range(110, 190), r = R.range(70, 95);
    // القمر يُرسم خلف الأرض (back) ليغيب نصفه خلف الأفق
    const back = celestial(R, P, { x, y: c.horizon - r * 0.35, r, moon: true });
    const front = figure(R, P, x + R.range(-30, 30), c.horizon + 50, 1.1, R.pick(['stand', 'balloon', 'umbrella']));
    return { back, front };
  },

  // قارب صغير — على الماء أو بين الغيوم
  boat(R, P, c) {
    const x = R.range(100, 200), y = R.chance(0.4) ? R.range(140, 200) : c.horizon + R.range(30, 60), s = R.range(0.9, 1.3);
    let g = `<g transform="translate(${f(x)} ${f(y)}) scale(${f(s)})">`;
    g += `<path d="M-30 0 L30 0 L22 10 L-22 10Z" fill="${P.shadow}"/>`;
    g += `<line x1="0" y1="0" x2="0" y2="-46" stroke="${P.shadow}" stroke-width="1.6"/>`;
    g += `<path d="M1 -44 L24 -6 L1 -6Z" fill="${P.light}" opacity=".9"/><path d="M-1 -38 L-18 -6 L-1 -6Z" fill="${P.light}" opacity=".6"/>`;
    g += `<path d="M-22 14 L22 14 L16 20 L-16 20Z" fill="${P.light}" opacity=".12"/>`;
    g += '</g>';
    return g;
  },

  // ساعة رملية عملاقة
  hourglass(R, P, c) {
    const x = R.range(110, 190), s = R.range(0.9, 1.2), base = c.horizon + R.range(40, 70);
    const h = 110 * s, w = 40 * s;
    let g = longShadow(P, x, base, w, R.range(80, 140));
    g += `<rect x="${f(x - w - 6)}" y="${f(base - 6)}" width="${f(2 * w + 12)}" height="6" fill="${P.shadow}"/>`;
    g += `<rect x="${f(x - w - 6)}" y="${f(base - h - 6)}" width="${f(2 * w + 12)}" height="6" fill="${P.shadow}"/>`;
    g += `<path d="M${f(x - w)} ${f(base - h)} L${f(x + w)} ${f(base - h)} L${f(x + 3)} ${f(base - h / 2)} L${f(x + w)} ${f(base - 6)} L${f(x - w)} ${f(base - 6)} L${f(x - 3)} ${f(base - h / 2)}Z" fill="${P.light}" opacity=".22" stroke="${P.shadow}" stroke-width="1.5"/>`;
    g += `<path d="M${f(x - w * 0.55)} ${f(base - h * 0.78)} L${f(x + w * 0.55)} ${f(base - h * 0.78)} L${f(x + 2)} ${f(base - h / 2)} L${f(x - 2)} ${f(base - h / 2)}Z" fill="${P.accent}" opacity=".85"/>`;
    g += `<line x1="${f(x)}" y1="${f(base - h / 2)}" x2="${f(x)}" y2="${f(base - 8)}" stroke="${P.accent}" stroke-width="1"/>`;
    g += `<path d="M${f(x - w * 0.7)} ${f(base - 6)} Q${f(x)} ${f(base - 34 * s)} ${f(x + w * 0.7)} ${f(base - 6)}Z" fill="${P.accent}" opacity=".85"/>`;
    return g;
  },

  // منارة بشعاع ضوء
  lighthouse(R, P, c) {
    const x = R.range(70, 230), base = c.horizon + R.range(10, 40), h = R.range(110, 140);
    const dir = x < 150 ? 1 : -1;
    let g = `<path d="M${f(x)} ${f(base - h + 8)} L${f(x + dir * 320)} ${f(base - h - 60)} L${f(x + dir * 320)} ${f(base - h + 40)}Z" fill="${P.light}" opacity=".18"/>`;
    g += `<path d="M${f(x - 14)} ${f(base)} L${f(x - 8)} ${f(base - h)} L${f(x + 8)} ${f(base - h)} L${f(x + 14)} ${f(base)}Z" fill="${P.shadow}"/>`;
    g += `<rect x="${f(x - 7)}" y="${f(base - h - 12)}" width="14" height="12" fill="${P.light}"/><path d="M${f(x - 10)} ${f(base - h - 12)} L${f(x)} ${f(base - h - 22)} L${f(x + 10)} ${f(base - h - 12)}Z" fill="${P.shadow}"/>`;
    g += `<circle cx="${f(x)}" cy="${f(base - h - 6)}" r="28" fill="url(#glow)" opacity=".7"/>`;
    return g;
  },

  // نافذة معلّقة تطل على سماء أخرى
  window(R, P, c) {
    const x = R.range(95, 205), y = R.range(120, 190), w = R.range(56, 72), h = w * 1.35;
    const alt = PALETTES[(PALETTES.indexOf(P) + R.int(2, 4)) % PALETTES.length];
    let g = `<defs><linearGradient id="alt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${alt.sky[0]}"/><stop offset="1" stop-color="${alt.sky[2]}"/></linearGradient>`
      + `<clipPath id="pane"><rect x="${f(x - w / 2)}" y="${f(y - h / 2)}" width="${f(w)}" height="${f(h)}"/></clipPath></defs>`;
    g += `<rect x="${f(x - w / 2 - 6)}" y="${f(y - h / 2 - 6)}" width="${f(w + 12)}" height="${f(h + 12)}" fill="${P.shadow}"/>`;
    g += `<g clip-path="url(#pane)"><rect x="${f(x - w / 2)}" y="${f(y - h / 2)}" width="${f(w)}" height="${f(h)}" fill="url(#alt)"/>`;
    for (let i = 0; i < 18; i++) g += `<circle cx="${f(x + R.range(-w / 2, w / 2))}" cy="${f(y + R.range(-h / 2, h / 4))}" r="${f(R.range(0.4, 1.2))}" fill="#fff"/>`;
    g += `<circle cx="${f(x + w * 0.18)}" cy="${f(y - h * 0.18)}" r="${f(w * 0.12)}" fill="${alt.light}"/></g>`;
    g += `<path d="M${f(x)} ${f(y - h / 2)} V${f(y + h / 2)} M${f(x - w / 2)} ${f(y)} H${f(x + w / 2)}" stroke="${P.shadow}" stroke-width="3.5"/>`;
    g += `<ellipse cx="${f(x)}" cy="${f(c.horizon + 45)}" rx="${f(w * 0.6)}" ry="4" fill="${P.shadow}" opacity=".35"/>`;
    return g;
  },

  // كرسي فارغ تحت ضوء
  chair(R, P, c) {
    const x = R.range(110, 190), base = c.horizon + R.range(45, 75), s = R.range(1, 1.3);
    let g = `<path d="M${f(x - 10)} 0 L${f(x + 10)} 0 L${f(x + 60)} ${f(base + 10)} L${f(x - 60)} ${f(base + 10)}Z" fill="url(#beam)" opacity=".5"/>`;
    g += `<ellipse cx="${f(x)}" cy="${f(base + 4)}" rx="${f(50 * s)}" ry="${f(8 * s)}" fill="${P.light}" opacity=".18"/>`;
    g += `<g transform="translate(${f(x)} ${f(base)}) scale(${f(s)})" fill="${P.shadow}">`
      + '<rect x="-14" y="-24" width="28" height="4"/><rect x="-14" y="-24" width="3" height="24"/><rect x="11" y="-24" width="3" height="24"/>'
      + '<rect x="11" y="-58" width="3" height="36"/><rect x="-14" y="-58" width="3" height="36" opacity=".6"/><rect x="-14" y="-58" width="28" height="3"/><rect x="-14" y="-46" width="28" height="2"/></g>';
    g += longShadow(P, x, base + 2, 26 * s, 90);
    return g;
  },

  // سرب أسماك في السماء
  fishSky(R, P, c) {
    let g = '';
    const cx = R.range(100, 200), cy = R.range(110, 180), n = R.int(14, 24);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + R.range(-0.2, 0.2);
      const rad = R.range(20, 70);
      const x = cx + Math.cos(a) * rad, y = cy + Math.sin(a) * rad * 0.6, s = R.range(0.5, 1.1);
      g += `<g transform="translate(${f(x)} ${f(y)}) rotate(${f((a * 180) / Math.PI + 90)}) scale(${f(s)})"><path d="M-9 0 Q0 -5 8 0 Q0 5 -9 0Z M8 0 L13 -4 L13 4Z" fill="${P.shadow}"/></g>`;
    }
    g += figure(R, P, cx + R.range(-20, 20), c.horizon + 50, 1, 'stand');
    return g;
  },

  // منطاد هادئ
  balloon(R, P) {
    let g = '';
    const n = R.chance(0.5) ? 1 : R.int(3, 5);
    for (let i = 0; i < n; i++) {
      const x = n === 1 ? R.range(110, 190) : R.range(40, 260), y = R.range(90, 230), s = n === 1 ? R.range(1, 1.4) : R.range(0.3, 0.7);
      g += `<g transform="translate(${f(x)} ${f(y)}) scale(${f(s)})">`
        + `<path d="M0 -40 C24 -40 30 -14 16 6 L6 18 L-6 18 L-16 6 C-30 -14 -24 -40 0 -40Z" fill="${i === 0 ? P.accent : P.shadow}"/>`
        + `<path d="M0 -40 C8 -40 10 -14 5 6 L2 18" fill="none" stroke="${P.shadow}" stroke-width="1" opacity=".5"/>`
        + `<path d="M-6 18 L-5 26 M6 18 L5 26" stroke="${P.shadow}" stroke-width=".8"/><rect x="-6" y="26" width="12" height="8" fill="${P.shadow}"/></g>`;
    }
    return g;
  },

  // قفص طائر بداخله قمر صغير
  cage(R, P, c) {
    const x = R.range(110, 190), y = R.range(120, 190), r = R.range(26, 34);
    let g = `<line x1="${f(x)}" y1="0" x2="${f(x)}" y2="${f(y - r * 1.4)}" stroke="${P.shadow}" stroke-width="1"/>`;
    g += `<circle cx="${f(x)}" cy="${f(y + r * 0.3)}" r="${f(r * 1.8)}" fill="url(#glow)" opacity=".55"/>`;
    g += `<circle cx="${f(x)}" cy="${f(y + r * 0.4)}" r="${f(r * 0.45)}" fill="${P.light}"/>`;
    let bars = '';
    for (let i = -3; i <= 3; i++) {
      const bx = x + (i / 3.2) * r;
      bars += `<path d="M${f(x)} ${f(y - r * 1.2)} Q${f(bx + (bx - x) * 0.3)} ${f(y - r * 0.6)} ${f(bx)} ${f(y + r)}" fill="none" stroke="${P.shadow}" stroke-width="1.4"/>`;
    }
    g += bars + `<rect x="${f(x - r - 2)}" y="${f(y + r)}" width="${f(2 * r + 4)}" height="5" fill="${P.shadow}"/>`;
    g += `<path d="M${f(x + r * 0.2)} ${f(y - r * 1.25)} q5 -8 12 -6 q-3 3 -2 6 q-6 1 -10 0Z" fill="${P.shadow}"/>`;
    return g;
  },
};
const SUBJECT_KEYS = Object.keys(SUBJECTS);

/** نقطة الدخول: SVG كامل للمعرّف */
function generateDreamSVG(id) {
  const R = makeRng(hashSeed(`dream:${id}`));
  const P = R.pick(PALETTES);
  const horizon = f(R.range(250, 290));
  const subject = R.pick(SUBJECT_KEYS);
  const c = { horizon };

  let body = defs(P);
  body += `<rect width="${W}" height="${H}" fill="url(#sky)"/>`;
  if (P.stars || R.chance(0.2)) body += stars(R, R.int(40, 90), horizon - 20);
  if (!['ladder', 'giantMoon'].includes(subject) && R.chance(0.75)) {
    body += celestial(R, P, { x: R.range(40, 260), y: R.range(40, 110), r: R.range(9, 18), moon: P.stars });
  }
  body += clouds(R, P, R.int(1, 4), 60, horizon - 30);
  const drawn = SUBJECTS[subject](R, P, c);
  const layers = typeof drawn === 'string' ? { back: '', front: drawn } : drawn;
  body += layers.back;
  body += landscape(R, P, horizon).svg;
  body += layers.front;
  if (R.chance(0.4)) body += birds(R, P, R.int(3, 8), R.range(60, 240), R.range(60, 140), 30);
  body += `<rect width="${W}" height="${H}" fill="url(#vignette)"/>`;
  body += `<rect width="${W}" height="${H}" filter="url(#grain)"/>`;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${body}</svg>`;
}

module.exports = { generateDreamSVG, DREAM_SUBJECTS: SUBJECT_KEYS };
