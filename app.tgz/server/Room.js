'use strict';
/**
 * الغرفة = آلة الحالة الكاملة للّعبة (Server-Authoritative).
 *
 *  LOBBY → DEALING → STORYTELLER_PHASE → PLAYERS_SUBMIT_PHASE → SHUFFLE_REVEAL → VOTING_PHASE → SCORING_PHASE
 *                ↑                                                                                   │
 *                └──────────────────── (جولة تالية) ─────────────────────────────────────────────────┤
 *                                                                                  (آخر جولة) → GAME_OVER
 *
 * الوحدة مستقلة عن Socket.IO: تستدعي onChange(room) عند كل تغيير، ويرسل RoomManager
 * لكل لاعب "منظوره" الخاص (viewFor) فقط — فلا يمكن تسريب صور الآخرين أو هوية أصحاب البطاقات.
 */
const cfg = require('./config');
const { pick, shuffle, randomId } = require('./random');
const { validateDescription, validateName, validateRounds, isSafeId } = require('./validation');
const { scoreRound, rankPlayers } = require('./scoring');
const { ImageProvider, generatedImage } = require('./imageProvider');

const PHASES = Object.freeze({
  LOBBY: 'LOBBY',
  DEALING: 'DEALING',
  STORYTELLER_PHASE: 'STORYTELLER_PHASE',
  PLAYERS_SUBMIT_PHASE: 'PLAYERS_SUBMIT_PHASE',
  SHUFFLE_REVEAL: 'SHUFFLE_REVEAL',
  VOTING_PHASE: 'VOTING_PHASE',
  SCORING_PHASE: 'SCORING_PHASE',
  GAME_OVER: 'GAME_OVER',
});

// مراحل الجولة الجارية (قبل احتساب النقاط)
const LIVE_ROUND = new Set([
  PHASES.DEALING, PHASES.STORYTELLER_PHASE, PHASES.PLAYERS_SUBMIT_PHASE, PHASES.SHUFFLE_REVEAL, PHASES.VOTING_PHASE,
]);

// أوصاف احتياطية إن انتهى وقت الراوي دون وصف
const AUTO_DESCRIPTIONS = [
  'شيء لا يفترض أن يكون هنا', 'حلم بعد عشاء ثقيل', 'صباح يوم الأحد', 'عندما يرن المنبه',
  'هدوء مريب', 'خطة ممتازة نظرياً', 'أنا أمام الثلاجة في منتصف الليل', 'آخر يوم في الإجازة',
];

class RoomError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

class Room {
  constructor(code, {
    imageProvider = new ImageProvider(),
    onChange = () => {},
    timers = cfg.TIMERS,
    transitions = cfg.TRANSITIONS_MS,
    graceMs = cfg.RECONNECT_GRACE_MS,
    rounds = null,
  } = {}) {
    this.code = code;
    this.images = imageProvider;
    this.onChange = onChange;
    this.timers = timers;
    this.transitions = transitions;
    this.graceMs = graceMs;

    this.players = new Map();
    this.joinCounter = 0;
    this.hostId = null;
    const r = validateRounds(rounds);
    if (!r.ok) throw new RoomError('BAD_ROUNDS', r.error);
    this.customRounds = r.value; // null = عدد اللاعبين
    this.usedImages = new Set();
    this.timer = null;
    this.roundToken = 0;
    this.lastActivity = Date.now();
    this.resetGame();
  }

  /* ======================= أدوات داخلية ======================= */

  resetGame() {
    this.clearTimer();
    this.phase = PHASES.LOBBY;
    this.round = 0;
    this.totalRounds = 0;
    this.storytellerId = null;
    this.order = []; // ترتيب ثابت للأدوار (Round-Robin)
    this.clearRound();
    this.lastResult = null;
    this.final = null;
    this.endReason = null;
    this.deadline = null;
    this.phaseSeconds = null;
  }

  clearRound() {
    this.participants = new Set();   // لاعبو الجولة (يُحذف منهم من تنتهي مهلته)
    this.hands = new Map();          // playerId → [{id,url,fallback}] — سرّي
    this.imageIndex = new Map();     // imageId → {url,fallback}
    this.submissions = new Map();    // playerId → imageId — سرّي
    this.description = null;
    this.autoDescription = false;
    this.autoPicked = new Set();
    this.table = [];                 // [{cardId,url,fallback}] بعد الخلط — بلا أصحاب
    this.cardOwners = new Map();     // cardId → playerId — سرّي حتى النتائج
    this.storytellerCardId = null;
    this.votes = new Map();          // voterId → cardId
  }

  emit() {
    this.lastActivity = Date.now();
    try { this.onChange(this); } catch (err) { console.error('[room] onChange failed', err); }
  }

  clearTimer() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  schedule(ms, fn) {
    this.clearTimer();
    this.timer = setTimeout(() => {
      this.timer = null;
      try { fn(); } catch (err) { console.error(`[room ${this.code}] timer error`, err); }
    }, ms);
  }

  /** الانتقال لمرحلة مع مؤقت تنازلي اختياري وإجراء تلقائي عند انتهائه */
  setPhase(phase, seconds, onTimeout) {
    this.phase = phase;
    if (seconds) {
      this.phaseSeconds = seconds;
      this.deadline = Date.now() + seconds * 1000;
      this.schedule(seconds * 1000, onTimeout);
    } else {
      this.phaseSeconds = null;
      this.deadline = null;
      this.clearTimer();
    }
    this.emit();
  }

  expectPhase(...phases) {
    if (!phases.includes(this.phase)) throw new RoomError('WRONG_PHASE', 'هذا الإجراء غير متاح في المرحلة الحالية.');
  }

  requirePlayer(pid) {
    const p = this.players.get(pid);
    if (!p) throw new RoomError('NOT_IN_ROOM', 'أنت لست في هذه الغرفة.');
    return p;
  }

  requireHost(pid) {
    this.requirePlayer(pid);
    if (pid !== this.hostId) throw new RoomError('NOT_HOST', 'هذا الإجراء لمنشئ الغرفة فقط.');
  }

  sortedPlayers() {
    return [...this.players.values()].sort((a, b) => a.joinOrder - b.joinOrder);
  }

  connectedPlayers() {
    return this.sortedPlayers().filter((p) => p.connected);
  }

  /** "متاح" = متصل أو داخل مهلة إعادة الاتصال */
  availablePlayers() {
    return this.sortedPlayers().filter((p) => !p.away);
  }

  isActive(pid) {
    return this.participants.has(pid);
  }

  activeParticipants() {
    return this.order.filter((id) => this.participants.has(id));
  }

  /** من يختار ويصوّت: كل لاعبي الجولة ما عدا الراوي */
  activeGuessers() {
    return this.activeParticipants().filter((id) => id !== this.storytellerId);
  }

  /** المضيف يبقى مضيفاً خلال مهلة الانقطاع، ويُنقل الدور بعد انتهائها */
  ensureHost() {
    const host = this.players.get(this.hostId);
    if (host && !host.away) return;
    const next = this.connectedPlayers()[0] || this.availablePlayers()[0];
    this.hostId = next ? next.id : null;
  }

  ownCardOf(pid) {
    for (const [cardId, owner] of this.cardOwners) if (owner === pid) return cardId;
    return null;
  }

  /* ======================= الانضمام والانقطاع ======================= */

  addPlayer(rawName, socketId) {
    const v = validateName(rawName);
    if (!v.ok) throw new RoomError('INVALID_NAME', v.error);
    if (this.phase !== PHASES.LOBBY) {
      throw new RoomError('GAME_IN_PROGRESS', 'اللعبة بدأت في هذه الغرفة. انتظر نهايتها أو أنشئ غرفة جديدة.');
    }
    if (this.players.size >= cfg.MAX_PLAYERS) {
      throw new RoomError('ROOM_FULL', `الغرفة ممتلئة: الحد الأقصى ${cfg.MAX_PLAYERS} لاعباً، ولا يمكن دخول لاعب رقم ${cfg.MAX_PLAYERS + 1}.`);
    }
    const lower = v.value.toLowerCase();
    if ([...this.players.values()].some((p) => p.name.toLowerCase() === lower)) {
      throw new RoomError('NAME_TAKEN', 'هذا الاسم مستخدم في الغرفة. اختر اسماً آخر.');
    }
    const player = {
      id: randomId(6),
      token: randomId(16), // معرّف الجلسة السري لإعادة الاتصال
      name: v.value,
      socketId,
      connected: true,
      away: false,          // true = انتهت مهلة الانقطاع أثناء اللعب
      score: 0,
      joinOrder: this.joinCounter++,
      graceTimer: null,
    };
    this.players.set(player.id, player);
    this.ensureHost();
    this.emit();
    return player;
  }

  findByToken(token) {
    if (!isSafeId(token)) return null;
    return [...this.players.values()].find((x) => x.token === token) || null;
  }

  /** العودة بمعرّف الجلسة: خلال المهلة يكمل اللاعب جولته كأن شيئاً لم يحدث */
  reconnect(token, socketId) {
    const p = this.findByToken(token);
    if (!p) throw new RoomError('BAD_SESSION', 'انتهت جلستك في هذه الغرفة. انضم من جديد.');
    clearTimeout(p.graceTimer);
    p.graceTimer = null;
    p.socketId = socketId;
    p.connected = true;
    p.away = false; // إن كانت مهلته انتهت، يعود بنقاطه ويشارك من الجولة القادمة
    this.ensureHost();
    this.emit();
    return p;
  }

  /** انقطاع مفاجئ: نمنح مهلة (30 ثانية افتراضياً) قبل أي إجراء */
  handleDisconnect(pid) {
    const p = this.players.get(pid);
    if (!p) return;
    p.connected = false;
    p.socketId = null;
    clearTimeout(p.graceTimer);
    p.graceTimer = setTimeout(() => this.onGraceExpired(pid), this.graceMs);
    this.emit();
  }

  onGraceExpired(pid) {
    const p = this.players.get(pid);
    if (!p || p.connected) return;
    p.graceTimer = null;
    if (this.phase === PHASES.LOBBY || this.phase === PHASES.GAME_OVER) {
      this.removePlayer(pid);
      return;
    }
    p.away = true;
    this.ensureHost();
    this.dropFromRound(pid);
    if (this.phase !== PHASES.GAME_OVER) this.emit();
  }

  /** مغادرة صريحة */
  leave(pid) {
    const p = this.players.get(pid);
    if (!p) return;
    clearTimeout(p.graceTimer);
    p.graceTimer = null;
    if (this.phase === PHASES.LOBBY || this.phase === PHASES.GAME_OVER) {
      this.removePlayer(pid);
      return;
    }
    p.token = randomId(16); // إبطال الجلسة: لا عودة بعد المغادرة الصريحة
    p.connected = false;
    p.socketId = null;
    p.away = true;
    this.ensureHost();
    this.dropFromRound(pid);
    if (this.phase !== PHASES.GAME_OVER) this.emit();
  }

  removePlayer(pid) {
    const p = this.players.get(pid);
    if (!p) return;
    clearTimeout(p.graceTimer);
    this.players.delete(pid);
    this.ensureHost();
    this.emit();
  }

  /**
   * استبعاد لاعب من الجولة بعد انتهاء مهلته: تُحذف صورته من الطاولة،
   * وتُلغى الأصوات عليها (يعيد أصحابها التصويت)، ويُحتسب الباقون فقط.
   */
  dropFromRound(pid) {
    const wasIn = this.participants.delete(pid);
    this.hands.delete(pid);
    if (this.guardPlayerCount()) return;
    if (!wasIn || !LIVE_ROUND.has(this.phase)) return;

    if (pid === this.storytellerId) {
      this.cancelRound('STORYTELLER_LEFT');
      return;
    }

    this.submissions.delete(pid);
    this.votes.delete(pid);
    this.autoPicked.delete(pid);
    const card = this.ownCardOf(pid);
    if (card) {
      this.cardOwners.delete(card);
      this.table = this.table.filter((c) => c.cardId !== card);
      for (const [voter, voted] of this.votes) if (voted === card) this.votes.delete(voter);
    }

    if (this.phase === PHASES.PLAYERS_SUBMIT_PHASE) this.maybeAllSubmitted();
    else if (this.phase === PHASES.VOTING_PHASE) this.maybeAllVoted();
  }

  /** نقص اللاعبين عن الحد الأدنى: إلغاء الجولة أو إنهاء اللعبة. يعيد true إن تصرّف. */
  guardPlayerCount() {
    if (this.phase === PHASES.LOBBY || this.phase === PHASES.GAME_OVER) return false;
    if (this.availablePlayers().length < cfg.MIN_PLAYERS) {
      this.endGame('NOT_ENOUGH_PLAYERS');
      return true;
    }
    if (LIVE_ROUND.has(this.phase) && this.activeParticipants().length < cfg.MIN_PLAYERS) {
      this.cancelRound('NOT_ENOUGH_IN_ROUND');
      return true;
    }
    return false;
  }

  /* ======================= الإعداد والبدء ======================= */

  setRounds(pid, value) {
    this.requireHost(pid);
    this.expectPhase(PHASES.LOBBY);
    const r = validateRounds(value);
    if (!r.ok) throw new RoomError('BAD_ROUNDS', r.error);
    this.customRounds = r.value;
    this.emit();
  }

  startGame(pid) {
    this.requireHost(pid);
    this.expectPhase(PHASES.LOBBY);
    const players = this.connectedPlayers();
    if (players.length < cfg.MIN_PLAYERS) {
      throw new RoomError('NOT_ENOUGH_PLAYERS', `تحتاج ${cfg.MIN_PLAYERS} لاعبين متصلين على الأقل للبدء.`);
    }
    // من انقطع في الانتظار ولم يعد لا يدخل اللعبة
    for (const p of this.sortedPlayers()) if (!p.connected) this.removePlayer(p.id);
    players.forEach((p) => { p.score = 0; p.away = false; });
    this.order = players.map((p) => p.id);
    this.totalRounds = this.customRounds ?? Math.min(players.length, cfg.MAX_ROUNDS);
    this.round = 0;
    this.storytellerId = null;
    this.lastResult = null;
    this.final = null;
    this.usedImages.clear();
    this.startRound();
  }

  restart(pid) {
    this.requireHost(pid);
    this.expectPhase(PHASES.GAME_OVER);
    for (const p of this.sortedPlayers()) {
      if (!p.connected) { clearTimeout(p.graceTimer); this.players.delete(p.id); } else { p.score = 0; p.away = false; }
    }
    this.ensureHost();
    this.resetGame();
    this.emit();
  }

  /** الراوي: الأول عشوائي (crypto)، ثم التالي بالترتيب الثابت دون تكرار الراوي السابق */
  nextStoryteller(eligible) {
    if (!this.storytellerId) return pick(eligible);
    const start = this.order.indexOf(this.storytellerId);
    for (let i = 1; i <= this.order.length; i++) {
      const id = this.order[(start + i) % this.order.length];
      if (eligible.includes(id) && id !== this.storytellerId) return id;
    }
    return pick(eligible);
  }

  /* ======================= دورة الجولة ======================= */

  async startRound() {
    this.clearRound();
    const available = this.order.filter((id) => { const p = this.players.get(id); return p && !p.away; });
    if (available.length < cfg.MIN_PLAYERS) return this.endGame('NOT_ENOUGH_PLAYERS');

    this.round += 1;
    // نفضّل راوياً متصلاً الآن؛ من هو داخل مهلة الانقطاع يشارك لاعباً عادياً
    const connected = available.filter((id) => this.players.get(id).connected);
    this.storytellerId = this.nextStoryteller(connected.length ? connected : available);
    this.participants = new Set(available);
    this.lastResult = null;
    this.setPhase(PHASES.DEALING);

    const token = ++this.roundToken;
    const need = available.length * cfg.HAND_SIZE;
    let images;
    try {
      images = await this.images.getImages(need, this.usedImages);
    } catch (err) {
      console.error('[room] image provider failed, using generated', err);
      images = Array.from({ length: need }, generatedImage);
    }
    // تغيّرت الحالة أثناء جلب الصور (إلغاء/نهاية)؟ نتجاهل النتيجة
    if (token !== this.roundToken || this.phase !== PHASES.DEALING) return undefined;

    // 5 صور فريدة لكل لاعب
    let i = 0;
    for (const pid of this.participants) {
      const hand = images.slice(i, i + cfg.HAND_SIZE);
      i += cfg.HAND_SIZE;
      this.hands.set(pid, hand);
      hand.forEach((img) => { this.imageIndex.set(img.id, img); this.usedImages.add(img.id); });
    }
    this.emit();

    this.schedule(this.transitions.DEALING, () => {
      this.setPhase(PHASES.STORYTELLER_PHASE, this.timers.STORYTELLER_PHASE, () => this.onStorytellerTimeout());
    });
    return undefined;
  }

  handHas(pid, imageId) {
    return isSafeId(imageId) && (this.hands.get(pid) || []).some((img) => img.id === imageId);
  }

  storytellerSubmit(pid, imageId, description) {
    this.requirePlayer(pid);
    this.expectPhase(PHASES.STORYTELLER_PHASE);
    if (pid !== this.storytellerId) throw new RoomError('NOT_STORYTELLER', 'الراوي فقط يكتب الوصف في هذه المرحلة.');
    if (!this.handHas(pid, imageId)) throw new RoomError('BAD_IMAGE', 'اختر صورة من صورك الخمس.');
    const v = validateDescription(description);
    if (!v.ok) throw new RoomError('BAD_DESCRIPTION', v.error);
    this.submissions.set(pid, imageId);
    this.description = v.value;
    this.enterSubmitPhase();
  }

  onStorytellerTimeout() {
    const hand = this.hands.get(this.storytellerId);
    if (!hand || !hand.length) return this.cancelRound('STORYTELLER_LEFT');
    this.submissions.set(this.storytellerId, pick(hand).id);
    this.description = pick(AUTO_DESCRIPTIONS);
    this.autoDescription = true;
    return this.enterSubmitPhase();
  }

  enterSubmitPhase() {
    this.setPhase(PHASES.PLAYERS_SUBMIT_PHASE, this.timers.PLAYERS_SUBMIT_PHASE, () => this.onSubmitTimeout());
  }

  playerSubmit(pid, imageId) {
    this.requirePlayer(pid);
    this.expectPhase(PHASES.PLAYERS_SUBMIT_PHASE);
    if (pid === this.storytellerId) throw new RoomError('NOT_ALLOWED', 'أنت الراوي، وصورتك أُرسلت بالفعل.');
    if (!this.isActive(pid)) throw new RoomError('NOT_PARTICIPANT', 'ستشارك من الجولة القادمة.');
    if (!this.handHas(pid, imageId)) throw new RoomError('BAD_IMAGE', 'اختر صورة من صورك الخمس.');
    this.submissions.set(pid, imageId); // يمكن تغيير الاختيار حتى يرسل الجميع
    this.autoPicked.delete(pid);
    this.maybeAllSubmitted();
  }

  maybeAllSubmitted() {
    if (this.activeGuessers().every((id) => this.submissions.has(id))) this.toShuffleReveal();
    else this.emit();
  }

  onSubmitTimeout() {
    for (const pid of this.activeGuessers()) {
      if (this.submissions.has(pid)) continue;
      const hand = this.hands.get(pid);
      if (hand?.length) { this.submissions.set(pid, pick(hand).id); this.autoPicked.add(pid); }
    }
    this.toShuffleReveal();
  }

  /** خلط وتجريد من الهوية: معرّفات بطاقات جديدة عشوائية لا تُربط بأصحابها */
  toShuffleReveal() {
    const entries = [...this.submissions].filter(([pid]) => this.participants.has(pid));
    const cards = shuffle(entries.map(([pid, imageId]) => {
      const img = this.imageIndex.get(imageId);
      return { cardId: randomId(6), pid, url: img.url, fallback: img.fallback };
    }));
    this.cardOwners = new Map(cards.map((c) => [c.cardId, c.pid]));
    this.table = cards.map(({ cardId, url, fallback }) => ({ cardId, url, fallback }));
    this.storytellerCardId = cards.find((c) => c.pid === this.storytellerId)?.cardId || null;
    this.votes = new Map();
    this.setPhase(PHASES.SHUFFLE_REVEAL);
    this.schedule(this.transitions.SHUFFLE_REVEAL, () => {
      this.setPhase(PHASES.VOTING_PHASE, this.timers.VOTING_PHASE, () => this.onVotingTimeout());
    });
  }

  vote(pid, cardId) {
    this.requirePlayer(pid);
    this.expectPhase(PHASES.VOTING_PHASE);
    if (pid === this.storytellerId) throw new RoomError('NOT_ALLOWED', 'الراوي لا يصوّت.');
    if (!this.isActive(pid)) throw new RoomError('NOT_PARTICIPANT', 'ستشارك من الجولة القادمة.');
    if (!isSafeId(cardId) || !this.cardOwners.has(cardId)) throw new RoomError('BAD_CARD', 'هذه البطاقة غير موجودة.');
    if (this.cardOwners.get(cardId) === pid) throw new RoomError('OWN_CARD', 'لا يمكنك التصويت على صورتك.');
    this.votes.set(pid, cardId); // يمكن تغيير الصوت حتى يصوّت الجميع
    this.autoPicked.delete(pid);
    this.maybeAllVoted();
  }

  maybeAllVoted() {
    if (this.activeGuessers().every((id) => this.votes.has(id))) this.toScoring();
    else this.emit();
  }

  onVotingTimeout() {
    for (const pid of this.activeGuessers()) {
      if (this.votes.has(pid)) continue;
      const options = this.table.filter((c) => this.cardOwners.get(c.cardId) !== pid);
      if (options.length) { this.votes.set(pid, pick(options).cardId); this.autoPicked.add(pid); }
    }
    this.toScoring();
  }

  toScoring() {
    const res = scoreRound({
      storytellerId: this.storytellerId,
      storytellerCardId: this.storytellerCardId,
      cardOwners: Object.fromEntries(this.cardOwners),
      votes: Object.fromEntries(this.votes),
      voterIds: this.activeGuessers(),
    });
    for (const [pid, d] of Object.entries(res.deltas)) {
      const p = this.players.get(pid);
      if (p) p.score += d;
    }
    const nameOf = (id) => this.players.get(id)?.name ?? '—';
    this.lastResult = {
      round: this.round,
      cancelled: false,
      storytellerId: this.storytellerId,
      storytellerName: nameOf(this.storytellerId),
      description: this.description,
      autoDescription: this.autoDescription,
      outcome: res.outcome,
      correctVoterIds: res.correctVoters,
      cards: this.table.map((c) => {
        const ownerId = this.cardOwners.get(c.cardId);
        return {
          cardId: c.cardId,
          url: c.url,
          fallback: c.fallback,
          ownerId,
          ownerName: nameOf(ownerId),
          isStoryteller: ownerId === this.storytellerId,
          voters: [...this.votes].filter(([, card]) => card === c.cardId).map(([v]) => ({ id: v, name: nameOf(v) })),
        };
      }),
      deltas: res.deltas,
      autoPicked: [...this.autoPicked].map(nameOf),
    };
    this.setPhase(PHASES.SCORING_PHASE, this.timers.SCORING_PHASE, () => this.afterScoring());
  }

  /** إلغاء الجولة دون نقاط (انتهاء مهلة الراوي أو نقص اللاعبين) */
  cancelRound(reason) {
    this.roundToken += 1;
    this.lastResult = {
      round: this.round,
      cancelled: true,
      reason,
      storytellerId: this.storytellerId,
      storytellerName: this.players.get(this.storytellerId)?.name ?? '—',
    };
    this.setPhase(PHASES.SCORING_PHASE, this.timers.SCORING_PHASE, () => this.afterScoring());
  }

  continueFromScoring(pid) {
    this.requireHost(pid);
    this.expectPhase(PHASES.SCORING_PHASE);
    this.afterScoring();
  }

  afterScoring() {
    if (this.round >= this.totalRounds) return this.endGame('COMPLETED');
    this.startRound();
    return undefined;
  }

  endGame(reason) {
    this.clearTimer();
    this.roundToken += 1;
    this.endReason = reason;
    this.final = rankPlayers(this.sortedPlayers().filter((p) => this.order.includes(p.id)))
      .map(({ id, name, score, rank }) => ({ id, name, score, rank }));
    this.clearRound();
    this.phase = PHASES.GAME_OVER;
    this.deadline = null;
    this.phaseSeconds = null;
    this.emit();
  }

  destroy() {
    this.clearTimer();
    this.roundToken += 1;
    for (const p of this.players.values()) clearTimeout(p.graceTimer);
  }

  /* ======================= منظور اللاعب ======================= */

  doneFlag(pid) {
    if (!this.participants.has(pid)) return false;
    if (this.phase === PHASES.STORYTELLER_PHASE) return pid === this.storytellerId && this.submissions.has(pid);
    if (this.phase === PHASES.PLAYERS_SUBMIT_PHASE) return this.submissions.has(pid);
    if (this.phase === PHASES.VOTING_PHASE) return pid === this.storytellerId || this.votes.has(pid);
    return false;
  }

  /** ما يحق للاعب رؤيته فقط — لا يُرسل أبداً شيء من أسرار الآخرين */
  viewFor(pid) {
    const me = this.players.get(pid);
    if (!me) return null;
    const p = this.phase;
    const view = {
      code: this.code,
      phase: p,
      round: this.round,
      totalRounds: this.totalRounds,
      deadline: this.deadline,
      phaseSeconds: this.phaseSeconds,
      serverNow: Date.now(),
      hostId: this.hostId,
      storytellerId: p === PHASES.LOBBY ? null : this.storytellerId,
      settings: {
        customRounds: this.customRounds,
        minPlayers: cfg.MIN_PLAYERS,
        maxPlayers: cfg.MAX_PLAYERS,
        maxRounds: cfg.MAX_ROUNDS,
        descriptionMax: cfg.DESCRIPTION_MAX,
        graceSeconds: Math.round(this.graceMs / 1000),
      },
      me: {
        id: me.id,
        name: me.name,
        isHost: pid === this.hostId,
        isStoryteller: p !== PHASES.LOBBY && pid === this.storytellerId,
        participating: this.participants.has(pid),
      },
      players: this.sortedPlayers().map((x) => ({
        id: x.id,
        name: x.name,
        score: x.score,
        connected: x.connected,
        away: x.away,
        isHost: x.id === this.hostId,
        isStoryteller: p !== PHASES.LOBBY && x.id === this.storytellerId,
        inRound: this.participants.has(x.id),
        done: this.doneFlag(x.id),
      })),
    };

    if ([PHASES.PLAYERS_SUBMIT_PHASE, PHASES.SHUFFLE_REVEAL, PHASES.VOTING_PHASE].includes(p)) {
      view.description = this.description;
      view.autoDescription = this.autoDescription;
    }
    if ([PHASES.STORYTELLER_PHASE, PHASES.PLAYERS_SUBMIT_PHASE].includes(p)) {
      const g = this.activeGuessers();
      view.progress = { done: g.filter((id) => this.submissions.has(id)).length, total: g.length };
      if (this.participants.has(pid)) {
        view.hand = this.hands.get(pid) || [];
        view.mySubmission = this.submissions.get(pid) || null;
      }
    }
    if (p === PHASES.SHUFFLE_REVEAL || p === PHASES.VOTING_PHASE) {
      view.table = this.table;              // صور فقط بلا أصحاب
      view.myCardId = this.ownCardOf(pid);   // يعرف اللاعب بطاقته هو فقط
    }
    if (p === PHASES.VOTING_PHASE) {
      const g = this.activeGuessers();
      view.progress = { done: g.filter((id) => this.votes.has(id)).length, total: g.length };
      view.myVote = this.votes.get(pid) || null;
    }
    if (p === PHASES.SCORING_PHASE) view.result = this.lastResult;
    if (p === PHASES.GAME_OVER) {
      view.final = this.final;
      view.endReason = this.endReason;
    }
    return view;
  }
}

module.exports = { Room, RoomError, PHASES };
