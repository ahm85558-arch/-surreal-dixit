'use strict';
/**
 * أدوات العشوائية المعتمدة على crypto لضمان العدالة (لا نستخدم Math.random في منطق اللعب).
 */
const crypto = require('crypto');

/** عدد صحيح عشوائي في المدى [0, max) */
const randInt = (max) => crypto.randomInt(max);

/** عنصر عشوائي من مصفوفة */
const pick = (arr) => arr[crypto.randomInt(arr.length)];

/** خلط Fisher–Yates بمولد آمن، يعيد نسخة جديدة */
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** معرّف سداسي عشري عشوائي */
const randomId = (bytes = 8) => crypto.randomBytes(bytes).toString('hex');

// أبجدية بلا أحرف ملتبسة (0/O و1/I)
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function roomCode(len = 6) {
  let s = '';
  for (let i = 0; i < len; i++) s += CODE_ALPHABET[crypto.randomInt(CODE_ALPHABET.length)];
  return s;
}

module.exports = { randInt, pick, shuffle, randomId, roomCode, CODE_ALPHABET };
